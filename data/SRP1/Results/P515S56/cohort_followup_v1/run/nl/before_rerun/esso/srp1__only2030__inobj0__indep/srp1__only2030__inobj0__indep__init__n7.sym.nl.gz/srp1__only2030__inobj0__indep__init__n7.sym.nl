g3 1 1 0	# problem 'ESSO, Operational Planning'
 1002 1004 1 0 330 	# vars, constraints, objectives, ranges, eqns
 292 0 0 0 0 0	# nonlinear constrs, objs; ccons: lin, nonlin, nd, nzlb
 0 0	# network constraints: nonlinear, linear
 9 0 0 	# nonlinear vars in constraints, objectives, both
 0 0 0 1	# linear network variables; functions; arith, flags
 0 0 0 0 0 	# discrete variables: binary, integer, nonlinear (b,c,o)
 2475 960 	# nonzeros in Jacobian, obj. gradient
 39 28	# max name lengths: constraints, variables
 0 0 0 0 0	# common exprs: b,c,o,c1,o1
C0	#available_e_capacity_unit[5]
o16	#-
o2	#*
v0	#es_e_rated_per_unit[1,1]
v5	#es_soh_per_unit_cumul[1,1]
C1	#available_e_capacity_unit[6]
o16	#-
o2	#*
v1	#es_e_rated_per_unit[1,2]
v6	#es_soh_per_unit_cumul[1,2]
C2	#energy_storage_capacity_degradation[11]
o2	#*
n-0.9272165023656249
o44	#exp
o2	#*
n-1
v7	#es_D_per_unit[1,1]
C3	#energy_storage_capacity_degradation[14]
o2	#*
n-0.9272165023656249
o2	#*
v5	#es_soh_per_unit_cumul[1,1]
o44	#exp
o2	#*
n-1
v8	#es_D_per_unit[1,2]
C4	#energy_storage_operation_agg[2]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C5	#energy_storage_operation_agg[4]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C6	#energy_storage_operation_agg[6]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C7	#energy_storage_operation_agg[8]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C8	#energy_storage_operation_agg[10]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C9	#energy_storage_operation_agg[12]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C10	#energy_storage_operation_agg[14]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C11	#energy_storage_operation_agg[16]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C12	#energy_storage_operation_agg[18]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C13	#energy_storage_operation_agg[20]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C14	#energy_storage_operation_agg[22]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C15	#energy_storage_operation_agg[24]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C16	#energy_storage_operation_agg[26]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C17	#energy_storage_operation_agg[28]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C18	#energy_storage_operation_agg[30]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C19	#energy_storage_operation_agg[32]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C20	#energy_storage_operation_agg[34]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C21	#energy_storage_operation_agg[36]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C22	#energy_storage_operation_agg[38]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C23	#energy_storage_operation_agg[40]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C24	#energy_storage_operation_agg[42]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C25	#energy_storage_operation_agg[44]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C26	#energy_storage_operation_agg[46]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C27	#energy_storage_operation_agg[48]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C28	#energy_storage_operation_agg[50]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C29	#energy_storage_operation_agg[52]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C30	#energy_storage_operation_agg[54]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C31	#energy_storage_operation_agg[56]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C32	#energy_storage_operation_agg[58]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C33	#energy_storage_operation_agg[60]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C34	#energy_storage_operation_agg[62]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C35	#energy_storage_operation_agg[64]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C36	#energy_storage_operation_agg[66]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C37	#energy_storage_operation_agg[68]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C38	#energy_storage_operation_agg[70]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C39	#energy_storage_operation_agg[72]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C40	#energy_storage_operation_agg[74]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C41	#energy_storage_operation_agg[76]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C42	#energy_storage_operation_agg[78]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C43	#energy_storage_operation_agg[80]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C44	#energy_storage_operation_agg[82]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C45	#energy_storage_operation_agg[84]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C46	#energy_storage_operation_agg[86]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C47	#energy_storage_operation_agg[88]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C48	#energy_storage_operation_agg[90]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C49	#energy_storage_operation_agg[92]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C50	#energy_storage_operation_agg[94]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C51	#energy_storage_operation_agg[96]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C52	#energy_storage_operation_agg[98]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C53	#energy_storage_operation_agg[100]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C54	#energy_storage_operation_agg[102]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C55	#energy_storage_operation_agg[104]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C56	#energy_storage_operation_agg[106]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C57	#energy_storage_operation_agg[108]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C58	#energy_storage_operation_agg[110]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C59	#energy_storage_operation_agg[112]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C60	#energy_storage_operation_agg[114]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C61	#energy_storage_operation_agg[116]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C62	#energy_storage_operation_agg[118]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C63	#energy_storage_operation_agg[120]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C64	#energy_storage_operation_agg[122]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C65	#energy_storage_operation_agg[124]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C66	#energy_storage_operation_agg[126]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C67	#energy_storage_operation_agg[128]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C68	#energy_storage_operation_agg[130]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C69	#energy_storage_operation_agg[132]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C70	#energy_storage_operation_agg[134]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C71	#energy_storage_operation_agg[136]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C72	#energy_storage_operation_agg[138]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C73	#energy_storage_operation_agg[140]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C74	#energy_storage_operation_agg[142]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C75	#energy_storage_operation_agg[144]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C76	#energy_storage_operation_agg[146]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C77	#energy_storage_operation_agg[148]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C78	#energy_storage_operation_agg[150]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C79	#energy_storage_operation_agg[152]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C80	#energy_storage_operation_agg[154]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C81	#energy_storage_operation_agg[156]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C82	#energy_storage_operation_agg[158]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C83	#energy_storage_operation_agg[160]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C84	#energy_storage_operation_agg[162]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C85	#energy_storage_operation_agg[164]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C86	#energy_storage_operation_agg[166]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C87	#energy_storage_operation_agg[168]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C88	#energy_storage_operation_agg[170]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C89	#energy_storage_operation_agg[172]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C90	#energy_storage_operation_agg[174]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C91	#energy_storage_operation_agg[176]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C92	#energy_storage_operation_agg[178]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C93	#energy_storage_operation_agg[180]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C94	#energy_storage_operation_agg[182]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C95	#energy_storage_operation_agg[184]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C96	#energy_storage_operation_agg[186]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C97	#energy_storage_operation_agg[188]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C98	#energy_storage_operation_agg[190]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C99	#energy_storage_operation_agg[192]
o16	#-
o5	#^
v2	#es_s_rated[0]
n2
C100	#energy_storage_operation_agg[194]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C101	#energy_storage_operation_agg[196]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C102	#energy_storage_operation_agg[198]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C103	#energy_storage_operation_agg[200]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C104	#energy_storage_operation_agg[202]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C105	#energy_storage_operation_agg[204]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C106	#energy_storage_operation_agg[206]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C107	#energy_storage_operation_agg[208]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C108	#energy_storage_operation_agg[210]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C109	#energy_storage_operation_agg[212]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C110	#energy_storage_operation_agg[214]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C111	#energy_storage_operation_agg[216]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C112	#energy_storage_operation_agg[218]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C113	#energy_storage_operation_agg[220]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C114	#energy_storage_operation_agg[222]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C115	#energy_storage_operation_agg[224]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C116	#energy_storage_operation_agg[226]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C117	#energy_storage_operation_agg[228]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C118	#energy_storage_operation_agg[230]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C119	#energy_storage_operation_agg[232]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C120	#energy_storage_operation_agg[234]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C121	#energy_storage_operation_agg[236]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C122	#energy_storage_operation_agg[238]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C123	#energy_storage_operation_agg[240]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C124	#energy_storage_operation_agg[242]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C125	#energy_storage_operation_agg[244]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C126	#energy_storage_operation_agg[246]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C127	#energy_storage_operation_agg[248]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C128	#energy_storage_operation_agg[250]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C129	#energy_storage_operation_agg[252]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C130	#energy_storage_operation_agg[254]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C131	#energy_storage_operation_agg[256]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C132	#energy_storage_operation_agg[258]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C133	#energy_storage_operation_agg[260]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C134	#energy_storage_operation_agg[262]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C135	#energy_storage_operation_agg[264]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C136	#energy_storage_operation_agg[266]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C137	#energy_storage_operation_agg[268]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C138	#energy_storage_operation_agg[270]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C139	#energy_storage_operation_agg[272]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C140	#energy_storage_operation_agg[274]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C141	#energy_storage_operation_agg[276]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C142	#energy_storage_operation_agg[278]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C143	#energy_storage_operation_agg[280]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C144	#energy_storage_operation_agg[282]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C145	#energy_storage_operation_agg[284]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C146	#energy_storage_operation_agg[286]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C147	#energy_storage_operation_agg[288]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C148	#energy_storage_operation_agg[290]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C149	#energy_storage_operation_agg[292]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C150	#energy_storage_operation_agg[294]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C151	#energy_storage_operation_agg[296]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C152	#energy_storage_operation_agg[298]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C153	#energy_storage_operation_agg[300]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C154	#energy_storage_operation_agg[302]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C155	#energy_storage_operation_agg[304]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C156	#energy_storage_operation_agg[306]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C157	#energy_storage_operation_agg[308]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C158	#energy_storage_operation_agg[310]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C159	#energy_storage_operation_agg[312]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C160	#energy_storage_operation_agg[314]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C161	#energy_storage_operation_agg[316]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C162	#energy_storage_operation_agg[318]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C163	#energy_storage_operation_agg[320]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C164	#energy_storage_operation_agg[322]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C165	#energy_storage_operation_agg[324]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C166	#energy_storage_operation_agg[326]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C167	#energy_storage_operation_agg[328]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C168	#energy_storage_operation_agg[330]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C169	#energy_storage_operation_agg[332]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C170	#energy_storage_operation_agg[334]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C171	#energy_storage_operation_agg[336]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C172	#energy_storage_operation_agg[338]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C173	#energy_storage_operation_agg[340]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C174	#energy_storage_operation_agg[342]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C175	#energy_storage_operation_agg[344]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C176	#energy_storage_operation_agg[346]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C177	#energy_storage_operation_agg[348]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C178	#energy_storage_operation_agg[350]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C179	#energy_storage_operation_agg[352]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C180	#energy_storage_operation_agg[354]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C181	#energy_storage_operation_agg[356]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C182	#energy_storage_operation_agg[358]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C183	#energy_storage_operation_agg[360]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C184	#energy_storage_operation_agg[362]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C185	#energy_storage_operation_agg[364]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C186	#energy_storage_operation_agg[366]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C187	#energy_storage_operation_agg[368]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C188	#energy_storage_operation_agg[370]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C189	#energy_storage_operation_agg[372]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C190	#energy_storage_operation_agg[374]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C191	#energy_storage_operation_agg[376]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C192	#energy_storage_operation_agg[378]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C193	#energy_storage_operation_agg[380]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C194	#energy_storage_operation_agg[382]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C195	#energy_storage_operation_agg[384]
o16	#-
o5	#^
v3	#es_s_rated[1]
n2
C196	#energy_storage_operation_agg[386]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C197	#energy_storage_operation_agg[388]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C198	#energy_storage_operation_agg[390]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C199	#energy_storage_operation_agg[392]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C200	#energy_storage_operation_agg[394]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C201	#energy_storage_operation_agg[396]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C202	#energy_storage_operation_agg[398]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C203	#energy_storage_operation_agg[400]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C204	#energy_storage_operation_agg[402]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C205	#energy_storage_operation_agg[404]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C206	#energy_storage_operation_agg[406]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C207	#energy_storage_operation_agg[408]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C208	#energy_storage_operation_agg[410]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C209	#energy_storage_operation_agg[412]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C210	#energy_storage_operation_agg[414]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C211	#energy_storage_operation_agg[416]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C212	#energy_storage_operation_agg[418]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C213	#energy_storage_operation_agg[420]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C214	#energy_storage_operation_agg[422]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C215	#energy_storage_operation_agg[424]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C216	#energy_storage_operation_agg[426]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C217	#energy_storage_operation_agg[428]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C218	#energy_storage_operation_agg[430]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C219	#energy_storage_operation_agg[432]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C220	#energy_storage_operation_agg[434]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C221	#energy_storage_operation_agg[436]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C222	#energy_storage_operation_agg[438]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C223	#energy_storage_operation_agg[440]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C224	#energy_storage_operation_agg[442]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C225	#energy_storage_operation_agg[444]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C226	#energy_storage_operation_agg[446]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C227	#energy_storage_operation_agg[448]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C228	#energy_storage_operation_agg[450]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C229	#energy_storage_operation_agg[452]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C230	#energy_storage_operation_agg[454]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C231	#energy_storage_operation_agg[456]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C232	#energy_storage_operation_agg[458]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C233	#energy_storage_operation_agg[460]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C234	#energy_storage_operation_agg[462]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C235	#energy_storage_operation_agg[464]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C236	#energy_storage_operation_agg[466]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C237	#energy_storage_operation_agg[468]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C238	#energy_storage_operation_agg[470]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C239	#energy_storage_operation_agg[472]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C240	#energy_storage_operation_agg[474]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C241	#energy_storage_operation_agg[476]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C242	#energy_storage_operation_agg[478]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C243	#energy_storage_operation_agg[480]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C244	#energy_storage_operation_agg[482]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C245	#energy_storage_operation_agg[484]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C246	#energy_storage_operation_agg[486]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C247	#energy_storage_operation_agg[488]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C248	#energy_storage_operation_agg[490]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C249	#energy_storage_operation_agg[492]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C250	#energy_storage_operation_agg[494]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C251	#energy_storage_operation_agg[496]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C252	#energy_storage_operation_agg[498]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C253	#energy_storage_operation_agg[500]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C254	#energy_storage_operation_agg[502]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C255	#energy_storage_operation_agg[504]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C256	#energy_storage_operation_agg[506]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C257	#energy_storage_operation_agg[508]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C258	#energy_storage_operation_agg[510]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C259	#energy_storage_operation_agg[512]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C260	#energy_storage_operation_agg[514]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C261	#energy_storage_operation_agg[516]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C262	#energy_storage_operation_agg[518]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C263	#energy_storage_operation_agg[520]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C264	#energy_storage_operation_agg[522]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C265	#energy_storage_operation_agg[524]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C266	#energy_storage_operation_agg[526]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C267	#energy_storage_operation_agg[528]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C268	#energy_storage_operation_agg[530]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C269	#energy_storage_operation_agg[532]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C270	#energy_storage_operation_agg[534]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C271	#energy_storage_operation_agg[536]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C272	#energy_storage_operation_agg[538]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C273	#energy_storage_operation_agg[540]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C274	#energy_storage_operation_agg[542]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C275	#energy_storage_operation_agg[544]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C276	#energy_storage_operation_agg[546]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C277	#energy_storage_operation_agg[548]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C278	#energy_storage_operation_agg[550]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C279	#energy_storage_operation_agg[552]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C280	#energy_storage_operation_agg[554]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C281	#energy_storage_operation_agg[556]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C282	#energy_storage_operation_agg[558]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C283	#energy_storage_operation_agg[560]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C284	#energy_storage_operation_agg[562]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C285	#energy_storage_operation_agg[564]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C286	#energy_storage_operation_agg[566]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C287	#energy_storage_operation_agg[568]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C288	#energy_storage_operation_agg[570]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C289	#energy_storage_operation_agg[572]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C290	#energy_storage_operation_agg[574]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C291	#energy_storage_operation_agg[576]
o16	#-
o5	#^
v4	#es_s_rated[2]
n2
C292	#rated_s_capacity_unit[1]
n0
C293	#rated_s_capacity_unit[2]
n0
C294	#rated_s_capacity_unit[3]
n0
C295	#rated_s_capacity_unit[4]
n0
C296	#rated_s_capacity_unit[5]
n0
C297	#rated_s_capacity_unit[6]
n0
C298	#rated_e_capacity_unit[1]
n0
C299	#rated_e_capacity_unit[2]
n0
C300	#rated_e_capacity_unit[3]
n0
C301	#rated_e_capacity_unit[4]
n0
C302	#rated_e_capacity_unit[5]
n0
C303	#rated_e_capacity_unit[6]
n0
C304	#rated_s_capacity[1]
n0
C305	#rated_s_capacity[2]
n0
C306	#rated_s_capacity[3]
n0
C307	#rated_e_capacity[1]
n0
C308	#rated_e_capacity[2]
n0
C309	#rated_e_capacity[3]
n0
C310	#available_s_capacity_unit[1]
n0
C311	#available_s_capacity_unit[2]
n0
C312	#available_s_capacity_unit[3]
n0
C313	#available_s_capacity_unit[4]
n0
C314	#available_s_capacity_unit[5]
n0
C315	#available_s_capacity_unit[6]
n0
C316	#available_s_capacity_unit[7]
n0
C317	#available_s_capacity_unit[8]
n0
C318	#available_s_capacity_unit[9]
n0
C319	#available_e_capacity_unit[1]
n0
C320	#available_e_capacity_unit[2]
n0
C321	#available_e_capacity_unit[3]
n0
C322	#available_e_capacity_unit[4]
n0
C323	#available_e_capacity_unit[7]
n0
C324	#available_e_capacity_unit[8]
n0
C325	#available_e_capacity_unit[9]
n0
C326	#energy_storage_charging_discharging[5]
n0
C327	#energy_storage_charging_discharging[6]
n0
C328	#energy_storage_capacity_degradation[10]
n0
C329	#energy_storage_capacity_degradation[12]
n0
C330	#energy_storage_capacity_degradation[13]
n0
C331	#energy_storage_capacity_degradation[15]
n0
C332	#energy_storage_limits[769]
n0
C333	#energy_storage_limits[770]
n0
C334	#energy_storage_limits[771]
n0
C335	#energy_storage_limits[772]
n0
C336	#energy_storage_limits[773]
n0
C337	#energy_storage_limits[774]
n0
C338	#energy_storage_limits[775]
n0
C339	#energy_storage_limits[776]
n0
C340	#energy_storage_limits[777]
n0
C341	#energy_storage_limits[778]
n0
C342	#energy_storage_limits[779]
n0
C343	#energy_storage_limits[780]
n0
C344	#energy_storage_limits[781]
n0
C345	#energy_storage_limits[782]
n0
C346	#energy_storage_limits[783]
n0
C347	#energy_storage_limits[784]
n0
C348	#energy_storage_limits[785]
n0
C349	#energy_storage_limits[786]
n0
C350	#energy_storage_limits[787]
n0
C351	#energy_storage_limits[788]
n0
C352	#energy_storage_limits[789]
n0
C353	#energy_storage_limits[790]
n0
C354	#energy_storage_limits[791]
n0
C355	#energy_storage_limits[792]
n0
C356	#energy_storage_limits[793]
n0
C357	#energy_storage_limits[794]
n0
C358	#energy_storage_limits[795]
n0
C359	#energy_storage_limits[796]
n0
C360	#energy_storage_limits[797]
n0
C361	#energy_storage_limits[798]
n0
C362	#energy_storage_limits[799]
n0
C363	#energy_storage_limits[800]
n0
C364	#energy_storage_limits[801]
n0
C365	#energy_storage_limits[802]
n0
C366	#energy_storage_limits[803]
n0
C367	#energy_storage_limits[804]
n0
C368	#energy_storage_limits[805]
n0
C369	#energy_storage_limits[806]
n0
C370	#energy_storage_limits[807]
n0
C371	#energy_storage_limits[808]
n0
C372	#energy_storage_limits[809]
n0
C373	#energy_storage_limits[810]
n0
C374	#energy_storage_limits[811]
n0
C375	#energy_storage_limits[812]
n0
C376	#energy_storage_limits[813]
n0
C377	#energy_storage_limits[814]
n0
C378	#energy_storage_limits[815]
n0
C379	#energy_storage_limits[816]
n0
C380	#energy_storage_limits[817]
n0
C381	#energy_storage_limits[818]
n0
C382	#energy_storage_limits[819]
n0
C383	#energy_storage_limits[820]
n0
C384	#energy_storage_limits[821]
n0
C385	#energy_storage_limits[822]
n0
C386	#energy_storage_limits[823]
n0
C387	#energy_storage_limits[824]
n0
C388	#energy_storage_limits[825]
n0
C389	#energy_storage_limits[826]
n0
C390	#energy_storage_limits[827]
n0
C391	#energy_storage_limits[828]
n0
C392	#energy_storage_limits[829]
n0
C393	#energy_storage_limits[830]
n0
C394	#energy_storage_limits[831]
n0
C395	#energy_storage_limits[832]
n0
C396	#energy_storage_limits[833]
n0
C397	#energy_storage_limits[834]
n0
C398	#energy_storage_limits[835]
n0
C399	#energy_storage_limits[836]
n0
C400	#energy_storage_limits[837]
n0
C401	#energy_storage_limits[838]
n0
C402	#energy_storage_limits[839]
n0
C403	#energy_storage_limits[840]
n0
C404	#energy_storage_limits[841]
n0
C405	#energy_storage_limits[842]
n0
C406	#energy_storage_limits[843]
n0
C407	#energy_storage_limits[844]
n0
C408	#energy_storage_limits[845]
n0
C409	#energy_storage_limits[846]
n0
C410	#energy_storage_limits[847]
n0
C411	#energy_storage_limits[848]
n0
C412	#energy_storage_limits[849]
n0
C413	#energy_storage_limits[850]
n0
C414	#energy_storage_limits[851]
n0
C415	#energy_storage_limits[852]
n0
C416	#energy_storage_limits[853]
n0
C417	#energy_storage_limits[854]
n0
C418	#energy_storage_limits[855]
n0
C419	#energy_storage_limits[856]
n0
C420	#energy_storage_limits[857]
n0
C421	#energy_storage_limits[858]
n0
C422	#energy_storage_limits[859]
n0
C423	#energy_storage_limits[860]
n0
C424	#energy_storage_limits[861]
n0
C425	#energy_storage_limits[862]
n0
C426	#energy_storage_limits[863]
n0
C427	#energy_storage_limits[864]
n0
C428	#energy_storage_limits[865]
n0
C429	#energy_storage_limits[866]
n0
C430	#energy_storage_limits[867]
n0
C431	#energy_storage_limits[868]
n0
C432	#energy_storage_limits[869]
n0
C433	#energy_storage_limits[870]
n0
C434	#energy_storage_limits[871]
n0
C435	#energy_storage_limits[872]
n0
C436	#energy_storage_limits[873]
n0
C437	#energy_storage_limits[874]
n0
C438	#energy_storage_limits[875]
n0
C439	#energy_storage_limits[876]
n0
C440	#energy_storage_limits[877]
n0
C441	#energy_storage_limits[878]
n0
C442	#energy_storage_limits[879]
n0
C443	#energy_storage_limits[880]
n0
C444	#energy_storage_limits[881]
n0
C445	#energy_storage_limits[882]
n0
C446	#energy_storage_limits[883]
n0
C447	#energy_storage_limits[884]
n0
C448	#energy_storage_limits[885]
n0
C449	#energy_storage_limits[886]
n0
C450	#energy_storage_limits[887]
n0
C451	#energy_storage_limits[888]
n0
C452	#energy_storage_limits[889]
n0
C453	#energy_storage_limits[890]
n0
C454	#energy_storage_limits[891]
n0
C455	#energy_storage_limits[892]
n0
C456	#energy_storage_limits[893]
n0
C457	#energy_storage_limits[894]
n0
C458	#energy_storage_limits[895]
n0
C459	#energy_storage_limits[896]
n0
C460	#energy_storage_limits[897]
n0
C461	#energy_storage_limits[898]
n0
C462	#energy_storage_limits[899]
n0
C463	#energy_storage_limits[900]
n0
C464	#energy_storage_limits[901]
n0
C465	#energy_storage_limits[902]
n0
C466	#energy_storage_limits[903]
n0
C467	#energy_storage_limits[904]
n0
C468	#energy_storage_limits[905]
n0
C469	#energy_storage_limits[906]
n0
C470	#energy_storage_limits[907]
n0
C471	#energy_storage_limits[908]
n0
C472	#energy_storage_limits[909]
n0
C473	#energy_storage_limits[910]
n0
C474	#energy_storage_limits[911]
n0
C475	#energy_storage_limits[912]
n0
C476	#energy_storage_limits[913]
n0
C477	#energy_storage_limits[914]
n0
C478	#energy_storage_limits[915]
n0
C479	#energy_storage_limits[916]
n0
C480	#energy_storage_limits[917]
n0
C481	#energy_storage_limits[918]
n0
C482	#energy_storage_limits[919]
n0
C483	#energy_storage_limits[920]
n0
C484	#energy_storage_limits[921]
n0
C485	#energy_storage_limits[922]
n0
C486	#energy_storage_limits[923]
n0
C487	#energy_storage_limits[924]
n0
C488	#energy_storage_limits[925]
n0
C489	#energy_storage_limits[926]
n0
C490	#energy_storage_limits[927]
n0
C491	#energy_storage_limits[928]
n0
C492	#energy_storage_limits[929]
n0
C493	#energy_storage_limits[930]
n0
C494	#energy_storage_limits[931]
n0
C495	#energy_storage_limits[932]
n0
C496	#energy_storage_limits[933]
n0
C497	#energy_storage_limits[934]
n0
C498	#energy_storage_limits[935]
n0
C499	#energy_storage_limits[936]
n0
C500	#energy_storage_limits[937]
n0
C501	#energy_storage_limits[938]
n0
C502	#energy_storage_limits[939]
n0
C503	#energy_storage_limits[940]
n0
C504	#energy_storage_limits[941]
n0
C505	#energy_storage_limits[942]
n0
C506	#energy_storage_limits[943]
n0
C507	#energy_storage_limits[944]
n0
C508	#energy_storage_limits[945]
n0
C509	#energy_storage_limits[946]
n0
C510	#energy_storage_limits[947]
n0
C511	#energy_storage_limits[948]
n0
C512	#energy_storage_limits[949]
n0
C513	#energy_storage_limits[950]
n0
C514	#energy_storage_limits[951]
n0
C515	#energy_storage_limits[952]
n0
C516	#energy_storage_limits[953]
n0
C517	#energy_storage_limits[954]
n0
C518	#energy_storage_limits[955]
n0
C519	#energy_storage_limits[956]
n0
C520	#energy_storage_limits[957]
n0
C521	#energy_storage_limits[958]
n0
C522	#energy_storage_limits[959]
n0
C523	#energy_storage_limits[960]
n0
C524	#energy_storage_limits[961]
n0
C525	#energy_storage_limits[962]
n0
C526	#energy_storage_limits[963]
n0
C527	#energy_storage_limits[964]
n0
C528	#energy_storage_limits[965]
n0
C529	#energy_storage_limits[966]
n0
C530	#energy_storage_limits[967]
n0
C531	#energy_storage_limits[968]
n0
C532	#energy_storage_limits[969]
n0
C533	#energy_storage_limits[970]
n0
C534	#energy_storage_limits[971]
n0
C535	#energy_storage_limits[972]
n0
C536	#energy_storage_limits[973]
n0
C537	#energy_storage_limits[974]
n0
C538	#energy_storage_limits[975]
n0
C539	#energy_storage_limits[976]
n0
C540	#energy_storage_limits[977]
n0
C541	#energy_storage_limits[978]
n0
C542	#energy_storage_limits[979]
n0
C543	#energy_storage_limits[980]
n0
C544	#energy_storage_limits[981]
n0
C545	#energy_storage_limits[982]
n0
C546	#energy_storage_limits[983]
n0
C547	#energy_storage_limits[984]
n0
C548	#energy_storage_limits[985]
n0
C549	#energy_storage_limits[986]
n0
C550	#energy_storage_limits[987]
n0
C551	#energy_storage_limits[988]
n0
C552	#energy_storage_limits[989]
n0
C553	#energy_storage_limits[990]
n0
C554	#energy_storage_limits[991]
n0
C555	#energy_storage_limits[992]
n0
C556	#energy_storage_limits[993]
n0
C557	#energy_storage_limits[994]
n0
C558	#energy_storage_limits[995]
n0
C559	#energy_storage_limits[996]
n0
C560	#energy_storage_limits[997]
n0
C561	#energy_storage_limits[998]
n0
C562	#energy_storage_limits[999]
n0
C563	#energy_storage_limits[1000]
n0
C564	#energy_storage_limits[1001]
n0
C565	#energy_storage_limits[1002]
n0
C566	#energy_storage_limits[1003]
n0
C567	#energy_storage_limits[1004]
n0
C568	#energy_storage_limits[1005]
n0
C569	#energy_storage_limits[1006]
n0
C570	#energy_storage_limits[1007]
n0
C571	#energy_storage_limits[1008]
n0
C572	#energy_storage_limits[1009]
n0
C573	#energy_storage_limits[1010]
n0
C574	#energy_storage_limits[1011]
n0
C575	#energy_storage_limits[1012]
n0
C576	#energy_storage_limits[1013]
n0
C577	#energy_storage_limits[1014]
n0
C578	#energy_storage_limits[1015]
n0
C579	#energy_storage_limits[1016]
n0
C580	#energy_storage_limits[1017]
n0
C581	#energy_storage_limits[1018]
n0
C582	#energy_storage_limits[1019]
n0
C583	#energy_storage_limits[1020]
n0
C584	#energy_storage_limits[1021]
n0
C585	#energy_storage_limits[1022]
n0
C586	#energy_storage_limits[1023]
n0
C587	#energy_storage_limits[1024]
n0
C588	#energy_storage_limits[1025]
n0
C589	#energy_storage_limits[1026]
n0
C590	#energy_storage_limits[1027]
n0
C591	#energy_storage_limits[1028]
n0
C592	#energy_storage_limits[1029]
n0
C593	#energy_storage_limits[1030]
n0
C594	#energy_storage_limits[1031]
n0
C595	#energy_storage_limits[1032]
n0
C596	#energy_storage_limits[1033]
n0
C597	#energy_storage_limits[1034]
n0
C598	#energy_storage_limits[1035]
n0
C599	#energy_storage_limits[1036]
n0
C600	#energy_storage_limits[1037]
n0
C601	#energy_storage_limits[1038]
n0
C602	#energy_storage_limits[1039]
n0
C603	#energy_storage_limits[1040]
n0
C604	#energy_storage_limits[1041]
n0
C605	#energy_storage_limits[1042]
n0
C606	#energy_storage_limits[1043]
n0
C607	#energy_storage_limits[1044]
n0
C608	#energy_storage_limits[1045]
n0
C609	#energy_storage_limits[1046]
n0
C610	#energy_storage_limits[1047]
n0
C611	#energy_storage_limits[1048]
n0
C612	#energy_storage_limits[1049]
n0
C613	#energy_storage_limits[1050]
n0
C614	#energy_storage_limits[1051]
n0
C615	#energy_storage_limits[1052]
n0
C616	#energy_storage_limits[1053]
n0
C617	#energy_storage_limits[1054]
n0
C618	#energy_storage_limits[1055]
n0
C619	#energy_storage_limits[1056]
n0
C620	#energy_storage_limits[1057]
n0
C621	#energy_storage_limits[1058]
n0
C622	#energy_storage_limits[1059]
n0
C623	#energy_storage_limits[1060]
n0
C624	#energy_storage_limits[1061]
n0
C625	#energy_storage_limits[1062]
n0
C626	#energy_storage_limits[1063]
n0
C627	#energy_storage_limits[1064]
n0
C628	#energy_storage_limits[1065]
n0
C629	#energy_storage_limits[1066]
n0
C630	#energy_storage_limits[1067]
n0
C631	#energy_storage_limits[1068]
n0
C632	#energy_storage_limits[1069]
n0
C633	#energy_storage_limits[1070]
n0
C634	#energy_storage_limits[1071]
n0
C635	#energy_storage_limits[1072]
n0
C636	#energy_storage_limits[1073]
n0
C637	#energy_storage_limits[1074]
n0
C638	#energy_storage_limits[1075]
n0
C639	#energy_storage_limits[1076]
n0
C640	#energy_storage_limits[1077]
n0
C641	#energy_storage_limits[1078]
n0
C642	#energy_storage_limits[1079]
n0
C643	#energy_storage_limits[1080]
n0
C644	#energy_storage_limits[1081]
n0
C645	#energy_storage_limits[1082]
n0
C646	#energy_storage_limits[1083]
n0
C647	#energy_storage_limits[1084]
n0
C648	#energy_storage_limits[1085]
n0
C649	#energy_storage_limits[1086]
n0
C650	#energy_storage_limits[1087]
n0
C651	#energy_storage_limits[1088]
n0
C652	#energy_storage_limits[1089]
n0
C653	#energy_storage_limits[1090]
n0
C654	#energy_storage_limits[1091]
n0
C655	#energy_storage_limits[1092]
n0
C656	#energy_storage_limits[1093]
n0
C657	#energy_storage_limits[1094]
n0
C658	#energy_storage_limits[1095]
n0
C659	#energy_storage_limits[1096]
n0
C660	#energy_storage_limits[1097]
n0
C661	#energy_storage_limits[1098]
n0
C662	#energy_storage_limits[1099]
n0
C663	#energy_storage_limits[1100]
n0
C664	#energy_storage_limits[1101]
n0
C665	#energy_storage_limits[1102]
n0
C666	#energy_storage_limits[1103]
n0
C667	#energy_storage_limits[1104]
n0
C668	#energy_storage_limits[1105]
n0
C669	#energy_storage_limits[1106]
n0
C670	#energy_storage_limits[1107]
n0
C671	#energy_storage_limits[1108]
n0
C672	#energy_storage_limits[1109]
n0
C673	#energy_storage_limits[1110]
n0
C674	#energy_storage_limits[1111]
n0
C675	#energy_storage_limits[1112]
n0
C676	#energy_storage_limits[1113]
n0
C677	#energy_storage_limits[1114]
n0
C678	#energy_storage_limits[1115]
n0
C679	#energy_storage_limits[1116]
n0
C680	#energy_storage_limits[1117]
n0
C681	#energy_storage_limits[1118]
n0
C682	#energy_storage_limits[1119]
n0
C683	#energy_storage_limits[1120]
n0
C684	#energy_storage_limits[1121]
n0
C685	#energy_storage_limits[1122]
n0
C686	#energy_storage_limits[1123]
n0
C687	#energy_storage_limits[1124]
n0
C688	#energy_storage_limits[1125]
n0
C689	#energy_storage_limits[1126]
n0
C690	#energy_storage_limits[1127]
n0
C691	#energy_storage_limits[1128]
n0
C692	#energy_storage_limits[1129]
n0
C693	#energy_storage_limits[1130]
n0
C694	#energy_storage_limits[1131]
n0
C695	#energy_storage_limits[1132]
n0
C696	#energy_storage_limits[1133]
n0
C697	#energy_storage_limits[1134]
n0
C698	#energy_storage_limits[1135]
n0
C699	#energy_storage_limits[1136]
n0
C700	#energy_storage_limits[1137]
n0
C701	#energy_storage_limits[1138]
n0
C702	#energy_storage_limits[1139]
n0
C703	#energy_storage_limits[1140]
n0
C704	#energy_storage_limits[1141]
n0
C705	#energy_storage_limits[1142]
n0
C706	#energy_storage_limits[1143]
n0
C707	#energy_storage_limits[1144]
n0
C708	#energy_storage_limits[1145]
n0
C709	#energy_storage_limits[1146]
n0
C710	#energy_storage_limits[1147]
n0
C711	#energy_storage_limits[1148]
n0
C712	#energy_storage_limits[1149]
n0
C713	#energy_storage_limits[1150]
n0
C714	#energy_storage_limits[1151]
n0
C715	#energy_storage_limits[1152]
n0
C716	#energy_storage_operation_agg[1]
n0
C717	#energy_storage_operation_agg[3]
n0
C718	#energy_storage_operation_agg[5]
n0
C719	#energy_storage_operation_agg[7]
n0
C720	#energy_storage_operation_agg[9]
n0
C721	#energy_storage_operation_agg[11]
n0
C722	#energy_storage_operation_agg[13]
n0
C723	#energy_storage_operation_agg[15]
n0
C724	#energy_storage_operation_agg[17]
n0
C725	#energy_storage_operation_agg[19]
n0
C726	#energy_storage_operation_agg[21]
n0
C727	#energy_storage_operation_agg[23]
n0
C728	#energy_storage_operation_agg[25]
n0
C729	#energy_storage_operation_agg[27]
n0
C730	#energy_storage_operation_agg[29]
n0
C731	#energy_storage_operation_agg[31]
n0
C732	#energy_storage_operation_agg[33]
n0
C733	#energy_storage_operation_agg[35]
n0
C734	#energy_storage_operation_agg[37]
n0
C735	#energy_storage_operation_agg[39]
n0
C736	#energy_storage_operation_agg[41]
n0
C737	#energy_storage_operation_agg[43]
n0
C738	#energy_storage_operation_agg[45]
n0
C739	#energy_storage_operation_agg[47]
n0
C740	#energy_storage_operation_agg[49]
n0
C741	#energy_storage_operation_agg[51]
n0
C742	#energy_storage_operation_agg[53]
n0
C743	#energy_storage_operation_agg[55]
n0
C744	#energy_storage_operation_agg[57]
n0
C745	#energy_storage_operation_agg[59]
n0
C746	#energy_storage_operation_agg[61]
n0
C747	#energy_storage_operation_agg[63]
n0
C748	#energy_storage_operation_agg[65]
n0
C749	#energy_storage_operation_agg[67]
n0
C750	#energy_storage_operation_agg[69]
n0
C751	#energy_storage_operation_agg[71]
n0
C752	#energy_storage_operation_agg[73]
n0
C753	#energy_storage_operation_agg[75]
n0
C754	#energy_storage_operation_agg[77]
n0
C755	#energy_storage_operation_agg[79]
n0
C756	#energy_storage_operation_agg[81]
n0
C757	#energy_storage_operation_agg[83]
n0
C758	#energy_storage_operation_agg[85]
n0
C759	#energy_storage_operation_agg[87]
n0
C760	#energy_storage_operation_agg[89]
n0
C761	#energy_storage_operation_agg[91]
n0
C762	#energy_storage_operation_agg[93]
n0
C763	#energy_storage_operation_agg[95]
n0
C764	#energy_storage_operation_agg[97]
n0
C765	#energy_storage_operation_agg[99]
n0
C766	#energy_storage_operation_agg[101]
n0
C767	#energy_storage_operation_agg[103]
n0
C768	#energy_storage_operation_agg[105]
n0
C769	#energy_storage_operation_agg[107]
n0
C770	#energy_storage_operation_agg[109]
n0
C771	#energy_storage_operation_agg[111]
n0
C772	#energy_storage_operation_agg[113]
n0
C773	#energy_storage_operation_agg[115]
n0
C774	#energy_storage_operation_agg[117]
n0
C775	#energy_storage_operation_agg[119]
n0
C776	#energy_storage_operation_agg[121]
n0
C777	#energy_storage_operation_agg[123]
n0
C778	#energy_storage_operation_agg[125]
n0
C779	#energy_storage_operation_agg[127]
n0
C780	#energy_storage_operation_agg[129]
n0
C781	#energy_storage_operation_agg[131]
n0
C782	#energy_storage_operation_agg[133]
n0
C783	#energy_storage_operation_agg[135]
n0
C784	#energy_storage_operation_agg[137]
n0
C785	#energy_storage_operation_agg[139]
n0
C786	#energy_storage_operation_agg[141]
n0
C787	#energy_storage_operation_agg[143]
n0
C788	#energy_storage_operation_agg[145]
n0
C789	#energy_storage_operation_agg[147]
n0
C790	#energy_storage_operation_agg[149]
n0
C791	#energy_storage_operation_agg[151]
n0
C792	#energy_storage_operation_agg[153]
n0
C793	#energy_storage_operation_agg[155]
n0
C794	#energy_storage_operation_agg[157]
n0
C795	#energy_storage_operation_agg[159]
n0
C796	#energy_storage_operation_agg[161]
n0
C797	#energy_storage_operation_agg[163]
n0
C798	#energy_storage_operation_agg[165]
n0
C799	#energy_storage_operation_agg[167]
n0
C800	#energy_storage_operation_agg[169]
n0
C801	#energy_storage_operation_agg[171]
n0
C802	#energy_storage_operation_agg[173]
n0
C803	#energy_storage_operation_agg[175]
n0
C804	#energy_storage_operation_agg[177]
n0
C805	#energy_storage_operation_agg[179]
n0
C806	#energy_storage_operation_agg[181]
n0
C807	#energy_storage_operation_agg[183]
n0
C808	#energy_storage_operation_agg[185]
n0
C809	#energy_storage_operation_agg[187]
n0
C810	#energy_storage_operation_agg[189]
n0
C811	#energy_storage_operation_agg[191]
n0
C812	#energy_storage_operation_agg[193]
n0
C813	#energy_storage_operation_agg[195]
n0
C814	#energy_storage_operation_agg[197]
n0
C815	#energy_storage_operation_agg[199]
n0
C816	#energy_storage_operation_agg[201]
n0
C817	#energy_storage_operation_agg[203]
n0
C818	#energy_storage_operation_agg[205]
n0
C819	#energy_storage_operation_agg[207]
n0
C820	#energy_storage_operation_agg[209]
n0
C821	#energy_storage_operation_agg[211]
n0
C822	#energy_storage_operation_agg[213]
n0
C823	#energy_storage_operation_agg[215]
n0
C824	#energy_storage_operation_agg[217]
n0
C825	#energy_storage_operation_agg[219]
n0
C826	#energy_storage_operation_agg[221]
n0
C827	#energy_storage_operation_agg[223]
n0
C828	#energy_storage_operation_agg[225]
n0
C829	#energy_storage_operation_agg[227]
n0
C830	#energy_storage_operation_agg[229]
n0
C831	#energy_storage_operation_agg[231]
n0
C832	#energy_storage_operation_agg[233]
n0
C833	#energy_storage_operation_agg[235]
n0
C834	#energy_storage_operation_agg[237]
n0
C835	#energy_storage_operation_agg[239]
n0
C836	#energy_storage_operation_agg[241]
n0
C837	#energy_storage_operation_agg[243]
n0
C838	#energy_storage_operation_agg[245]
n0
C839	#energy_storage_operation_agg[247]
n0
C840	#energy_storage_operation_agg[249]
n0
C841	#energy_storage_operation_agg[251]
n0
C842	#energy_storage_operation_agg[253]
n0
C843	#energy_storage_operation_agg[255]
n0
C844	#energy_storage_operation_agg[257]
n0
C845	#energy_storage_operation_agg[259]
n0
C846	#energy_storage_operation_agg[261]
n0
C847	#energy_storage_operation_agg[263]
n0
C848	#energy_storage_operation_agg[265]
n0
C849	#energy_storage_operation_agg[267]
n0
C850	#energy_storage_operation_agg[269]
n0
C851	#energy_storage_operation_agg[271]
n0
C852	#energy_storage_operation_agg[273]
n0
C853	#energy_storage_operation_agg[275]
n0
C854	#energy_storage_operation_agg[277]
n0
C855	#energy_storage_operation_agg[279]
n0
C856	#energy_storage_operation_agg[281]
n0
C857	#energy_storage_operation_agg[283]
n0
C858	#energy_storage_operation_agg[285]
n0
C859	#energy_storage_operation_agg[287]
n0
C860	#energy_storage_operation_agg[289]
n0
C861	#energy_storage_operation_agg[291]
n0
C862	#energy_storage_operation_agg[293]
n0
C863	#energy_storage_operation_agg[295]
n0
C864	#energy_storage_operation_agg[297]
n0
C865	#energy_storage_operation_agg[299]
n0
C866	#energy_storage_operation_agg[301]
n0
C867	#energy_storage_operation_agg[303]
n0
C868	#energy_storage_operation_agg[305]
n0
C869	#energy_storage_operation_agg[307]
n0
C870	#energy_storage_operation_agg[309]
n0
C871	#energy_storage_operation_agg[311]
n0
C872	#energy_storage_operation_agg[313]
n0
C873	#energy_storage_operation_agg[315]
n0
C874	#energy_storage_operation_agg[317]
n0
C875	#energy_storage_operation_agg[319]
n0
C876	#energy_storage_operation_agg[321]
n0
C877	#energy_storage_operation_agg[323]
n0
C878	#energy_storage_operation_agg[325]
n0
C879	#energy_storage_operation_agg[327]
n0
C880	#energy_storage_operation_agg[329]
n0
C881	#energy_storage_operation_agg[331]
n0
C882	#energy_storage_operation_agg[333]
n0
C883	#energy_storage_operation_agg[335]
n0
C884	#energy_storage_operation_agg[337]
n0
C885	#energy_storage_operation_agg[339]
n0
C886	#energy_storage_operation_agg[341]
n0
C887	#energy_storage_operation_agg[343]
n0
C888	#energy_storage_operation_agg[345]
n0
C889	#energy_storage_operation_agg[347]
n0
C890	#energy_storage_operation_agg[349]
n0
C891	#energy_storage_operation_agg[351]
n0
C892	#energy_storage_operation_agg[353]
n0
C893	#energy_storage_operation_agg[355]
n0
C894	#energy_storage_operation_agg[357]
n0
C895	#energy_storage_operation_agg[359]
n0
C896	#energy_storage_operation_agg[361]
n0
C897	#energy_storage_operation_agg[363]
n0
C898	#energy_storage_operation_agg[365]
n0
C899	#energy_storage_operation_agg[367]
n0
C900	#energy_storage_operation_agg[369]
n0
C901	#energy_storage_operation_agg[371]
n0
C902	#energy_storage_operation_agg[373]
n0
C903	#energy_storage_operation_agg[375]
n0
C904	#energy_storage_operation_agg[377]
n0
C905	#energy_storage_operation_agg[379]
n0
C906	#energy_storage_operation_agg[381]
n0
C907	#energy_storage_operation_agg[383]
n0
C908	#energy_storage_operation_agg[385]
n0
C909	#energy_storage_operation_agg[387]
n0
C910	#energy_storage_operation_agg[389]
n0
C911	#energy_storage_operation_agg[391]
n0
C912	#energy_storage_operation_agg[393]
n0
C913	#energy_storage_operation_agg[395]
n0
C914	#energy_storage_operation_agg[397]
n0
C915	#energy_storage_operation_agg[399]
n0
C916	#energy_storage_operation_agg[401]
n0
C917	#energy_storage_operation_agg[403]
n0
C918	#energy_storage_operation_agg[405]
n0
C919	#energy_storage_operation_agg[407]
n0
C920	#energy_storage_operation_agg[409]
n0
C921	#energy_storage_operation_agg[411]
n0
C922	#energy_storage_operation_agg[413]
n0
C923	#energy_storage_operation_agg[415]
n0
C924	#energy_storage_operation_agg[417]
n0
C925	#energy_storage_operation_agg[419]
n0
C926	#energy_storage_operation_agg[421]
n0
C927	#energy_storage_operation_agg[423]
n0
C928	#energy_storage_operation_agg[425]
n0
C929	#energy_storage_operation_agg[427]
n0
C930	#energy_storage_operation_agg[429]
n0
C931	#energy_storage_operation_agg[431]
n0
C932	#energy_storage_operation_agg[433]
n0
C933	#energy_storage_operation_agg[435]
n0
C934	#energy_storage_operation_agg[437]
n0
C935	#energy_storage_operation_agg[439]
n0
C936	#energy_storage_operation_agg[441]
n0
C937	#energy_storage_operation_agg[443]
n0
C938	#energy_storage_operation_agg[445]
n0
C939	#energy_storage_operation_agg[447]
n0
C940	#energy_storage_operation_agg[449]
n0
C941	#energy_storage_operation_agg[451]
n0
C942	#energy_storage_operation_agg[453]
n0
C943	#energy_storage_operation_agg[455]
n0
C944	#energy_storage_operation_agg[457]
n0
C945	#energy_storage_operation_agg[459]
n0
C946	#energy_storage_operation_agg[461]
n0
C947	#energy_storage_operation_agg[463]
n0
C948	#energy_storage_operation_agg[465]
n0
C949	#energy_storage_operation_agg[467]
n0
C950	#energy_storage_operation_agg[469]
n0
C951	#energy_storage_operation_agg[471]
n0
C952	#energy_storage_operation_agg[473]
n0
C953	#energy_storage_operation_agg[475]
n0
C954	#energy_storage_operation_agg[477]
n0
C955	#energy_storage_operation_agg[479]
n0
C956	#energy_storage_operation_agg[481]
n0
C957	#energy_storage_operation_agg[483]
n0
C958	#energy_storage_operation_agg[485]
n0
C959	#energy_storage_operation_agg[487]
n0
C960	#energy_storage_operation_agg[489]
n0
C961	#energy_storage_operation_agg[491]
n0
C962	#energy_storage_operation_agg[493]
n0
C963	#energy_storage_operation_agg[495]
n0
C964	#energy_storage_operation_agg[497]
n0
C965	#energy_storage_operation_agg[499]
n0
C966	#energy_storage_operation_agg[501]
n0
C967	#energy_storage_operation_agg[503]
n0
C968	#energy_storage_operation_agg[505]
n0
C969	#energy_storage_operation_agg[507]
n0
C970	#energy_storage_operation_agg[509]
n0
C971	#energy_storage_operation_agg[511]
n0
C972	#energy_storage_operation_agg[513]
n0
C973	#energy_storage_operation_agg[515]
n0
C974	#energy_storage_operation_agg[517]
n0
C975	#energy_storage_operation_agg[519]
n0
C976	#energy_storage_operation_agg[521]
n0
C977	#energy_storage_operation_agg[523]
n0
C978	#energy_storage_operation_agg[525]
n0
C979	#energy_storage_operation_agg[527]
n0
C980	#energy_storage_operation_agg[529]
n0
C981	#energy_storage_operation_agg[531]
n0
C982	#energy_storage_operation_agg[533]
n0
C983	#energy_storage_operation_agg[535]
n0
C984	#energy_storage_operation_agg[537]
n0
C985	#energy_storage_operation_agg[539]
n0
C986	#energy_storage_operation_agg[541]
n0
C987	#energy_storage_operation_agg[543]
n0
C988	#energy_storage_operation_agg[545]
n0
C989	#energy_storage_operation_agg[547]
n0
C990	#energy_storage_operation_agg[549]
n0
C991	#energy_storage_operation_agg[551]
n0
C992	#energy_storage_operation_agg[553]
n0
C993	#energy_storage_operation_agg[555]
n0
C994	#energy_storage_operation_agg[557]
n0
C995	#energy_storage_operation_agg[559]
n0
C996	#energy_storage_operation_agg[561]
n0
C997	#energy_storage_operation_agg[563]
n0
C998	#energy_storage_operation_agg[565]
n0
C999	#energy_storage_operation_agg[567]
n0
C1000	#energy_storage_operation_agg[569]
n0
C1001	#energy_storage_operation_agg[571]
n0
C1002	#energy_storage_operation_agg[573]
n0
C1003	#energy_storage_operation_agg[575]
n0
O0 0	#objective
n0.0
x1002	# initial guess
0 0.0	#es_e_rated_per_unit[1,1]
1 0.0	#es_e_rated_per_unit[1,2]
2 0.0	#es_s_rated[0]
3 0.0	#es_s_rated[1]
4 0.0	#es_s_rated[2]
5 1.0	#es_soh_per_unit_cumul[1,1]
6 1.0	#es_soh_per_unit_cumul[1,2]
7 0.0	#es_D_per_unit[1,1]
8 0.0	#es_D_per_unit[1,2]
9 0.0	#slack_es_pnet_up[0,0,0]
10 0.0	#slack_es_pnet_up[0,0,1]
11 0.0	#slack_es_pnet_up[0,0,2]
12 0.0	#slack_es_pnet_up[0,0,3]
13 0.0	#slack_es_pnet_up[0,0,4]
14 0.0	#slack_es_pnet_up[0,0,5]
15 0.0	#slack_es_pnet_up[0,0,6]
16 0.0	#slack_es_pnet_up[0,0,7]
17 0.0	#slack_es_pnet_up[0,0,8]
18 0.0	#slack_es_pnet_up[0,0,9]
19 0.0	#slack_es_pnet_up[0,0,10]
20 0.0	#slack_es_pnet_up[0,0,11]
21 0.0	#slack_es_pnet_up[0,0,12]
22 0.0	#slack_es_pnet_up[0,0,13]
23 0.0	#slack_es_pnet_up[0,0,14]
24 0.0	#slack_es_pnet_up[0,0,15]
25 0.0	#slack_es_pnet_up[0,0,16]
26 0.0	#slack_es_pnet_up[0,0,17]
27 0.0	#slack_es_pnet_up[0,0,18]
28 0.0	#slack_es_pnet_up[0,0,19]
29 0.0	#slack_es_pnet_up[0,0,20]
30 0.0	#slack_es_pnet_up[0,0,21]
31 0.0	#slack_es_pnet_up[0,0,22]
32 0.0	#slack_es_pnet_up[0,0,23]
33 0.0	#slack_es_pnet_up[0,1,0]
34 0.0	#slack_es_pnet_up[0,1,1]
35 0.0	#slack_es_pnet_up[0,1,2]
36 0.0	#slack_es_pnet_up[0,1,3]
37 0.0	#slack_es_pnet_up[0,1,4]
38 0.0	#slack_es_pnet_up[0,1,5]
39 0.0	#slack_es_pnet_up[0,1,6]
40 0.0	#slack_es_pnet_up[0,1,7]
41 0.0	#slack_es_pnet_up[0,1,8]
42 0.0	#slack_es_pnet_up[0,1,9]
43 0.0	#slack_es_pnet_up[0,1,10]
44 0.0	#slack_es_pnet_up[0,1,11]
45 0.0	#slack_es_pnet_up[0,1,12]
46 0.0	#slack_es_pnet_up[0,1,13]
47 0.0	#slack_es_pnet_up[0,1,14]
48 0.0	#slack_es_pnet_up[0,1,15]
49 0.0	#slack_es_pnet_up[0,1,16]
50 0.0	#slack_es_pnet_up[0,1,17]
51 0.0	#slack_es_pnet_up[0,1,18]
52 0.0	#slack_es_pnet_up[0,1,19]
53 0.0	#slack_es_pnet_up[0,1,20]
54 0.0	#slack_es_pnet_up[0,1,21]
55 0.0	#slack_es_pnet_up[0,1,22]
56 0.0	#slack_es_pnet_up[0,1,23]
57 0.0	#slack_es_pnet_up[0,2,0]
58 0.0	#slack_es_pnet_up[0,2,1]
59 0.0	#slack_es_pnet_up[0,2,2]
60 0.0	#slack_es_pnet_up[0,2,3]
61 0.0	#slack_es_pnet_up[0,2,4]
62 0.0	#slack_es_pnet_up[0,2,5]
63 0.0	#slack_es_pnet_up[0,2,6]
64 0.0	#slack_es_pnet_up[0,2,7]
65 0.0	#slack_es_pnet_up[0,2,8]
66 0.0	#slack_es_pnet_up[0,2,9]
67 0.0	#slack_es_pnet_up[0,2,10]
68 0.0	#slack_es_pnet_up[0,2,11]
69 0.0	#slack_es_pnet_up[0,2,12]
70 0.0	#slack_es_pnet_up[0,2,13]
71 0.0	#slack_es_pnet_up[0,2,14]
72 0.0	#slack_es_pnet_up[0,2,15]
73 0.0	#slack_es_pnet_up[0,2,16]
74 0.0	#slack_es_pnet_up[0,2,17]
75 0.0	#slack_es_pnet_up[0,2,18]
76 0.0	#slack_es_pnet_up[0,2,19]
77 0.0	#slack_es_pnet_up[0,2,20]
78 0.0	#slack_es_pnet_up[0,2,21]
79 0.0	#slack_es_pnet_up[0,2,22]
80 0.0	#slack_es_pnet_up[0,2,23]
81 0.0	#slack_es_pnet_up[0,3,0]
82 0.0	#slack_es_pnet_up[0,3,1]
83 0.0	#slack_es_pnet_up[0,3,2]
84 0.0	#slack_es_pnet_up[0,3,3]
85 0.0	#slack_es_pnet_up[0,3,4]
86 0.0	#slack_es_pnet_up[0,3,5]
87 0.0	#slack_es_pnet_up[0,3,6]
88 0.0	#slack_es_pnet_up[0,3,7]
89 0.0	#slack_es_pnet_up[0,3,8]
90 0.0	#slack_es_pnet_up[0,3,9]
91 0.0	#slack_es_pnet_up[0,3,10]
92 0.0	#slack_es_pnet_up[0,3,11]
93 0.0	#slack_es_pnet_up[0,3,12]
94 0.0	#slack_es_pnet_up[0,3,13]
95 0.0	#slack_es_pnet_up[0,3,14]
96 0.0	#slack_es_pnet_up[0,3,15]
97 0.0	#slack_es_pnet_up[0,3,16]
98 0.0	#slack_es_pnet_up[0,3,17]
99 0.0	#slack_es_pnet_up[0,3,18]
100 0.0	#slack_es_pnet_up[0,3,19]
101 0.0	#slack_es_pnet_up[0,3,20]
102 0.0	#slack_es_pnet_up[0,3,21]
103 0.0	#slack_es_pnet_up[0,3,22]
104 0.0	#slack_es_pnet_up[0,3,23]
105 0.0	#slack_es_pnet_up[1,0,0]
106 0.0	#slack_es_pnet_up[1,0,1]
107 0.0	#slack_es_pnet_up[1,0,2]
108 0.0	#slack_es_pnet_up[1,0,3]
109 0.0	#slack_es_pnet_up[1,0,4]
110 0.0	#slack_es_pnet_up[1,0,5]
111 0.0	#slack_es_pnet_up[1,0,6]
112 0.0	#slack_es_pnet_up[1,0,7]
113 0.0	#slack_es_pnet_up[1,0,8]
114 0.0	#slack_es_pnet_up[1,0,9]
115 0.0	#slack_es_pnet_up[1,0,10]
116 0.0	#slack_es_pnet_up[1,0,11]
117 0.0	#slack_es_pnet_up[1,0,12]
118 0.0	#slack_es_pnet_up[1,0,13]
119 0.0	#slack_es_pnet_up[1,0,14]
120 0.0	#slack_es_pnet_up[1,0,15]
121 0.0	#slack_es_pnet_up[1,0,16]
122 0.0	#slack_es_pnet_up[1,0,17]
123 0.0	#slack_es_pnet_up[1,0,18]
124 0.0	#slack_es_pnet_up[1,0,19]
125 0.0	#slack_es_pnet_up[1,0,20]
126 0.0	#slack_es_pnet_up[1,0,21]
127 0.0	#slack_es_pnet_up[1,0,22]
128 0.0	#slack_es_pnet_up[1,0,23]
129 0.0	#slack_es_pnet_up[1,1,0]
130 0.0	#slack_es_pnet_up[1,1,1]
131 0.0	#slack_es_pnet_up[1,1,2]
132 0.0	#slack_es_pnet_up[1,1,3]
133 0.0	#slack_es_pnet_up[1,1,4]
134 0.0	#slack_es_pnet_up[1,1,5]
135 0.0	#slack_es_pnet_up[1,1,6]
136 0.0	#slack_es_pnet_up[1,1,7]
137 0.0	#slack_es_pnet_up[1,1,8]
138 0.0	#slack_es_pnet_up[1,1,9]
139 0.0	#slack_es_pnet_up[1,1,10]
140 0.0	#slack_es_pnet_up[1,1,11]
141 0.0	#slack_es_pnet_up[1,1,12]
142 0.0	#slack_es_pnet_up[1,1,13]
143 0.0	#slack_es_pnet_up[1,1,14]
144 0.0	#slack_es_pnet_up[1,1,15]
145 0.0	#slack_es_pnet_up[1,1,16]
146 0.0	#slack_es_pnet_up[1,1,17]
147 0.0	#slack_es_pnet_up[1,1,18]
148 0.0	#slack_es_pnet_up[1,1,19]
149 0.0	#slack_es_pnet_up[1,1,20]
150 0.0	#slack_es_pnet_up[1,1,21]
151 0.0	#slack_es_pnet_up[1,1,22]
152 0.0	#slack_es_pnet_up[1,1,23]
153 0.0	#slack_es_pnet_up[1,2,0]
154 0.0	#slack_es_pnet_up[1,2,1]
155 0.0	#slack_es_pnet_up[1,2,2]
156 0.0	#slack_es_pnet_up[1,2,3]
157 0.0	#slack_es_pnet_up[1,2,4]
158 0.0	#slack_es_pnet_up[1,2,5]
159 0.0	#slack_es_pnet_up[1,2,6]
160 0.0	#slack_es_pnet_up[1,2,7]
161 0.0	#slack_es_pnet_up[1,2,8]
162 0.0	#slack_es_pnet_up[1,2,9]
163 0.0	#slack_es_pnet_up[1,2,10]
164 0.0	#slack_es_pnet_up[1,2,11]
165 0.0	#slack_es_pnet_up[1,2,12]
166 0.0	#slack_es_pnet_up[1,2,13]
167 0.0	#slack_es_pnet_up[1,2,14]
168 0.0	#slack_es_pnet_up[1,2,15]
169 0.0	#slack_es_pnet_up[1,2,16]
170 0.0	#slack_es_pnet_up[1,2,17]
171 0.0	#slack_es_pnet_up[1,2,18]
172 0.0	#slack_es_pnet_up[1,2,19]
173 0.0	#slack_es_pnet_up[1,2,20]
174 0.0	#slack_es_pnet_up[1,2,21]
175 0.0	#slack_es_pnet_up[1,2,22]
176 0.0	#slack_es_pnet_up[1,2,23]
177 0.0	#slack_es_pnet_up[1,3,0]
178 0.0	#slack_es_pnet_up[1,3,1]
179 0.0	#slack_es_pnet_up[1,3,2]
180 0.0	#slack_es_pnet_up[1,3,3]
181 0.0	#slack_es_pnet_up[1,3,4]
182 0.0	#slack_es_pnet_up[1,3,5]
183 0.0	#slack_es_pnet_up[1,3,6]
184 0.0	#slack_es_pnet_up[1,3,7]
185 0.0	#slack_es_pnet_up[1,3,8]
186 0.0	#slack_es_pnet_up[1,3,9]
187 0.0	#slack_es_pnet_up[1,3,10]
188 0.0	#slack_es_pnet_up[1,3,11]
189 0.0	#slack_es_pnet_up[1,3,12]
190 0.0	#slack_es_pnet_up[1,3,13]
191 0.0	#slack_es_pnet_up[1,3,14]
192 0.0	#slack_es_pnet_up[1,3,15]
193 0.0	#slack_es_pnet_up[1,3,16]
194 0.0	#slack_es_pnet_up[1,3,17]
195 0.0	#slack_es_pnet_up[1,3,18]
196 0.0	#slack_es_pnet_up[1,3,19]
197 0.0	#slack_es_pnet_up[1,3,20]
198 0.0	#slack_es_pnet_up[1,3,21]
199 0.0	#slack_es_pnet_up[1,3,22]
200 0.0	#slack_es_pnet_up[1,3,23]
201 0.0	#slack_es_pnet_up[2,0,0]
202 0.0	#slack_es_pnet_up[2,0,1]
203 0.0	#slack_es_pnet_up[2,0,2]
204 0.0	#slack_es_pnet_up[2,0,3]
205 0.0	#slack_es_pnet_up[2,0,4]
206 0.0	#slack_es_pnet_up[2,0,5]
207 0.0	#slack_es_pnet_up[2,0,6]
208 0.0	#slack_es_pnet_up[2,0,7]
209 0.0	#slack_es_pnet_up[2,0,8]
210 0.0	#slack_es_pnet_up[2,0,9]
211 0.0	#slack_es_pnet_up[2,0,10]
212 0.0	#slack_es_pnet_up[2,0,11]
213 0.0	#slack_es_pnet_up[2,0,12]
214 0.0	#slack_es_pnet_up[2,0,13]
215 0.0	#slack_es_pnet_up[2,0,14]
216 0.0	#slack_es_pnet_up[2,0,15]
217 0.0	#slack_es_pnet_up[2,0,16]
218 0.0	#slack_es_pnet_up[2,0,17]
219 0.0	#slack_es_pnet_up[2,0,18]
220 0.0	#slack_es_pnet_up[2,0,19]
221 0.0	#slack_es_pnet_up[2,0,20]
222 0.0	#slack_es_pnet_up[2,0,21]
223 0.0	#slack_es_pnet_up[2,0,22]
224 0.0	#slack_es_pnet_up[2,0,23]
225 0.0	#slack_es_pnet_up[2,1,0]
226 0.0	#slack_es_pnet_up[2,1,1]
227 0.0	#slack_es_pnet_up[2,1,2]
228 0.0	#slack_es_pnet_up[2,1,3]
229 0.0	#slack_es_pnet_up[2,1,4]
230 0.0	#slack_es_pnet_up[2,1,5]
231 0.0	#slack_es_pnet_up[2,1,6]
232 0.0	#slack_es_pnet_up[2,1,7]
233 0.0	#slack_es_pnet_up[2,1,8]
234 0.0	#slack_es_pnet_up[2,1,9]
235 0.0	#slack_es_pnet_up[2,1,10]
236 0.0	#slack_es_pnet_up[2,1,11]
237 0.0	#slack_es_pnet_up[2,1,12]
238 0.0	#slack_es_pnet_up[2,1,13]
239 0.0	#slack_es_pnet_up[2,1,14]
240 0.0	#slack_es_pnet_up[2,1,15]
241 0.0	#slack_es_pnet_up[2,1,16]
242 0.0	#slack_es_pnet_up[2,1,17]
243 0.0	#slack_es_pnet_up[2,1,18]
244 0.0	#slack_es_pnet_up[2,1,19]
245 0.0	#slack_es_pnet_up[2,1,20]
246 0.0	#slack_es_pnet_up[2,1,21]
247 0.0	#slack_es_pnet_up[2,1,22]
248 0.0	#slack_es_pnet_up[2,1,23]
249 0.0	#slack_es_pnet_up[2,2,0]
250 0.0	#slack_es_pnet_up[2,2,1]
251 0.0	#slack_es_pnet_up[2,2,2]
252 0.0	#slack_es_pnet_up[2,2,3]
253 0.0	#slack_es_pnet_up[2,2,4]
254 0.0	#slack_es_pnet_up[2,2,5]
255 0.0	#slack_es_pnet_up[2,2,6]
256 0.0	#slack_es_pnet_up[2,2,7]
257 0.0	#slack_es_pnet_up[2,2,8]
258 0.0	#slack_es_pnet_up[2,2,9]
259 0.0	#slack_es_pnet_up[2,2,10]
260 0.0	#slack_es_pnet_up[2,2,11]
261 0.0	#slack_es_pnet_up[2,2,12]
262 0.0	#slack_es_pnet_up[2,2,13]
263 0.0	#slack_es_pnet_up[2,2,14]
264 0.0	#slack_es_pnet_up[2,2,15]
265 0.0	#slack_es_pnet_up[2,2,16]
266 0.0	#slack_es_pnet_up[2,2,17]
267 0.0	#slack_es_pnet_up[2,2,18]
268 0.0	#slack_es_pnet_up[2,2,19]
269 0.0	#slack_es_pnet_up[2,2,20]
270 0.0	#slack_es_pnet_up[2,2,21]
271 0.0	#slack_es_pnet_up[2,2,22]
272 0.0	#slack_es_pnet_up[2,2,23]
273 0.0	#slack_es_pnet_up[2,3,0]
274 0.0	#slack_es_pnet_up[2,3,1]
275 0.0	#slack_es_pnet_up[2,3,2]
276 0.0	#slack_es_pnet_up[2,3,3]
277 0.0	#slack_es_pnet_up[2,3,4]
278 0.0	#slack_es_pnet_up[2,3,5]
279 0.0	#slack_es_pnet_up[2,3,6]
280 0.0	#slack_es_pnet_up[2,3,7]
281 0.0	#slack_es_pnet_up[2,3,8]
282 0.0	#slack_es_pnet_up[2,3,9]
283 0.0	#slack_es_pnet_up[2,3,10]
284 0.0	#slack_es_pnet_up[2,3,11]
285 0.0	#slack_es_pnet_up[2,3,12]
286 0.0	#slack_es_pnet_up[2,3,13]
287 0.0	#slack_es_pnet_up[2,3,14]
288 0.0	#slack_es_pnet_up[2,3,15]
289 0.0	#slack_es_pnet_up[2,3,16]
290 0.0	#slack_es_pnet_up[2,3,17]
291 0.0	#slack_es_pnet_up[2,3,18]
292 0.0	#slack_es_pnet_up[2,3,19]
293 0.0	#slack_es_pnet_up[2,3,20]
294 0.0	#slack_es_pnet_up[2,3,21]
295 0.0	#slack_es_pnet_up[2,3,22]
296 0.0	#slack_es_pnet_up[2,3,23]
297 0.0	#slack_es_pnet_down[0,0,0]
298 0.0	#slack_es_pnet_down[0,0,1]
299 0.0	#slack_es_pnet_down[0,0,2]
300 0.0	#slack_es_pnet_down[0,0,3]
301 0.0	#slack_es_pnet_down[0,0,4]
302 0.0	#slack_es_pnet_down[0,0,5]
303 0.0	#slack_es_pnet_down[0,0,6]
304 0.0	#slack_es_pnet_down[0,0,7]
305 0.0	#slack_es_pnet_down[0,0,8]
306 0.0	#slack_es_pnet_down[0,0,9]
307 0.0	#slack_es_pnet_down[0,0,10]
308 0.0	#slack_es_pnet_down[0,0,11]
309 0.0	#slack_es_pnet_down[0,0,12]
310 0.0	#slack_es_pnet_down[0,0,13]
311 0.0	#slack_es_pnet_down[0,0,14]
312 0.0	#slack_es_pnet_down[0,0,15]
313 0.0	#slack_es_pnet_down[0,0,16]
314 0.0	#slack_es_pnet_down[0,0,17]
315 0.0	#slack_es_pnet_down[0,0,18]
316 0.0	#slack_es_pnet_down[0,0,19]
317 0.0	#slack_es_pnet_down[0,0,20]
318 0.0	#slack_es_pnet_down[0,0,21]
319 0.0	#slack_es_pnet_down[0,0,22]
320 0.0	#slack_es_pnet_down[0,0,23]
321 0.0	#slack_es_pnet_down[0,1,0]
322 0.0	#slack_es_pnet_down[0,1,1]
323 0.0	#slack_es_pnet_down[0,1,2]
324 0.0	#slack_es_pnet_down[0,1,3]
325 0.0	#slack_es_pnet_down[0,1,4]
326 0.0	#slack_es_pnet_down[0,1,5]
327 0.0	#slack_es_pnet_down[0,1,6]
328 0.0	#slack_es_pnet_down[0,1,7]
329 0.0	#slack_es_pnet_down[0,1,8]
330 0.0	#slack_es_pnet_down[0,1,9]
331 0.0	#slack_es_pnet_down[0,1,10]
332 0.0	#slack_es_pnet_down[0,1,11]
333 0.0	#slack_es_pnet_down[0,1,12]
334 0.0	#slack_es_pnet_down[0,1,13]
335 0.0	#slack_es_pnet_down[0,1,14]
336 0.0	#slack_es_pnet_down[0,1,15]
337 0.0	#slack_es_pnet_down[0,1,16]
338 0.0	#slack_es_pnet_down[0,1,17]
339 0.0	#slack_es_pnet_down[0,1,18]
340 0.0	#slack_es_pnet_down[0,1,19]
341 0.0	#slack_es_pnet_down[0,1,20]
342 0.0	#slack_es_pnet_down[0,1,21]
343 0.0	#slack_es_pnet_down[0,1,22]
344 0.0	#slack_es_pnet_down[0,1,23]
345 0.0	#slack_es_pnet_down[0,2,0]
346 0.0	#slack_es_pnet_down[0,2,1]
347 0.0	#slack_es_pnet_down[0,2,2]
348 0.0	#slack_es_pnet_down[0,2,3]
349 0.0	#slack_es_pnet_down[0,2,4]
350 0.0	#slack_es_pnet_down[0,2,5]
351 0.0	#slack_es_pnet_down[0,2,6]
352 0.0	#slack_es_pnet_down[0,2,7]
353 0.0	#slack_es_pnet_down[0,2,8]
354 0.0	#slack_es_pnet_down[0,2,9]
355 0.0	#slack_es_pnet_down[0,2,10]
356 0.0	#slack_es_pnet_down[0,2,11]
357 0.0	#slack_es_pnet_down[0,2,12]
358 0.0	#slack_es_pnet_down[0,2,13]
359 0.0	#slack_es_pnet_down[0,2,14]
360 0.0	#slack_es_pnet_down[0,2,15]
361 0.0	#slack_es_pnet_down[0,2,16]
362 0.0	#slack_es_pnet_down[0,2,17]
363 0.0	#slack_es_pnet_down[0,2,18]
364 0.0	#slack_es_pnet_down[0,2,19]
365 0.0	#slack_es_pnet_down[0,2,20]
366 0.0	#slack_es_pnet_down[0,2,21]
367 0.0	#slack_es_pnet_down[0,2,22]
368 0.0	#slack_es_pnet_down[0,2,23]
369 0.0	#slack_es_pnet_down[0,3,0]
370 0.0	#slack_es_pnet_down[0,3,1]
371 0.0	#slack_es_pnet_down[0,3,2]
372 0.0	#slack_es_pnet_down[0,3,3]
373 0.0	#slack_es_pnet_down[0,3,4]
374 0.0	#slack_es_pnet_down[0,3,5]
375 0.0	#slack_es_pnet_down[0,3,6]
376 0.0	#slack_es_pnet_down[0,3,7]
377 0.0	#slack_es_pnet_down[0,3,8]
378 0.0	#slack_es_pnet_down[0,3,9]
379 0.0	#slack_es_pnet_down[0,3,10]
380 0.0	#slack_es_pnet_down[0,3,11]
381 0.0	#slack_es_pnet_down[0,3,12]
382 0.0	#slack_es_pnet_down[0,3,13]
383 0.0	#slack_es_pnet_down[0,3,14]
384 0.0	#slack_es_pnet_down[0,3,15]
385 0.0	#slack_es_pnet_down[0,3,16]
386 0.0	#slack_es_pnet_down[0,3,17]
387 0.0	#slack_es_pnet_down[0,3,18]
388 0.0	#slack_es_pnet_down[0,3,19]
389 0.0	#slack_es_pnet_down[0,3,20]
390 0.0	#slack_es_pnet_down[0,3,21]
391 0.0	#slack_es_pnet_down[0,3,22]
392 0.0	#slack_es_pnet_down[0,3,23]
393 0.0	#slack_es_pnet_down[1,0,0]
394 0.0	#slack_es_pnet_down[1,0,1]
395 0.0	#slack_es_pnet_down[1,0,2]
396 0.0	#slack_es_pnet_down[1,0,3]
397 0.0	#slack_es_pnet_down[1,0,4]
398 0.0	#slack_es_pnet_down[1,0,5]
399 0.0	#slack_es_pnet_down[1,0,6]
400 0.0	#slack_es_pnet_down[1,0,7]
401 0.0	#slack_es_pnet_down[1,0,8]
402 0.0	#slack_es_pnet_down[1,0,9]
403 0.0	#slack_es_pnet_down[1,0,10]
404 0.0	#slack_es_pnet_down[1,0,11]
405 0.0	#slack_es_pnet_down[1,0,12]
406 0.0	#slack_es_pnet_down[1,0,13]
407 0.0	#slack_es_pnet_down[1,0,14]
408 0.0	#slack_es_pnet_down[1,0,15]
409 0.0	#slack_es_pnet_down[1,0,16]
410 0.0	#slack_es_pnet_down[1,0,17]
411 0.0	#slack_es_pnet_down[1,0,18]
412 0.0	#slack_es_pnet_down[1,0,19]
413 0.0	#slack_es_pnet_down[1,0,20]
414 0.0	#slack_es_pnet_down[1,0,21]
415 0.0	#slack_es_pnet_down[1,0,22]
416 0.0	#slack_es_pnet_down[1,0,23]
417 0.0	#slack_es_pnet_down[1,1,0]
418 0.0	#slack_es_pnet_down[1,1,1]
419 0.0	#slack_es_pnet_down[1,1,2]
420 0.0	#slack_es_pnet_down[1,1,3]
421 0.0	#slack_es_pnet_down[1,1,4]
422 0.0	#slack_es_pnet_down[1,1,5]
423 0.0	#slack_es_pnet_down[1,1,6]
424 0.0	#slack_es_pnet_down[1,1,7]
425 0.0	#slack_es_pnet_down[1,1,8]
426 0.0	#slack_es_pnet_down[1,1,9]
427 0.0	#slack_es_pnet_down[1,1,10]
428 0.0	#slack_es_pnet_down[1,1,11]
429 0.0	#slack_es_pnet_down[1,1,12]
430 0.0	#slack_es_pnet_down[1,1,13]
431 0.0	#slack_es_pnet_down[1,1,14]
432 0.0	#slack_es_pnet_down[1,1,15]
433 0.0	#slack_es_pnet_down[1,1,16]
434 0.0	#slack_es_pnet_down[1,1,17]
435 0.0	#slack_es_pnet_down[1,1,18]
436 0.0	#slack_es_pnet_down[1,1,19]
437 0.0	#slack_es_pnet_down[1,1,20]
438 0.0	#slack_es_pnet_down[1,1,21]
439 0.0	#slack_es_pnet_down[1,1,22]
440 0.0	#slack_es_pnet_down[1,1,23]
441 0.0	#slack_es_pnet_down[1,2,0]
442 0.0	#slack_es_pnet_down[1,2,1]
443 0.0	#slack_es_pnet_down[1,2,2]
444 0.0	#slack_es_pnet_down[1,2,3]
445 0.0	#slack_es_pnet_down[1,2,4]
446 0.0	#slack_es_pnet_down[1,2,5]
447 0.0	#slack_es_pnet_down[1,2,6]
448 0.0	#slack_es_pnet_down[1,2,7]
449 0.0	#slack_es_pnet_down[1,2,8]
450 0.0	#slack_es_pnet_down[1,2,9]
451 0.0	#slack_es_pnet_down[1,2,10]
452 0.0	#slack_es_pnet_down[1,2,11]
453 0.0	#slack_es_pnet_down[1,2,12]
454 0.0	#slack_es_pnet_down[1,2,13]
455 0.0	#slack_es_pnet_down[1,2,14]
456 0.0	#slack_es_pnet_down[1,2,15]
457 0.0	#slack_es_pnet_down[1,2,16]
458 0.0	#slack_es_pnet_down[1,2,17]
459 0.0	#slack_es_pnet_down[1,2,18]
460 0.0	#slack_es_pnet_down[1,2,19]
461 0.0	#slack_es_pnet_down[1,2,20]
462 0.0	#slack_es_pnet_down[1,2,21]
463 0.0	#slack_es_pnet_down[1,2,22]
464 0.0	#slack_es_pnet_down[1,2,23]
465 0.0	#slack_es_pnet_down[1,3,0]
466 0.0	#slack_es_pnet_down[1,3,1]
467 0.0	#slack_es_pnet_down[1,3,2]
468 0.0	#slack_es_pnet_down[1,3,3]
469 0.0	#slack_es_pnet_down[1,3,4]
470 0.0	#slack_es_pnet_down[1,3,5]
471 0.0	#slack_es_pnet_down[1,3,6]
472 0.0	#slack_es_pnet_down[1,3,7]
473 0.0	#slack_es_pnet_down[1,3,8]
474 0.0	#slack_es_pnet_down[1,3,9]
475 0.0	#slack_es_pnet_down[1,3,10]
476 0.0	#slack_es_pnet_down[1,3,11]
477 0.0	#slack_es_pnet_down[1,3,12]
478 0.0	#slack_es_pnet_down[1,3,13]
479 0.0	#slack_es_pnet_down[1,3,14]
480 0.0	#slack_es_pnet_down[1,3,15]
481 0.0	#slack_es_pnet_down[1,3,16]
482 0.0	#slack_es_pnet_down[1,3,17]
483 0.0	#slack_es_pnet_down[1,3,18]
484 0.0	#slack_es_pnet_down[1,3,19]
485 0.0	#slack_es_pnet_down[1,3,20]
486 0.0	#slack_es_pnet_down[1,3,21]
487 0.0	#slack_es_pnet_down[1,3,22]
488 0.0	#slack_es_pnet_down[1,3,23]
489 0.0	#slack_es_pnet_down[2,0,0]
490 0.0	#slack_es_pnet_down[2,0,1]
491 0.0	#slack_es_pnet_down[2,0,2]
492 0.0	#slack_es_pnet_down[2,0,3]
493 0.0	#slack_es_pnet_down[2,0,4]
494 0.0	#slack_es_pnet_down[2,0,5]
495 0.0	#slack_es_pnet_down[2,0,6]
496 0.0	#slack_es_pnet_down[2,0,7]
497 0.0	#slack_es_pnet_down[2,0,8]
498 0.0	#slack_es_pnet_down[2,0,9]
499 0.0	#slack_es_pnet_down[2,0,10]
500 0.0	#slack_es_pnet_down[2,0,11]
501 0.0	#slack_es_pnet_down[2,0,12]
502 0.0	#slack_es_pnet_down[2,0,13]
503 0.0	#slack_es_pnet_down[2,0,14]
504 0.0	#slack_es_pnet_down[2,0,15]
505 0.0	#slack_es_pnet_down[2,0,16]
506 0.0	#slack_es_pnet_down[2,0,17]
507 0.0	#slack_es_pnet_down[2,0,18]
508 0.0	#slack_es_pnet_down[2,0,19]
509 0.0	#slack_es_pnet_down[2,0,20]
510 0.0	#slack_es_pnet_down[2,0,21]
511 0.0	#slack_es_pnet_down[2,0,22]
512 0.0	#slack_es_pnet_down[2,0,23]
513 0.0	#slack_es_pnet_down[2,1,0]
514 0.0	#slack_es_pnet_down[2,1,1]
515 0.0	#slack_es_pnet_down[2,1,2]
516 0.0	#slack_es_pnet_down[2,1,3]
517 0.0	#slack_es_pnet_down[2,1,4]
518 0.0	#slack_es_pnet_down[2,1,5]
519 0.0	#slack_es_pnet_down[2,1,6]
520 0.0	#slack_es_pnet_down[2,1,7]
521 0.0	#slack_es_pnet_down[2,1,8]
522 0.0	#slack_es_pnet_down[2,1,9]
523 0.0	#slack_es_pnet_down[2,1,10]
524 0.0	#slack_es_pnet_down[2,1,11]
525 0.0	#slack_es_pnet_down[2,1,12]
526 0.0	#slack_es_pnet_down[2,1,13]
527 0.0	#slack_es_pnet_down[2,1,14]
528 0.0	#slack_es_pnet_down[2,1,15]
529 0.0	#slack_es_pnet_down[2,1,16]
530 0.0	#slack_es_pnet_down[2,1,17]
531 0.0	#slack_es_pnet_down[2,1,18]
532 0.0	#slack_es_pnet_down[2,1,19]
533 0.0	#slack_es_pnet_down[2,1,20]
534 0.0	#slack_es_pnet_down[2,1,21]
535 0.0	#slack_es_pnet_down[2,1,22]
536 0.0	#slack_es_pnet_down[2,1,23]
537 0.0	#slack_es_pnet_down[2,2,0]
538 0.0	#slack_es_pnet_down[2,2,1]
539 0.0	#slack_es_pnet_down[2,2,2]
540 0.0	#slack_es_pnet_down[2,2,3]
541 0.0	#slack_es_pnet_down[2,2,4]
542 0.0	#slack_es_pnet_down[2,2,5]
543 0.0	#slack_es_pnet_down[2,2,6]
544 0.0	#slack_es_pnet_down[2,2,7]
545 0.0	#slack_es_pnet_down[2,2,8]
546 0.0	#slack_es_pnet_down[2,2,9]
547 0.0	#slack_es_pnet_down[2,2,10]
548 0.0	#slack_es_pnet_down[2,2,11]
549 0.0	#slack_es_pnet_down[2,2,12]
550 0.0	#slack_es_pnet_down[2,2,13]
551 0.0	#slack_es_pnet_down[2,2,14]
552 0.0	#slack_es_pnet_down[2,2,15]
553 0.0	#slack_es_pnet_down[2,2,16]
554 0.0	#slack_es_pnet_down[2,2,17]
555 0.0	#slack_es_pnet_down[2,2,18]
556 0.0	#slack_es_pnet_down[2,2,19]
557 0.0	#slack_es_pnet_down[2,2,20]
558 0.0	#slack_es_pnet_down[2,2,21]
559 0.0	#slack_es_pnet_down[2,2,22]
560 0.0	#slack_es_pnet_down[2,2,23]
561 0.0	#slack_es_pnet_down[2,3,0]
562 0.0	#slack_es_pnet_down[2,3,1]
563 0.0	#slack_es_pnet_down[2,3,2]
564 0.0	#slack_es_pnet_down[2,3,3]
565 0.0	#slack_es_pnet_down[2,3,4]
566 0.0	#slack_es_pnet_down[2,3,5]
567 0.0	#slack_es_pnet_down[2,3,6]
568 0.0	#slack_es_pnet_down[2,3,7]
569 0.0	#slack_es_pnet_down[2,3,8]
570 0.0	#slack_es_pnet_down[2,3,9]
571 0.0	#slack_es_pnet_down[2,3,10]
572 0.0	#slack_es_pnet_down[2,3,11]
573 0.0	#slack_es_pnet_down[2,3,12]
574 0.0	#slack_es_pnet_down[2,3,13]
575 0.0	#slack_es_pnet_down[2,3,14]
576 0.0	#slack_es_pnet_down[2,3,15]
577 0.0	#slack_es_pnet_down[2,3,16]
578 0.0	#slack_es_pnet_down[2,3,17]
579 0.0	#slack_es_pnet_down[2,3,18]
580 0.0	#slack_es_pnet_down[2,3,19]
581 0.0	#slack_es_pnet_down[2,3,20]
582 0.0	#slack_es_pnet_down[2,3,21]
583 0.0	#slack_es_pnet_down[2,3,22]
584 0.0	#slack_es_pnet_down[2,3,23]
585 0.0	#es_pch_per_unit[1,1,0,0]
586 0.0	#es_pch_per_unit[1,1,0,1]
587 0.0	#es_pch_per_unit[1,1,0,2]
588 0.0	#es_pch_per_unit[1,1,0,3]
589 0.0	#es_pch_per_unit[1,1,0,4]
590 0.0	#es_pch_per_unit[1,1,0,5]
591 0.0	#es_pch_per_unit[1,1,0,6]
592 0.0	#es_pch_per_unit[1,1,0,7]
593 0.0	#es_pch_per_unit[1,1,0,8]
594 0.0	#es_pch_per_unit[1,1,0,9]
595 0.0	#es_pch_per_unit[1,1,0,10]
596 0.0	#es_pch_per_unit[1,1,0,11]
597 0.0	#es_pch_per_unit[1,1,0,12]
598 0.0	#es_pch_per_unit[1,1,0,13]
599 0.0	#es_pch_per_unit[1,1,0,14]
600 0.0	#es_pch_per_unit[1,1,0,15]
601 0.0	#es_pch_per_unit[1,1,0,16]
602 0.0	#es_pch_per_unit[1,1,0,17]
603 0.0	#es_pch_per_unit[1,1,0,18]
604 0.0	#es_pch_per_unit[1,1,0,19]
605 0.0	#es_pch_per_unit[1,1,0,20]
606 0.0	#es_pch_per_unit[1,1,0,21]
607 0.0	#es_pch_per_unit[1,1,0,22]
608 0.0	#es_pch_per_unit[1,1,0,23]
609 0.0	#es_pch_per_unit[1,1,1,0]
610 0.0	#es_pch_per_unit[1,1,1,1]
611 0.0	#es_pch_per_unit[1,1,1,2]
612 0.0	#es_pch_per_unit[1,1,1,3]
613 0.0	#es_pch_per_unit[1,1,1,4]
614 0.0	#es_pch_per_unit[1,1,1,5]
615 0.0	#es_pch_per_unit[1,1,1,6]
616 0.0	#es_pch_per_unit[1,1,1,7]
617 0.0	#es_pch_per_unit[1,1,1,8]
618 0.0	#es_pch_per_unit[1,1,1,9]
619 0.0	#es_pch_per_unit[1,1,1,10]
620 0.0	#es_pch_per_unit[1,1,1,11]
621 0.0	#es_pch_per_unit[1,1,1,12]
622 0.0	#es_pch_per_unit[1,1,1,13]
623 0.0	#es_pch_per_unit[1,1,1,14]
624 0.0	#es_pch_per_unit[1,1,1,15]
625 0.0	#es_pch_per_unit[1,1,1,16]
626 0.0	#es_pch_per_unit[1,1,1,17]
627 0.0	#es_pch_per_unit[1,1,1,18]
628 0.0	#es_pch_per_unit[1,1,1,19]
629 0.0	#es_pch_per_unit[1,1,1,20]
630 0.0	#es_pch_per_unit[1,1,1,21]
631 0.0	#es_pch_per_unit[1,1,1,22]
632 0.0	#es_pch_per_unit[1,1,1,23]
633 0.0	#es_pch_per_unit[1,1,2,0]
634 0.0	#es_pch_per_unit[1,1,2,1]
635 0.0	#es_pch_per_unit[1,1,2,2]
636 0.0	#es_pch_per_unit[1,1,2,3]
637 0.0	#es_pch_per_unit[1,1,2,4]
638 0.0	#es_pch_per_unit[1,1,2,5]
639 0.0	#es_pch_per_unit[1,1,2,6]
640 0.0	#es_pch_per_unit[1,1,2,7]
641 0.0	#es_pch_per_unit[1,1,2,8]
642 0.0	#es_pch_per_unit[1,1,2,9]
643 0.0	#es_pch_per_unit[1,1,2,10]
644 0.0	#es_pch_per_unit[1,1,2,11]
645 0.0	#es_pch_per_unit[1,1,2,12]
646 0.0	#es_pch_per_unit[1,1,2,13]
647 0.0	#es_pch_per_unit[1,1,2,14]
648 0.0	#es_pch_per_unit[1,1,2,15]
649 0.0	#es_pch_per_unit[1,1,2,16]
650 0.0	#es_pch_per_unit[1,1,2,17]
651 0.0	#es_pch_per_unit[1,1,2,18]
652 0.0	#es_pch_per_unit[1,1,2,19]
653 0.0	#es_pch_per_unit[1,1,2,20]
654 0.0	#es_pch_per_unit[1,1,2,21]
655 0.0	#es_pch_per_unit[1,1,2,22]
656 0.0	#es_pch_per_unit[1,1,2,23]
657 0.0	#es_pch_per_unit[1,1,3,0]
658 0.0	#es_pch_per_unit[1,1,3,1]
659 0.0	#es_pch_per_unit[1,1,3,2]
660 0.0	#es_pch_per_unit[1,1,3,3]
661 0.0	#es_pch_per_unit[1,1,3,4]
662 0.0	#es_pch_per_unit[1,1,3,5]
663 0.0	#es_pch_per_unit[1,1,3,6]
664 0.0	#es_pch_per_unit[1,1,3,7]
665 0.0	#es_pch_per_unit[1,1,3,8]
666 0.0	#es_pch_per_unit[1,1,3,9]
667 0.0	#es_pch_per_unit[1,1,3,10]
668 0.0	#es_pch_per_unit[1,1,3,11]
669 0.0	#es_pch_per_unit[1,1,3,12]
670 0.0	#es_pch_per_unit[1,1,3,13]
671 0.0	#es_pch_per_unit[1,1,3,14]
672 0.0	#es_pch_per_unit[1,1,3,15]
673 0.0	#es_pch_per_unit[1,1,3,16]
674 0.0	#es_pch_per_unit[1,1,3,17]
675 0.0	#es_pch_per_unit[1,1,3,18]
676 0.0	#es_pch_per_unit[1,1,3,19]
677 0.0	#es_pch_per_unit[1,1,3,20]
678 0.0	#es_pch_per_unit[1,1,3,21]
679 0.0	#es_pch_per_unit[1,1,3,22]
680 0.0	#es_pch_per_unit[1,1,3,23]
681 0.0	#es_pch_per_unit[1,2,0,0]
682 0.0	#es_pch_per_unit[1,2,0,1]
683 0.0	#es_pch_per_unit[1,2,0,2]
684 0.0	#es_pch_per_unit[1,2,0,3]
685 0.0	#es_pch_per_unit[1,2,0,4]
686 0.0	#es_pch_per_unit[1,2,0,5]
687 0.0	#es_pch_per_unit[1,2,0,6]
688 0.0	#es_pch_per_unit[1,2,0,7]
689 0.0	#es_pch_per_unit[1,2,0,8]
690 0.0	#es_pch_per_unit[1,2,0,9]
691 0.0	#es_pch_per_unit[1,2,0,10]
692 0.0	#es_pch_per_unit[1,2,0,11]
693 0.0	#es_pch_per_unit[1,2,0,12]
694 0.0	#es_pch_per_unit[1,2,0,13]
695 0.0	#es_pch_per_unit[1,2,0,14]
696 0.0	#es_pch_per_unit[1,2,0,15]
697 0.0	#es_pch_per_unit[1,2,0,16]
698 0.0	#es_pch_per_unit[1,2,0,17]
699 0.0	#es_pch_per_unit[1,2,0,18]
700 0.0	#es_pch_per_unit[1,2,0,19]
701 0.0	#es_pch_per_unit[1,2,0,20]
702 0.0	#es_pch_per_unit[1,2,0,21]
703 0.0	#es_pch_per_unit[1,2,0,22]
704 0.0	#es_pch_per_unit[1,2,0,23]
705 0.0	#es_pch_per_unit[1,2,1,0]
706 0.0	#es_pch_per_unit[1,2,1,1]
707 0.0	#es_pch_per_unit[1,2,1,2]
708 0.0	#es_pch_per_unit[1,2,1,3]
709 0.0	#es_pch_per_unit[1,2,1,4]
710 0.0	#es_pch_per_unit[1,2,1,5]
711 0.0	#es_pch_per_unit[1,2,1,6]
712 0.0	#es_pch_per_unit[1,2,1,7]
713 0.0	#es_pch_per_unit[1,2,1,8]
714 0.0	#es_pch_per_unit[1,2,1,9]
715 0.0	#es_pch_per_unit[1,2,1,10]
716 0.0	#es_pch_per_unit[1,2,1,11]
717 0.0	#es_pch_per_unit[1,2,1,12]
718 0.0	#es_pch_per_unit[1,2,1,13]
719 0.0	#es_pch_per_unit[1,2,1,14]
720 0.0	#es_pch_per_unit[1,2,1,15]
721 0.0	#es_pch_per_unit[1,2,1,16]
722 0.0	#es_pch_per_unit[1,2,1,17]
723 0.0	#es_pch_per_unit[1,2,1,18]
724 0.0	#es_pch_per_unit[1,2,1,19]
725 0.0	#es_pch_per_unit[1,2,1,20]
726 0.0	#es_pch_per_unit[1,2,1,21]
727 0.0	#es_pch_per_unit[1,2,1,22]
728 0.0	#es_pch_per_unit[1,2,1,23]
729 0.0	#es_pch_per_unit[1,2,2,0]
730 0.0	#es_pch_per_unit[1,2,2,1]
731 0.0	#es_pch_per_unit[1,2,2,2]
732 0.0	#es_pch_per_unit[1,2,2,3]
733 0.0	#es_pch_per_unit[1,2,2,4]
734 0.0	#es_pch_per_unit[1,2,2,5]
735 0.0	#es_pch_per_unit[1,2,2,6]
736 0.0	#es_pch_per_unit[1,2,2,7]
737 0.0	#es_pch_per_unit[1,2,2,8]
738 0.0	#es_pch_per_unit[1,2,2,9]
739 0.0	#es_pch_per_unit[1,2,2,10]
740 0.0	#es_pch_per_unit[1,2,2,11]
741 0.0	#es_pch_per_unit[1,2,2,12]
742 0.0	#es_pch_per_unit[1,2,2,13]
743 0.0	#es_pch_per_unit[1,2,2,14]
744 0.0	#es_pch_per_unit[1,2,2,15]
745 0.0	#es_pch_per_unit[1,2,2,16]
746 0.0	#es_pch_per_unit[1,2,2,17]
747 0.0	#es_pch_per_unit[1,2,2,18]
748 0.0	#es_pch_per_unit[1,2,2,19]
749 0.0	#es_pch_per_unit[1,2,2,20]
750 0.0	#es_pch_per_unit[1,2,2,21]
751 0.0	#es_pch_per_unit[1,2,2,22]
752 0.0	#es_pch_per_unit[1,2,2,23]
753 0.0	#es_pch_per_unit[1,2,3,0]
754 0.0	#es_pch_per_unit[1,2,3,1]
755 0.0	#es_pch_per_unit[1,2,3,2]
756 0.0	#es_pch_per_unit[1,2,3,3]
757 0.0	#es_pch_per_unit[1,2,3,4]
758 0.0	#es_pch_per_unit[1,2,3,5]
759 0.0	#es_pch_per_unit[1,2,3,6]
760 0.0	#es_pch_per_unit[1,2,3,7]
761 0.0	#es_pch_per_unit[1,2,3,8]
762 0.0	#es_pch_per_unit[1,2,3,9]
763 0.0	#es_pch_per_unit[1,2,3,10]
764 0.0	#es_pch_per_unit[1,2,3,11]
765 0.0	#es_pch_per_unit[1,2,3,12]
766 0.0	#es_pch_per_unit[1,2,3,13]
767 0.0	#es_pch_per_unit[1,2,3,14]
768 0.0	#es_pch_per_unit[1,2,3,15]
769 0.0	#es_pch_per_unit[1,2,3,16]
770 0.0	#es_pch_per_unit[1,2,3,17]
771 0.0	#es_pch_per_unit[1,2,3,18]
772 0.0	#es_pch_per_unit[1,2,3,19]
773 0.0	#es_pch_per_unit[1,2,3,20]
774 0.0	#es_pch_per_unit[1,2,3,21]
775 0.0	#es_pch_per_unit[1,2,3,22]
776 0.0	#es_pch_per_unit[1,2,3,23]
777 0.0	#es_pdch_per_unit[1,1,0,0]
778 0.0	#es_pdch_per_unit[1,1,0,1]
779 0.0	#es_pdch_per_unit[1,1,0,2]
780 0.0	#es_pdch_per_unit[1,1,0,3]
781 0.0	#es_pdch_per_unit[1,1,0,4]
782 0.0	#es_pdch_per_unit[1,1,0,5]
783 0.0	#es_pdch_per_unit[1,1,0,6]
784 0.0	#es_pdch_per_unit[1,1,0,7]
785 0.0	#es_pdch_per_unit[1,1,0,8]
786 0.0	#es_pdch_per_unit[1,1,0,9]
787 0.0	#es_pdch_per_unit[1,1,0,10]
788 0.0	#es_pdch_per_unit[1,1,0,11]
789 0.0	#es_pdch_per_unit[1,1,0,12]
790 0.0	#es_pdch_per_unit[1,1,0,13]
791 0.0	#es_pdch_per_unit[1,1,0,14]
792 0.0	#es_pdch_per_unit[1,1,0,15]
793 0.0	#es_pdch_per_unit[1,1,0,16]
794 0.0	#es_pdch_per_unit[1,1,0,17]
795 0.0	#es_pdch_per_unit[1,1,0,18]
796 0.0	#es_pdch_per_unit[1,1,0,19]
797 0.0	#es_pdch_per_unit[1,1,0,20]
798 0.0	#es_pdch_per_unit[1,1,0,21]
799 0.0	#es_pdch_per_unit[1,1,0,22]
800 0.0	#es_pdch_per_unit[1,1,0,23]
801 0.0	#es_pdch_per_unit[1,1,1,0]
802 0.0	#es_pdch_per_unit[1,1,1,1]
803 0.0	#es_pdch_per_unit[1,1,1,2]
804 0.0	#es_pdch_per_unit[1,1,1,3]
805 0.0	#es_pdch_per_unit[1,1,1,4]
806 0.0	#es_pdch_per_unit[1,1,1,5]
807 0.0	#es_pdch_per_unit[1,1,1,6]
808 0.0	#es_pdch_per_unit[1,1,1,7]
809 0.0	#es_pdch_per_unit[1,1,1,8]
810 0.0	#es_pdch_per_unit[1,1,1,9]
811 0.0	#es_pdch_per_unit[1,1,1,10]
812 0.0	#es_pdch_per_unit[1,1,1,11]
813 0.0	#es_pdch_per_unit[1,1,1,12]
814 0.0	#es_pdch_per_unit[1,1,1,13]
815 0.0	#es_pdch_per_unit[1,1,1,14]
816 0.0	#es_pdch_per_unit[1,1,1,15]
817 0.0	#es_pdch_per_unit[1,1,1,16]
818 0.0	#es_pdch_per_unit[1,1,1,17]
819 0.0	#es_pdch_per_unit[1,1,1,18]
820 0.0	#es_pdch_per_unit[1,1,1,19]
821 0.0	#es_pdch_per_unit[1,1,1,20]
822 0.0	#es_pdch_per_unit[1,1,1,21]
823 0.0	#es_pdch_per_unit[1,1,1,22]
824 0.0	#es_pdch_per_unit[1,1,1,23]
825 0.0	#es_pdch_per_unit[1,1,2,0]
826 0.0	#es_pdch_per_unit[1,1,2,1]
827 0.0	#es_pdch_per_unit[1,1,2,2]
828 0.0	#es_pdch_per_unit[1,1,2,3]
829 0.0	#es_pdch_per_unit[1,1,2,4]
830 0.0	#es_pdch_per_unit[1,1,2,5]
831 0.0	#es_pdch_per_unit[1,1,2,6]
832 0.0	#es_pdch_per_unit[1,1,2,7]
833 0.0	#es_pdch_per_unit[1,1,2,8]
834 0.0	#es_pdch_per_unit[1,1,2,9]
835 0.0	#es_pdch_per_unit[1,1,2,10]
836 0.0	#es_pdch_per_unit[1,1,2,11]
837 0.0	#es_pdch_per_unit[1,1,2,12]
838 0.0	#es_pdch_per_unit[1,1,2,13]
839 0.0	#es_pdch_per_unit[1,1,2,14]
840 0.0	#es_pdch_per_unit[1,1,2,15]
841 0.0	#es_pdch_per_unit[1,1,2,16]
842 0.0	#es_pdch_per_unit[1,1,2,17]
843 0.0	#es_pdch_per_unit[1,1,2,18]
844 0.0	#es_pdch_per_unit[1,1,2,19]
845 0.0	#es_pdch_per_unit[1,1,2,20]
846 0.0	#es_pdch_per_unit[1,1,2,21]
847 0.0	#es_pdch_per_unit[1,1,2,22]
848 0.0	#es_pdch_per_unit[1,1,2,23]
849 0.0	#es_pdch_per_unit[1,1,3,0]
850 0.0	#es_pdch_per_unit[1,1,3,1]
851 0.0	#es_pdch_per_unit[1,1,3,2]
852 0.0	#es_pdch_per_unit[1,1,3,3]
853 0.0	#es_pdch_per_unit[1,1,3,4]
854 0.0	#es_pdch_per_unit[1,1,3,5]
855 0.0	#es_pdch_per_unit[1,1,3,6]
856 0.0	#es_pdch_per_unit[1,1,3,7]
857 0.0	#es_pdch_per_unit[1,1,3,8]
858 0.0	#es_pdch_per_unit[1,1,3,9]
859 0.0	#es_pdch_per_unit[1,1,3,10]
860 0.0	#es_pdch_per_unit[1,1,3,11]
861 0.0	#es_pdch_per_unit[1,1,3,12]
862 0.0	#es_pdch_per_unit[1,1,3,13]
863 0.0	#es_pdch_per_unit[1,1,3,14]
864 0.0	#es_pdch_per_unit[1,1,3,15]
865 0.0	#es_pdch_per_unit[1,1,3,16]
866 0.0	#es_pdch_per_unit[1,1,3,17]
867 0.0	#es_pdch_per_unit[1,1,3,18]
868 0.0	#es_pdch_per_unit[1,1,3,19]
869 0.0	#es_pdch_per_unit[1,1,3,20]
870 0.0	#es_pdch_per_unit[1,1,3,21]
871 0.0	#es_pdch_per_unit[1,1,3,22]
872 0.0	#es_pdch_per_unit[1,1,3,23]
873 0.0	#es_pdch_per_unit[1,2,0,0]
874 0.0	#es_pdch_per_unit[1,2,0,1]
875 0.0	#es_pdch_per_unit[1,2,0,2]
876 0.0	#es_pdch_per_unit[1,2,0,3]
877 0.0	#es_pdch_per_unit[1,2,0,4]
878 0.0	#es_pdch_per_unit[1,2,0,5]
879 0.0	#es_pdch_per_unit[1,2,0,6]
880 0.0	#es_pdch_per_unit[1,2,0,7]
881 0.0	#es_pdch_per_unit[1,2,0,8]
882 0.0	#es_pdch_per_unit[1,2,0,9]
883 0.0	#es_pdch_per_unit[1,2,0,10]
884 0.0	#es_pdch_per_unit[1,2,0,11]
885 0.0	#es_pdch_per_unit[1,2,0,12]
886 0.0	#es_pdch_per_unit[1,2,0,13]
887 0.0	#es_pdch_per_unit[1,2,0,14]
888 0.0	#es_pdch_per_unit[1,2,0,15]
889 0.0	#es_pdch_per_unit[1,2,0,16]
890 0.0	#es_pdch_per_unit[1,2,0,17]
891 0.0	#es_pdch_per_unit[1,2,0,18]
892 0.0	#es_pdch_per_unit[1,2,0,19]
893 0.0	#es_pdch_per_unit[1,2,0,20]
894 0.0	#es_pdch_per_unit[1,2,0,21]
895 0.0	#es_pdch_per_unit[1,2,0,22]
896 0.0	#es_pdch_per_unit[1,2,0,23]
897 0.0	#es_pdch_per_unit[1,2,1,0]
898 0.0	#es_pdch_per_unit[1,2,1,1]
899 0.0	#es_pdch_per_unit[1,2,1,2]
900 0.0	#es_pdch_per_unit[1,2,1,3]
901 0.0	#es_pdch_per_unit[1,2,1,4]
902 0.0	#es_pdch_per_unit[1,2,1,5]
903 0.0	#es_pdch_per_unit[1,2,1,6]
904 0.0	#es_pdch_per_unit[1,2,1,7]
905 0.0	#es_pdch_per_unit[1,2,1,8]
906 0.0	#es_pdch_per_unit[1,2,1,9]
907 0.0	#es_pdch_per_unit[1,2,1,10]
908 0.0	#es_pdch_per_unit[1,2,1,11]
909 0.0	#es_pdch_per_unit[1,2,1,12]
910 0.0	#es_pdch_per_unit[1,2,1,13]
911 0.0	#es_pdch_per_unit[1,2,1,14]
912 0.0	#es_pdch_per_unit[1,2,1,15]
913 0.0	#es_pdch_per_unit[1,2,1,16]
914 0.0	#es_pdch_per_unit[1,2,1,17]
915 0.0	#es_pdch_per_unit[1,2,1,18]
916 0.0	#es_pdch_per_unit[1,2,1,19]
917 0.0	#es_pdch_per_unit[1,2,1,20]
918 0.0	#es_pdch_per_unit[1,2,1,21]
919 0.0	#es_pdch_per_unit[1,2,1,22]
920 0.0	#es_pdch_per_unit[1,2,1,23]
921 0.0	#es_pdch_per_unit[1,2,2,0]
922 0.0	#es_pdch_per_unit[1,2,2,1]
923 0.0	#es_pdch_per_unit[1,2,2,2]
924 0.0	#es_pdch_per_unit[1,2,2,3]
925 0.0	#es_pdch_per_unit[1,2,2,4]
926 0.0	#es_pdch_per_unit[1,2,2,5]
927 0.0	#es_pdch_per_unit[1,2,2,6]
928 0.0	#es_pdch_per_unit[1,2,2,7]
929 0.0	#es_pdch_per_unit[1,2,2,8]
930 0.0	#es_pdch_per_unit[1,2,2,9]
931 0.0	#es_pdch_per_unit[1,2,2,10]
932 0.0	#es_pdch_per_unit[1,2,2,11]
933 0.0	#es_pdch_per_unit[1,2,2,12]
934 0.0	#es_pdch_per_unit[1,2,2,13]
935 0.0	#es_pdch_per_unit[1,2,2,14]
936 0.0	#es_pdch_per_unit[1,2,2,15]
937 0.0	#es_pdch_per_unit[1,2,2,16]
938 0.0	#es_pdch_per_unit[1,2,2,17]
939 0.0	#es_pdch_per_unit[1,2,2,18]
940 0.0	#es_pdch_per_unit[1,2,2,19]
941 0.0	#es_pdch_per_unit[1,2,2,20]
942 0.0	#es_pdch_per_unit[1,2,2,21]
943 0.0	#es_pdch_per_unit[1,2,2,22]
944 0.0	#es_pdch_per_unit[1,2,2,23]
945 0.0	#es_pdch_per_unit[1,2,3,0]
946 0.0	#es_pdch_per_unit[1,2,3,1]
947 0.0	#es_pdch_per_unit[1,2,3,2]
948 0.0	#es_pdch_per_unit[1,2,3,3]
949 0.0	#es_pdch_per_unit[1,2,3,4]
950 0.0	#es_pdch_per_unit[1,2,3,5]
951 0.0	#es_pdch_per_unit[1,2,3,6]
952 0.0	#es_pdch_per_unit[1,2,3,7]
953 0.0	#es_pdch_per_unit[1,2,3,8]
954 0.0	#es_pdch_per_unit[1,2,3,9]
955 0.0	#es_pdch_per_unit[1,2,3,10]
956 0.0	#es_pdch_per_unit[1,2,3,11]
957 0.0	#es_pdch_per_unit[1,2,3,12]
958 0.0	#es_pdch_per_unit[1,2,3,13]
959 0.0	#es_pdch_per_unit[1,2,3,14]
960 0.0	#es_pdch_per_unit[1,2,3,15]
961 0.0	#es_pdch_per_unit[1,2,3,16]
962 0.0	#es_pdch_per_unit[1,2,3,17]
963 0.0	#es_pdch_per_unit[1,2,3,18]
964 0.0	#es_pdch_per_unit[1,2,3,19]
965 0.0	#es_pdch_per_unit[1,2,3,20]
966 0.0	#es_pdch_per_unit[1,2,3,21]
967 0.0	#es_pdch_per_unit[1,2,3,22]
968 0.0	#es_pdch_per_unit[1,2,3,23]
969 0.0	#es_s_rated_per_unit[0,0]
970 0.0	#es_s_rated_per_unit[0,1]
971 0.0	#es_s_rated_per_unit[0,2]
972 0.0	#es_s_rated_per_unit[1,1]
973 0.0	#es_s_rated_per_unit[1,2]
974 0.0	#es_s_rated_per_unit[2,2]
975 0.0	#es_e_rated_per_unit[0,0]
976 0.0	#es_e_rated_per_unit[0,1]
977 0.0	#es_e_rated_per_unit[0,2]
978 0.0	#es_e_rated_per_unit[2,2]
979 0.0	#es_e_rated[0]
980 0.0	#es_e_rated[1]
981 0.0	#es_e_rated[2]
982 0.0	#es_s_available_per_unit[0,0]
983 0.0	#es_s_available_per_unit[0,1]
984 0.0	#es_s_available_per_unit[0,2]
985 0.0	#es_s_available_per_unit[1,0]
986 0.0	#es_s_available_per_unit[1,1]
987 0.0	#es_s_available_per_unit[1,2]
988 0.0	#es_s_available_per_unit[2,0]
989 0.0	#es_s_available_per_unit[2,1]
990 0.0	#es_s_available_per_unit[2,2]
991 0.0	#es_e_available_per_unit[0,0]
992 0.0	#es_e_available_per_unit[0,1]
993 0.0	#es_e_available_per_unit[0,2]
994 0.0	#es_e_available_per_unit[1,0]
995 0.0	#es_e_available_per_unit[1,1]
996 0.0	#es_e_available_per_unit[1,2]
997 0.0	#es_e_available_per_unit[2,0]
998 0.0	#es_e_available_per_unit[2,1]
999 0.0	#es_e_available_per_unit[2,2]
1000 0.0	#es_avg_ch_dch_per_unit[1,1]
1001 0.0	#es_avg_ch_dch_per_unit[1,2]
r	#1004 ranges (rhs's)
4 0	#available_e_capacity_unit[5]
4 0	#available_e_capacity_unit[6]
4 0.0	#energy_storage_capacity_degradation[11]
4 0.0	#energy_storage_capacity_degradation[14]
1 0.0	#energy_storage_operation_agg[2]
1 0.0	#energy_storage_operation_agg[4]
1 0.0	#energy_storage_operation_agg[6]
1 0.0	#energy_storage_operation_agg[8]
1 0.0	#energy_storage_operation_agg[10]
1 0.0	#energy_storage_operation_agg[12]
1 0.0	#energy_storage_operation_agg[14]
1 0.0	#energy_storage_operation_agg[16]
1 0.0	#energy_storage_operation_agg[18]
1 0.0	#energy_storage_operation_agg[20]
1 0.0	#energy_storage_operation_agg[22]
1 0.0	#energy_storage_operation_agg[24]
1 0.0	#energy_storage_operation_agg[26]
1 0.0	#energy_storage_operation_agg[28]
1 0.0	#energy_storage_operation_agg[30]
1 0.0	#energy_storage_operation_agg[32]
1 0.0	#energy_storage_operation_agg[34]
1 0.0	#energy_storage_operation_agg[36]
1 0.0	#energy_storage_operation_agg[38]
1 0.0	#energy_storage_operation_agg[40]
1 0.0	#energy_storage_operation_agg[42]
1 0.0	#energy_storage_operation_agg[44]
1 0.0	#energy_storage_operation_agg[46]
1 0.0	#energy_storage_operation_agg[48]
1 0.0	#energy_storage_operation_agg[50]
1 0.0	#energy_storage_operation_agg[52]
1 0.0	#energy_storage_operation_agg[54]
1 0.0	#energy_storage_operation_agg[56]
1 0.0	#energy_storage_operation_agg[58]
1 0.0	#energy_storage_operation_agg[60]
1 0.0	#energy_storage_operation_agg[62]
1 0.0	#energy_storage_operation_agg[64]
1 0.0	#energy_storage_operation_agg[66]
1 0.0	#energy_storage_operation_agg[68]
1 0.0	#energy_storage_operation_agg[70]
1 0.0	#energy_storage_operation_agg[72]
1 0.0	#energy_storage_operation_agg[74]
1 0.0	#energy_storage_operation_agg[76]
1 0.0	#energy_storage_operation_agg[78]
1 0.0	#energy_storage_operation_agg[80]
1 0.0	#energy_storage_operation_agg[82]
1 0.0	#energy_storage_operation_agg[84]
1 0.0	#energy_storage_operation_agg[86]
1 0.0	#energy_storage_operation_agg[88]
1 0.0	#energy_storage_operation_agg[90]
1 0.0	#energy_storage_operation_agg[92]
1 0.0	#energy_storage_operation_agg[94]
1 0.0	#energy_storage_operation_agg[96]
1 0.0	#energy_storage_operation_agg[98]
1 0.0	#energy_storage_operation_agg[100]
1 0.0	#energy_storage_operation_agg[102]
1 0.0	#energy_storage_operation_agg[104]
1 0.0	#energy_storage_operation_agg[106]
1 0.0	#energy_storage_operation_agg[108]
1 0.0	#energy_storage_operation_agg[110]
1 0.0	#energy_storage_operation_agg[112]
1 0.0	#energy_storage_operation_agg[114]
1 0.0	#energy_storage_operation_agg[116]
1 0.0	#energy_storage_operation_agg[118]
1 0.0	#energy_storage_operation_agg[120]
1 0.0	#energy_storage_operation_agg[122]
1 0.0	#energy_storage_operation_agg[124]
1 0.0	#energy_storage_operation_agg[126]
1 0.0	#energy_storage_operation_agg[128]
1 0.0	#energy_storage_operation_agg[130]
1 0.0	#energy_storage_operation_agg[132]
1 0.0	#energy_storage_operation_agg[134]
1 0.0	#energy_storage_operation_agg[136]
1 0.0	#energy_storage_operation_agg[138]
1 0.0	#energy_storage_operation_agg[140]
1 0.0	#energy_storage_operation_agg[142]
1 0.0	#energy_storage_operation_agg[144]
1 0.0	#energy_storage_operation_agg[146]
1 0.0	#energy_storage_operation_agg[148]
1 0.0	#energy_storage_operation_agg[150]
1 0.0	#energy_storage_operation_agg[152]
1 0.0	#energy_storage_operation_agg[154]
1 0.0	#energy_storage_operation_agg[156]
1 0.0	#energy_storage_operation_agg[158]
1 0.0	#energy_storage_operation_agg[160]
1 0.0	#energy_storage_operation_agg[162]
1 0.0	#energy_storage_operation_agg[164]
1 0.0	#energy_storage_operation_agg[166]
1 0.0	#energy_storage_operation_agg[168]
1 0.0	#energy_storage_operation_agg[170]
1 0.0	#energy_storage_operation_agg[172]
1 0.0	#energy_storage_operation_agg[174]
1 0.0	#energy_storage_operation_agg[176]
1 0.0	#energy_storage_operation_agg[178]
1 0.0	#energy_storage_operation_agg[180]
1 0.0	#energy_storage_operation_agg[182]
1 0.0	#energy_storage_operation_agg[184]
1 0.0	#energy_storage_operation_agg[186]
1 0.0	#energy_storage_operation_agg[188]
1 0.0	#energy_storage_operation_agg[190]
1 0.0	#energy_storage_operation_agg[192]
1 0.0	#energy_storage_operation_agg[194]
1 0.0	#energy_storage_operation_agg[196]
1 0.0	#energy_storage_operation_agg[198]
1 0.0	#energy_storage_operation_agg[200]
1 0.0	#energy_storage_operation_agg[202]
1 0.0	#energy_storage_operation_agg[204]
1 0.0	#energy_storage_operation_agg[206]
1 0.0	#energy_storage_operation_agg[208]
1 0.0	#energy_storage_operation_agg[210]
1 0.0	#energy_storage_operation_agg[212]
1 0.0	#energy_storage_operation_agg[214]
1 0.0	#energy_storage_operation_agg[216]
1 0.0	#energy_storage_operation_agg[218]
1 0.0	#energy_storage_operation_agg[220]
1 0.0	#energy_storage_operation_agg[222]
1 0.0	#energy_storage_operation_agg[224]
1 0.0	#energy_storage_operation_agg[226]
1 0.0	#energy_storage_operation_agg[228]
1 0.0	#energy_storage_operation_agg[230]
1 0.0	#energy_storage_operation_agg[232]
1 0.0	#energy_storage_operation_agg[234]
1 0.0	#energy_storage_operation_agg[236]
1 0.0	#energy_storage_operation_agg[238]
1 0.0	#energy_storage_operation_agg[240]
1 0.0	#energy_storage_operation_agg[242]
1 0.0	#energy_storage_operation_agg[244]
1 0.0	#energy_storage_operation_agg[246]
1 0.0	#energy_storage_operation_agg[248]
1 0.0	#energy_storage_operation_agg[250]
1 0.0	#energy_storage_operation_agg[252]
1 0.0	#energy_storage_operation_agg[254]
1 0.0	#energy_storage_operation_agg[256]
1 0.0	#energy_storage_operation_agg[258]
1 0.0	#energy_storage_operation_agg[260]
1 0.0	#energy_storage_operation_agg[262]
1 0.0	#energy_storage_operation_agg[264]
1 0.0	#energy_storage_operation_agg[266]
1 0.0	#energy_storage_operation_agg[268]
1 0.0	#energy_storage_operation_agg[270]
1 0.0	#energy_storage_operation_agg[272]
1 0.0	#energy_storage_operation_agg[274]
1 0.0	#energy_storage_operation_agg[276]
1 0.0	#energy_storage_operation_agg[278]
1 0.0	#energy_storage_operation_agg[280]
1 0.0	#energy_storage_operation_agg[282]
1 0.0	#energy_storage_operation_agg[284]
1 0.0	#energy_storage_operation_agg[286]
1 0.0	#energy_storage_operation_agg[288]
1 0.0	#energy_storage_operation_agg[290]
1 0.0	#energy_storage_operation_agg[292]
1 0.0	#energy_storage_operation_agg[294]
1 0.0	#energy_storage_operation_agg[296]
1 0.0	#energy_storage_operation_agg[298]
1 0.0	#energy_storage_operation_agg[300]
1 0.0	#energy_storage_operation_agg[302]
1 0.0	#energy_storage_operation_agg[304]
1 0.0	#energy_storage_operation_agg[306]
1 0.0	#energy_storage_operation_agg[308]
1 0.0	#energy_storage_operation_agg[310]
1 0.0	#energy_storage_operation_agg[312]
1 0.0	#energy_storage_operation_agg[314]
1 0.0	#energy_storage_operation_agg[316]
1 0.0	#energy_storage_operation_agg[318]
1 0.0	#energy_storage_operation_agg[320]
1 0.0	#energy_storage_operation_agg[322]
1 0.0	#energy_storage_operation_agg[324]
1 0.0	#energy_storage_operation_agg[326]
1 0.0	#energy_storage_operation_agg[328]
1 0.0	#energy_storage_operation_agg[330]
1 0.0	#energy_storage_operation_agg[332]
1 0.0	#energy_storage_operation_agg[334]
1 0.0	#energy_storage_operation_agg[336]
1 0.0	#energy_storage_operation_agg[338]
1 0.0	#energy_storage_operation_agg[340]
1 0.0	#energy_storage_operation_agg[342]
1 0.0	#energy_storage_operation_agg[344]
1 0.0	#energy_storage_operation_agg[346]
1 0.0	#energy_storage_operation_agg[348]
1 0.0	#energy_storage_operation_agg[350]
1 0.0	#energy_storage_operation_agg[352]
1 0.0	#energy_storage_operation_agg[354]
1 0.0	#energy_storage_operation_agg[356]
1 0.0	#energy_storage_operation_agg[358]
1 0.0	#energy_storage_operation_agg[360]
1 0.0	#energy_storage_operation_agg[362]
1 0.0	#energy_storage_operation_agg[364]
1 0.0	#energy_storage_operation_agg[366]
1 0.0	#energy_storage_operation_agg[368]
1 0.0	#energy_storage_operation_agg[370]
1 0.0	#energy_storage_operation_agg[372]
1 0.0	#energy_storage_operation_agg[374]
1 0.0	#energy_storage_operation_agg[376]
1 0.0	#energy_storage_operation_agg[378]
1 0.0	#energy_storage_operation_agg[380]
1 0.0	#energy_storage_operation_agg[382]
1 0.0	#energy_storage_operation_agg[384]
1 0.0	#energy_storage_operation_agg[386]
1 0.0	#energy_storage_operation_agg[388]
1 0.0	#energy_storage_operation_agg[390]
1 0.0	#energy_storage_operation_agg[392]
1 0.0	#energy_storage_operation_agg[394]
1 0.0	#energy_storage_operation_agg[396]
1 0.0	#energy_storage_operation_agg[398]
1 0.0	#energy_storage_operation_agg[400]
1 0.0	#energy_storage_operation_agg[402]
1 0.0	#energy_storage_operation_agg[404]
1 0.0	#energy_storage_operation_agg[406]
1 0.0	#energy_storage_operation_agg[408]
1 0.0	#energy_storage_operation_agg[410]
1 0.0	#energy_storage_operation_agg[412]
1 0.0	#energy_storage_operation_agg[414]
1 0.0	#energy_storage_operation_agg[416]
1 0.0	#energy_storage_operation_agg[418]
1 0.0	#energy_storage_operation_agg[420]
1 0.0	#energy_storage_operation_agg[422]
1 0.0	#energy_storage_operation_agg[424]
1 0.0	#energy_storage_operation_agg[426]
1 0.0	#energy_storage_operation_agg[428]
1 0.0	#energy_storage_operation_agg[430]
1 0.0	#energy_storage_operation_agg[432]
1 0.0	#energy_storage_operation_agg[434]
1 0.0	#energy_storage_operation_agg[436]
1 0.0	#energy_storage_operation_agg[438]
1 0.0	#energy_storage_operation_agg[440]
1 0.0	#energy_storage_operation_agg[442]
1 0.0	#energy_storage_operation_agg[444]
1 0.0	#energy_storage_operation_agg[446]
1 0.0	#energy_storage_operation_agg[448]
1 0.0	#energy_storage_operation_agg[450]
1 0.0	#energy_storage_operation_agg[452]
1 0.0	#energy_storage_operation_agg[454]
1 0.0	#energy_storage_operation_agg[456]
1 0.0	#energy_storage_operation_agg[458]
1 0.0	#energy_storage_operation_agg[460]
1 0.0	#energy_storage_operation_agg[462]
1 0.0	#energy_storage_operation_agg[464]
1 0.0	#energy_storage_operation_agg[466]
1 0.0	#energy_storage_operation_agg[468]
1 0.0	#energy_storage_operation_agg[470]
1 0.0	#energy_storage_operation_agg[472]
1 0.0	#energy_storage_operation_agg[474]
1 0.0	#energy_storage_operation_agg[476]
1 0.0	#energy_storage_operation_agg[478]
1 0.0	#energy_storage_operation_agg[480]
1 0.0	#energy_storage_operation_agg[482]
1 0.0	#energy_storage_operation_agg[484]
1 0.0	#energy_storage_operation_agg[486]
1 0.0	#energy_storage_operation_agg[488]
1 0.0	#energy_storage_operation_agg[490]
1 0.0	#energy_storage_operation_agg[492]
1 0.0	#energy_storage_operation_agg[494]
1 0.0	#energy_storage_operation_agg[496]
1 0.0	#energy_storage_operation_agg[498]
1 0.0	#energy_storage_operation_agg[500]
1 0.0	#energy_storage_operation_agg[502]
1 0.0	#energy_storage_operation_agg[504]
1 0.0	#energy_storage_operation_agg[506]
1 0.0	#energy_storage_operation_agg[508]
1 0.0	#energy_storage_operation_agg[510]
1 0.0	#energy_storage_operation_agg[512]
1 0.0	#energy_storage_operation_agg[514]
1 0.0	#energy_storage_operation_agg[516]
1 0.0	#energy_storage_operation_agg[518]
1 0.0	#energy_storage_operation_agg[520]
1 0.0	#energy_storage_operation_agg[522]
1 0.0	#energy_storage_operation_agg[524]
1 0.0	#energy_storage_operation_agg[526]
1 0.0	#energy_storage_operation_agg[528]
1 0.0	#energy_storage_operation_agg[530]
1 0.0	#energy_storage_operation_agg[532]
1 0.0	#energy_storage_operation_agg[534]
1 0.0	#energy_storage_operation_agg[536]
1 0.0	#energy_storage_operation_agg[538]
1 0.0	#energy_storage_operation_agg[540]
1 0.0	#energy_storage_operation_agg[542]
1 0.0	#energy_storage_operation_agg[544]
1 0.0	#energy_storage_operation_agg[546]
1 0.0	#energy_storage_operation_agg[548]
1 0.0	#energy_storage_operation_agg[550]
1 0.0	#energy_storage_operation_agg[552]
1 0.0	#energy_storage_operation_agg[554]
1 0.0	#energy_storage_operation_agg[556]
1 0.0	#energy_storage_operation_agg[558]
1 0.0	#energy_storage_operation_agg[560]
1 0.0	#energy_storage_operation_agg[562]
1 0.0	#energy_storage_operation_agg[564]
1 0.0	#energy_storage_operation_agg[566]
1 0.0	#energy_storage_operation_agg[568]
1 0.0	#energy_storage_operation_agg[570]
1 0.0	#energy_storage_operation_agg[572]
1 0.0	#energy_storage_operation_agg[574]
1 0.0	#energy_storage_operation_agg[576]
4 0.0	#rated_s_capacity_unit[1]
4 0.0	#rated_s_capacity_unit[2]
4 0.0	#rated_s_capacity_unit[3]
4 0.25	#rated_s_capacity_unit[4]
4 0.25	#rated_s_capacity_unit[5]
4 0.0	#rated_s_capacity_unit[6]
4 0.0	#rated_e_capacity_unit[1]
4 0.0	#rated_e_capacity_unit[2]
4 0.0	#rated_e_capacity_unit[3]
4 1.0	#rated_e_capacity_unit[4]
4 1.0	#rated_e_capacity_unit[5]
4 0.0	#rated_e_capacity_unit[6]
4 0.0	#rated_s_capacity[1]
4 0.0	#rated_s_capacity[2]
4 0	#rated_s_capacity[3]
4 0.0	#rated_e_capacity[1]
4 0.0	#rated_e_capacity[2]
4 0	#rated_e_capacity[3]
4 0	#available_s_capacity_unit[1]
4 0	#available_s_capacity_unit[2]
4 0	#available_s_capacity_unit[3]
4 0.0	#available_s_capacity_unit[4]
4 0	#available_s_capacity_unit[5]
4 0	#available_s_capacity_unit[6]
4 0.0	#available_s_capacity_unit[7]
4 0.0	#available_s_capacity_unit[8]
4 0	#available_s_capacity_unit[9]
4 0	#available_e_capacity_unit[1]
4 0	#available_e_capacity_unit[2]
4 0	#available_e_capacity_unit[3]
4 0.0	#available_e_capacity_unit[4]
4 0.0	#available_e_capacity_unit[7]
4 0.0	#available_e_capacity_unit[8]
4 0	#available_e_capacity_unit[9]
4 0.0	#energy_storage_charging_discharging[5]
4 0.0	#energy_storage_charging_discharging[6]
4 0	#energy_storage_capacity_degradation[10]
2 0.7	#energy_storage_capacity_degradation[12]
4 0	#energy_storage_capacity_degradation[13]
2 0.7	#energy_storage_capacity_degradation[15]
1 0	#energy_storage_limits[769]
1 0	#energy_storage_limits[770]
1 0	#energy_storage_limits[771]
1 0	#energy_storage_limits[772]
1 0	#energy_storage_limits[773]
1 0	#energy_storage_limits[774]
1 0	#energy_storage_limits[775]
1 0	#energy_storage_limits[776]
1 0	#energy_storage_limits[777]
1 0	#energy_storage_limits[778]
1 0	#energy_storage_limits[779]
1 0	#energy_storage_limits[780]
1 0	#energy_storage_limits[781]
1 0	#energy_storage_limits[782]
1 0	#energy_storage_limits[783]
1 0	#energy_storage_limits[784]
1 0	#energy_storage_limits[785]
1 0	#energy_storage_limits[786]
1 0	#energy_storage_limits[787]
1 0	#energy_storage_limits[788]
1 0	#energy_storage_limits[789]
1 0	#energy_storage_limits[790]
1 0	#energy_storage_limits[791]
1 0	#energy_storage_limits[792]
1 0	#energy_storage_limits[793]
1 0	#energy_storage_limits[794]
1 0	#energy_storage_limits[795]
1 0	#energy_storage_limits[796]
1 0	#energy_storage_limits[797]
1 0	#energy_storage_limits[798]
1 0	#energy_storage_limits[799]
1 0	#energy_storage_limits[800]
1 0	#energy_storage_limits[801]
1 0	#energy_storage_limits[802]
1 0	#energy_storage_limits[803]
1 0	#energy_storage_limits[804]
1 0	#energy_storage_limits[805]
1 0	#energy_storage_limits[806]
1 0	#energy_storage_limits[807]
1 0	#energy_storage_limits[808]
1 0	#energy_storage_limits[809]
1 0	#energy_storage_limits[810]
1 0	#energy_storage_limits[811]
1 0	#energy_storage_limits[812]
1 0	#energy_storage_limits[813]
1 0	#energy_storage_limits[814]
1 0	#energy_storage_limits[815]
1 0	#energy_storage_limits[816]
1 0	#energy_storage_limits[817]
1 0	#energy_storage_limits[818]
1 0	#energy_storage_limits[819]
1 0	#energy_storage_limits[820]
1 0	#energy_storage_limits[821]
1 0	#energy_storage_limits[822]
1 0	#energy_storage_limits[823]
1 0	#energy_storage_limits[824]
1 0	#energy_storage_limits[825]
1 0	#energy_storage_limits[826]
1 0	#energy_storage_limits[827]
1 0	#energy_storage_limits[828]
1 0	#energy_storage_limits[829]
1 0	#energy_storage_limits[830]
1 0	#energy_storage_limits[831]
1 0	#energy_storage_limits[832]
1 0	#energy_storage_limits[833]
1 0	#energy_storage_limits[834]
1 0	#energy_storage_limits[835]
1 0	#energy_storage_limits[836]
1 0	#energy_storage_limits[837]
1 0	#energy_storage_limits[838]
1 0	#energy_storage_limits[839]
1 0	#energy_storage_limits[840]
1 0	#energy_storage_limits[841]
1 0	#energy_storage_limits[842]
1 0	#energy_storage_limits[843]
1 0	#energy_storage_limits[844]
1 0	#energy_storage_limits[845]
1 0	#energy_storage_limits[846]
1 0	#energy_storage_limits[847]
1 0	#energy_storage_limits[848]
1 0	#energy_storage_limits[849]
1 0	#energy_storage_limits[850]
1 0	#energy_storage_limits[851]
1 0	#energy_storage_limits[852]
1 0	#energy_storage_limits[853]
1 0	#energy_storage_limits[854]
1 0	#energy_storage_limits[855]
1 0	#energy_storage_limits[856]
1 0	#energy_storage_limits[857]
1 0	#energy_storage_limits[858]
1 0	#energy_storage_limits[859]
1 0	#energy_storage_limits[860]
1 0	#energy_storage_limits[861]
1 0	#energy_storage_limits[862]
1 0	#energy_storage_limits[863]
1 0	#energy_storage_limits[864]
1 0	#energy_storage_limits[865]
1 0	#energy_storage_limits[866]
1 0	#energy_storage_limits[867]
1 0	#energy_storage_limits[868]
1 0	#energy_storage_limits[869]
1 0	#energy_storage_limits[870]
1 0	#energy_storage_limits[871]
1 0	#energy_storage_limits[872]
1 0	#energy_storage_limits[873]
1 0	#energy_storage_limits[874]
1 0	#energy_storage_limits[875]
1 0	#energy_storage_limits[876]
1 0	#energy_storage_limits[877]
1 0	#energy_storage_limits[878]
1 0	#energy_storage_limits[879]
1 0	#energy_storage_limits[880]
1 0	#energy_storage_limits[881]
1 0	#energy_storage_limits[882]
1 0	#energy_storage_limits[883]
1 0	#energy_storage_limits[884]
1 0	#energy_storage_limits[885]
1 0	#energy_storage_limits[886]
1 0	#energy_storage_limits[887]
1 0	#energy_storage_limits[888]
1 0	#energy_storage_limits[889]
1 0	#energy_storage_limits[890]
1 0	#energy_storage_limits[891]
1 0	#energy_storage_limits[892]
1 0	#energy_storage_limits[893]
1 0	#energy_storage_limits[894]
1 0	#energy_storage_limits[895]
1 0	#energy_storage_limits[896]
1 0	#energy_storage_limits[897]
1 0	#energy_storage_limits[898]
1 0	#energy_storage_limits[899]
1 0	#energy_storage_limits[900]
1 0	#energy_storage_limits[901]
1 0	#energy_storage_limits[902]
1 0	#energy_storage_limits[903]
1 0	#energy_storage_limits[904]
1 0	#energy_storage_limits[905]
1 0	#energy_storage_limits[906]
1 0	#energy_storage_limits[907]
1 0	#energy_storage_limits[908]
1 0	#energy_storage_limits[909]
1 0	#energy_storage_limits[910]
1 0	#energy_storage_limits[911]
1 0	#energy_storage_limits[912]
1 0	#energy_storage_limits[913]
1 0	#energy_storage_limits[914]
1 0	#energy_storage_limits[915]
1 0	#energy_storage_limits[916]
1 0	#energy_storage_limits[917]
1 0	#energy_storage_limits[918]
1 0	#energy_storage_limits[919]
1 0	#energy_storage_limits[920]
1 0	#energy_storage_limits[921]
1 0	#energy_storage_limits[922]
1 0	#energy_storage_limits[923]
1 0	#energy_storage_limits[924]
1 0	#energy_storage_limits[925]
1 0	#energy_storage_limits[926]
1 0	#energy_storage_limits[927]
1 0	#energy_storage_limits[928]
1 0	#energy_storage_limits[929]
1 0	#energy_storage_limits[930]
1 0	#energy_storage_limits[931]
1 0	#energy_storage_limits[932]
1 0	#energy_storage_limits[933]
1 0	#energy_storage_limits[934]
1 0	#energy_storage_limits[935]
1 0	#energy_storage_limits[936]
1 0	#energy_storage_limits[937]
1 0	#energy_storage_limits[938]
1 0	#energy_storage_limits[939]
1 0	#energy_storage_limits[940]
1 0	#energy_storage_limits[941]
1 0	#energy_storage_limits[942]
1 0	#energy_storage_limits[943]
1 0	#energy_storage_limits[944]
1 0	#energy_storage_limits[945]
1 0	#energy_storage_limits[946]
1 0	#energy_storage_limits[947]
1 0	#energy_storage_limits[948]
1 0	#energy_storage_limits[949]
1 0	#energy_storage_limits[950]
1 0	#energy_storage_limits[951]
1 0	#energy_storage_limits[952]
1 0	#energy_storage_limits[953]
1 0	#energy_storage_limits[954]
1 0	#energy_storage_limits[955]
1 0	#energy_storage_limits[956]
1 0	#energy_storage_limits[957]
1 0	#energy_storage_limits[958]
1 0	#energy_storage_limits[959]
1 0	#energy_storage_limits[960]
1 0	#energy_storage_limits[961]
1 0	#energy_storage_limits[962]
1 0	#energy_storage_limits[963]
1 0	#energy_storage_limits[964]
1 0	#energy_storage_limits[965]
1 0	#energy_storage_limits[966]
1 0	#energy_storage_limits[967]
1 0	#energy_storage_limits[968]
1 0	#energy_storage_limits[969]
1 0	#energy_storage_limits[970]
1 0	#energy_storage_limits[971]
1 0	#energy_storage_limits[972]
1 0	#energy_storage_limits[973]
1 0	#energy_storage_limits[974]
1 0	#energy_storage_limits[975]
1 0	#energy_storage_limits[976]
1 0	#energy_storage_limits[977]
1 0	#energy_storage_limits[978]
1 0	#energy_storage_limits[979]
1 0	#energy_storage_limits[980]
1 0	#energy_storage_limits[981]
1 0	#energy_storage_limits[982]
1 0	#energy_storage_limits[983]
1 0	#energy_storage_limits[984]
1 0	#energy_storage_limits[985]
1 0	#energy_storage_limits[986]
1 0	#energy_storage_limits[987]
1 0	#energy_storage_limits[988]
1 0	#energy_storage_limits[989]
1 0	#energy_storage_limits[990]
1 0	#energy_storage_limits[991]
1 0	#energy_storage_limits[992]
1 0	#energy_storage_limits[993]
1 0	#energy_storage_limits[994]
1 0	#energy_storage_limits[995]
1 0	#energy_storage_limits[996]
1 0	#energy_storage_limits[997]
1 0	#energy_storage_limits[998]
1 0	#energy_storage_limits[999]
1 0	#energy_storage_limits[1000]
1 0	#energy_storage_limits[1001]
1 0	#energy_storage_limits[1002]
1 0	#energy_storage_limits[1003]
1 0	#energy_storage_limits[1004]
1 0	#energy_storage_limits[1005]
1 0	#energy_storage_limits[1006]
1 0	#energy_storage_limits[1007]
1 0	#energy_storage_limits[1008]
1 0	#energy_storage_limits[1009]
1 0	#energy_storage_limits[1010]
1 0	#energy_storage_limits[1011]
1 0	#energy_storage_limits[1012]
1 0	#energy_storage_limits[1013]
1 0	#energy_storage_limits[1014]
1 0	#energy_storage_limits[1015]
1 0	#energy_storage_limits[1016]
1 0	#energy_storage_limits[1017]
1 0	#energy_storage_limits[1018]
1 0	#energy_storage_limits[1019]
1 0	#energy_storage_limits[1020]
1 0	#energy_storage_limits[1021]
1 0	#energy_storage_limits[1022]
1 0	#energy_storage_limits[1023]
1 0	#energy_storage_limits[1024]
1 0	#energy_storage_limits[1025]
1 0	#energy_storage_limits[1026]
1 0	#energy_storage_limits[1027]
1 0	#energy_storage_limits[1028]
1 0	#energy_storage_limits[1029]
1 0	#energy_storage_limits[1030]
1 0	#energy_storage_limits[1031]
1 0	#energy_storage_limits[1032]
1 0	#energy_storage_limits[1033]
1 0	#energy_storage_limits[1034]
1 0	#energy_storage_limits[1035]
1 0	#energy_storage_limits[1036]
1 0	#energy_storage_limits[1037]
1 0	#energy_storage_limits[1038]
1 0	#energy_storage_limits[1039]
1 0	#energy_storage_limits[1040]
1 0	#energy_storage_limits[1041]
1 0	#energy_storage_limits[1042]
1 0	#energy_storage_limits[1043]
1 0	#energy_storage_limits[1044]
1 0	#energy_storage_limits[1045]
1 0	#energy_storage_limits[1046]
1 0	#energy_storage_limits[1047]
1 0	#energy_storage_limits[1048]
1 0	#energy_storage_limits[1049]
1 0	#energy_storage_limits[1050]
1 0	#energy_storage_limits[1051]
1 0	#energy_storage_limits[1052]
1 0	#energy_storage_limits[1053]
1 0	#energy_storage_limits[1054]
1 0	#energy_storage_limits[1055]
1 0	#energy_storage_limits[1056]
1 0	#energy_storage_limits[1057]
1 0	#energy_storage_limits[1058]
1 0	#energy_storage_limits[1059]
1 0	#energy_storage_limits[1060]
1 0	#energy_storage_limits[1061]
1 0	#energy_storage_limits[1062]
1 0	#energy_storage_limits[1063]
1 0	#energy_storage_limits[1064]
1 0	#energy_storage_limits[1065]
1 0	#energy_storage_limits[1066]
1 0	#energy_storage_limits[1067]
1 0	#energy_storage_limits[1068]
1 0	#energy_storage_limits[1069]
1 0	#energy_storage_limits[1070]
1 0	#energy_storage_limits[1071]
1 0	#energy_storage_limits[1072]
1 0	#energy_storage_limits[1073]
1 0	#energy_storage_limits[1074]
1 0	#energy_storage_limits[1075]
1 0	#energy_storage_limits[1076]
1 0	#energy_storage_limits[1077]
1 0	#energy_storage_limits[1078]
1 0	#energy_storage_limits[1079]
1 0	#energy_storage_limits[1080]
1 0	#energy_storage_limits[1081]
1 0	#energy_storage_limits[1082]
1 0	#energy_storage_limits[1083]
1 0	#energy_storage_limits[1084]
1 0	#energy_storage_limits[1085]
1 0	#energy_storage_limits[1086]
1 0	#energy_storage_limits[1087]
1 0	#energy_storage_limits[1088]
1 0	#energy_storage_limits[1089]
1 0	#energy_storage_limits[1090]
1 0	#energy_storage_limits[1091]
1 0	#energy_storage_limits[1092]
1 0	#energy_storage_limits[1093]
1 0	#energy_storage_limits[1094]
1 0	#energy_storage_limits[1095]
1 0	#energy_storage_limits[1096]
1 0	#energy_storage_limits[1097]
1 0	#energy_storage_limits[1098]
1 0	#energy_storage_limits[1099]
1 0	#energy_storage_limits[1100]
1 0	#energy_storage_limits[1101]
1 0	#energy_storage_limits[1102]
1 0	#energy_storage_limits[1103]
1 0	#energy_storage_limits[1104]
1 0	#energy_storage_limits[1105]
1 0	#energy_storage_limits[1106]
1 0	#energy_storage_limits[1107]
1 0	#energy_storage_limits[1108]
1 0	#energy_storage_limits[1109]
1 0	#energy_storage_limits[1110]
1 0	#energy_storage_limits[1111]
1 0	#energy_storage_limits[1112]
1 0	#energy_storage_limits[1113]
1 0	#energy_storage_limits[1114]
1 0	#energy_storage_limits[1115]
1 0	#energy_storage_limits[1116]
1 0	#energy_storage_limits[1117]
1 0	#energy_storage_limits[1118]
1 0	#energy_storage_limits[1119]
1 0	#energy_storage_limits[1120]
1 0	#energy_storage_limits[1121]
1 0	#energy_storage_limits[1122]
1 0	#energy_storage_limits[1123]
1 0	#energy_storage_limits[1124]
1 0	#energy_storage_limits[1125]
1 0	#energy_storage_limits[1126]
1 0	#energy_storage_limits[1127]
1 0	#energy_storage_limits[1128]
1 0	#energy_storage_limits[1129]
1 0	#energy_storage_limits[1130]
1 0	#energy_storage_limits[1131]
1 0	#energy_storage_limits[1132]
1 0	#energy_storage_limits[1133]
1 0	#energy_storage_limits[1134]
1 0	#energy_storage_limits[1135]
1 0	#energy_storage_limits[1136]
1 0	#energy_storage_limits[1137]
1 0	#energy_storage_limits[1138]
1 0	#energy_storage_limits[1139]
1 0	#energy_storage_limits[1140]
1 0	#energy_storage_limits[1141]
1 0	#energy_storage_limits[1142]
1 0	#energy_storage_limits[1143]
1 0	#energy_storage_limits[1144]
1 0	#energy_storage_limits[1145]
1 0	#energy_storage_limits[1146]
1 0	#energy_storage_limits[1147]
1 0	#energy_storage_limits[1148]
1 0	#energy_storage_limits[1149]
1 0	#energy_storage_limits[1150]
1 0	#energy_storage_limits[1151]
1 0	#energy_storage_limits[1152]
4 0.0	#energy_storage_operation_agg[1]
4 0.0	#energy_storage_operation_agg[3]
4 0.0	#energy_storage_operation_agg[5]
4 0.0	#energy_storage_operation_agg[7]
4 0.0	#energy_storage_operation_agg[9]
4 0.0	#energy_storage_operation_agg[11]
4 0.0	#energy_storage_operation_agg[13]
4 0.0	#energy_storage_operation_agg[15]
4 0.0	#energy_storage_operation_agg[17]
4 0.0	#energy_storage_operation_agg[19]
4 0.0	#energy_storage_operation_agg[21]
4 0.0	#energy_storage_operation_agg[23]
4 0.0	#energy_storage_operation_agg[25]
4 0.0	#energy_storage_operation_agg[27]
4 0.0	#energy_storage_operation_agg[29]
4 0.0	#energy_storage_operation_agg[31]
4 0.0	#energy_storage_operation_agg[33]
4 0.0	#energy_storage_operation_agg[35]
4 0.0	#energy_storage_operation_agg[37]
4 0.0	#energy_storage_operation_agg[39]
4 0.0	#energy_storage_operation_agg[41]
4 0.0	#energy_storage_operation_agg[43]
4 0.0	#energy_storage_operation_agg[45]
4 0.0	#energy_storage_operation_agg[47]
4 0.0	#energy_storage_operation_agg[49]
4 0.0	#energy_storage_operation_agg[51]
4 0.0	#energy_storage_operation_agg[53]
4 0.0	#energy_storage_operation_agg[55]
4 0.0	#energy_storage_operation_agg[57]
4 0.0	#energy_storage_operation_agg[59]
4 0.0	#energy_storage_operation_agg[61]
4 0.0	#energy_storage_operation_agg[63]
4 0.0	#energy_storage_operation_agg[65]
4 0.0	#energy_storage_operation_agg[67]
4 0.0	#energy_storage_operation_agg[69]
4 0.0	#energy_storage_operation_agg[71]
4 0.0	#energy_storage_operation_agg[73]
4 0.0	#energy_storage_operation_agg[75]
4 0.0	#energy_storage_operation_agg[77]
4 0.0	#energy_storage_operation_agg[79]
4 0.0	#energy_storage_operation_agg[81]
4 0.0	#energy_storage_operation_agg[83]
4 0.0	#energy_storage_operation_agg[85]
4 0.0	#energy_storage_operation_agg[87]
4 0.0	#energy_storage_operation_agg[89]
4 0.0	#energy_storage_operation_agg[91]
4 0.0	#energy_storage_operation_agg[93]
4 0.0	#energy_storage_operation_agg[95]
4 0.0	#energy_storage_operation_agg[97]
4 0.0	#energy_storage_operation_agg[99]
4 0.0	#energy_storage_operation_agg[101]
4 0.0	#energy_storage_operation_agg[103]
4 0.0	#energy_storage_operation_agg[105]
4 0.0	#energy_storage_operation_agg[107]
4 0.0	#energy_storage_operation_agg[109]
4 0.0	#energy_storage_operation_agg[111]
4 0.0	#energy_storage_operation_agg[113]
4 0.0	#energy_storage_operation_agg[115]
4 0.0	#energy_storage_operation_agg[117]
4 0.0	#energy_storage_operation_agg[119]
4 0.0	#energy_storage_operation_agg[121]
4 0.0	#energy_storage_operation_agg[123]
4 0.0	#energy_storage_operation_agg[125]
4 0.0	#energy_storage_operation_agg[127]
4 0.0	#energy_storage_operation_agg[129]
4 0.0	#energy_storage_operation_agg[131]
4 0.0	#energy_storage_operation_agg[133]
4 0.0	#energy_storage_operation_agg[135]
4 0.0	#energy_storage_operation_agg[137]
4 0.0	#energy_storage_operation_agg[139]
4 0.0	#energy_storage_operation_agg[141]
4 0.0	#energy_storage_operation_agg[143]
4 0.0	#energy_storage_operation_agg[145]
4 0.0	#energy_storage_operation_agg[147]
4 0.0	#energy_storage_operation_agg[149]
4 0.0	#energy_storage_operation_agg[151]
4 0.0	#energy_storage_operation_agg[153]
4 0.0	#energy_storage_operation_agg[155]
4 0.0	#energy_storage_operation_agg[157]
4 0.0	#energy_storage_operation_agg[159]
4 0.0	#energy_storage_operation_agg[161]
4 0.0	#energy_storage_operation_agg[163]
4 0.0	#energy_storage_operation_agg[165]
4 0.0	#energy_storage_operation_agg[167]
4 0.0	#energy_storage_operation_agg[169]
4 0.0	#energy_storage_operation_agg[171]
4 0.0	#energy_storage_operation_agg[173]
4 0.0	#energy_storage_operation_agg[175]
4 0.0	#energy_storage_operation_agg[177]
4 0.0	#energy_storage_operation_agg[179]
4 0.0	#energy_storage_operation_agg[181]
4 0.0	#energy_storage_operation_agg[183]
4 0.0	#energy_storage_operation_agg[185]
4 0.0	#energy_storage_operation_agg[187]
4 0.0	#energy_storage_operation_agg[189]
4 0.0	#energy_storage_operation_agg[191]
4 0.0	#energy_storage_operation_agg[193]
4 0.0	#energy_storage_operation_agg[195]
4 0.0	#energy_storage_operation_agg[197]
4 0.0	#energy_storage_operation_agg[199]
4 0.0	#energy_storage_operation_agg[201]
4 0.0	#energy_storage_operation_agg[203]
4 0.0	#energy_storage_operation_agg[205]
4 0.0	#energy_storage_operation_agg[207]
4 0.0	#energy_storage_operation_agg[209]
4 0.0	#energy_storage_operation_agg[211]
4 0.0	#energy_storage_operation_agg[213]
4 0.0	#energy_storage_operation_agg[215]
4 0.0	#energy_storage_operation_agg[217]
4 0.0	#energy_storage_operation_agg[219]
4 0.0	#energy_storage_operation_agg[221]
4 0.0	#energy_storage_operation_agg[223]
4 0.0	#energy_storage_operation_agg[225]
4 0.0	#energy_storage_operation_agg[227]
4 0.0	#energy_storage_operation_agg[229]
4 0.0	#energy_storage_operation_agg[231]
4 0.0	#energy_storage_operation_agg[233]
4 0.0	#energy_storage_operation_agg[235]
4 0.0	#energy_storage_operation_agg[237]
4 0.0	#energy_storage_operation_agg[239]
4 0.0	#energy_storage_operation_agg[241]
4 0.0	#energy_storage_operation_agg[243]
4 0.0	#energy_storage_operation_agg[245]
4 0.0	#energy_storage_operation_agg[247]
4 0.0	#energy_storage_operation_agg[249]
4 0.0	#energy_storage_operation_agg[251]
4 0.0	#energy_storage_operation_agg[253]
4 0.0	#energy_storage_operation_agg[255]
4 0.0	#energy_storage_operation_agg[257]
4 0.0	#energy_storage_operation_agg[259]
4 0.0	#energy_storage_operation_agg[261]
4 0.0	#energy_storage_operation_agg[263]
4 0.0	#energy_storage_operation_agg[265]
4 0.0	#energy_storage_operation_agg[267]
4 0.0	#energy_storage_operation_agg[269]
4 0.0	#energy_storage_operation_agg[271]
4 0.0	#energy_storage_operation_agg[273]
4 0.0	#energy_storage_operation_agg[275]
4 0.0	#energy_storage_operation_agg[277]
4 0.0	#energy_storage_operation_agg[279]
4 0.0	#energy_storage_operation_agg[281]
4 0.0	#energy_storage_operation_agg[283]
4 0.0	#energy_storage_operation_agg[285]
4 0.0	#energy_storage_operation_agg[287]
4 0.0	#energy_storage_operation_agg[289]
4 0.0	#energy_storage_operation_agg[291]
4 0.0	#energy_storage_operation_agg[293]
4 0.0	#energy_storage_operation_agg[295]
4 0.0	#energy_storage_operation_agg[297]
4 0.0	#energy_storage_operation_agg[299]
4 0.0	#energy_storage_operation_agg[301]
4 0.0	#energy_storage_operation_agg[303]
4 0.0	#energy_storage_operation_agg[305]
4 0.0	#energy_storage_operation_agg[307]
4 0.0	#energy_storage_operation_agg[309]
4 0.0	#energy_storage_operation_agg[311]
4 0.0	#energy_storage_operation_agg[313]
4 0.0	#energy_storage_operation_agg[315]
4 0.0	#energy_storage_operation_agg[317]
4 0.0	#energy_storage_operation_agg[319]
4 0.0	#energy_storage_operation_agg[321]
4 0.0	#energy_storage_operation_agg[323]
4 0.0	#energy_storage_operation_agg[325]
4 0.0	#energy_storage_operation_agg[327]
4 0.0	#energy_storage_operation_agg[329]
4 0.0	#energy_storage_operation_agg[331]
4 0.0	#energy_storage_operation_agg[333]
4 0.0	#energy_storage_operation_agg[335]
4 0.0	#energy_storage_operation_agg[337]
4 0.0	#energy_storage_operation_agg[339]
4 0.0	#energy_storage_operation_agg[341]
4 0.0	#energy_storage_operation_agg[343]
4 0.0	#energy_storage_operation_agg[345]
4 0.0	#energy_storage_operation_agg[347]
4 0.0	#energy_storage_operation_agg[349]
4 0.0	#energy_storage_operation_agg[351]
4 0.0	#energy_storage_operation_agg[353]
4 0.0	#energy_storage_operation_agg[355]
4 0.0	#energy_storage_operation_agg[357]
4 0.0	#energy_storage_operation_agg[359]
4 0.0	#energy_storage_operation_agg[361]
4 0.0	#energy_storage_operation_agg[363]
4 0.0	#energy_storage_operation_agg[365]
4 0.0	#energy_storage_operation_agg[367]
4 0.0	#energy_storage_operation_agg[369]
4 0.0	#energy_storage_operation_agg[371]
4 0.0	#energy_storage_operation_agg[373]
4 0.0	#energy_storage_operation_agg[375]
4 0.0	#energy_storage_operation_agg[377]
4 0.0	#energy_storage_operation_agg[379]
4 0.0	#energy_storage_operation_agg[381]
4 0.0	#energy_storage_operation_agg[383]
4 0.0	#energy_storage_operation_agg[385]
4 0.0	#energy_storage_operation_agg[387]
4 0.0	#energy_storage_operation_agg[389]
4 0.0	#energy_storage_operation_agg[391]
4 0.0	#energy_storage_operation_agg[393]
4 0.0	#energy_storage_operation_agg[395]
4 0.0	#energy_storage_operation_agg[397]
4 0.0	#energy_storage_operation_agg[399]
4 0.0	#energy_storage_operation_agg[401]
4 0.0	#energy_storage_operation_agg[403]
4 0.0	#energy_storage_operation_agg[405]
4 0.0	#energy_storage_operation_agg[407]
4 0.0	#energy_storage_operation_agg[409]
4 0.0	#energy_storage_operation_agg[411]
4 0.0	#energy_storage_operation_agg[413]
4 0.0	#energy_storage_operation_agg[415]
4 0.0	#energy_storage_operation_agg[417]
4 0.0	#energy_storage_operation_agg[419]
4 0.0	#energy_storage_operation_agg[421]
4 0.0	#energy_storage_operation_agg[423]
4 0.0	#energy_storage_operation_agg[425]
4 0.0	#energy_storage_operation_agg[427]
4 0.0	#energy_storage_operation_agg[429]
4 0.0	#energy_storage_operation_agg[431]
4 0.0	#energy_storage_operation_agg[433]
4 0.0	#energy_storage_operation_agg[435]
4 0.0	#energy_storage_operation_agg[437]
4 0.0	#energy_storage_operation_agg[439]
4 0.0	#energy_storage_operation_agg[441]
4 0.0	#energy_storage_operation_agg[443]
4 0.0	#energy_storage_operation_agg[445]
4 0.0	#energy_storage_operation_agg[447]
4 0.0	#energy_storage_operation_agg[449]
4 0.0	#energy_storage_operation_agg[451]
4 0.0	#energy_storage_operation_agg[453]
4 0.0	#energy_storage_operation_agg[455]
4 0.0	#energy_storage_operation_agg[457]
4 0.0	#energy_storage_operation_agg[459]
4 0.0	#energy_storage_operation_agg[461]
4 0.0	#energy_storage_operation_agg[463]
4 0.0	#energy_storage_operation_agg[465]
4 0.0	#energy_storage_operation_agg[467]
4 0.0	#energy_storage_operation_agg[469]
4 0.0	#energy_storage_operation_agg[471]
4 0.0	#energy_storage_operation_agg[473]
4 0.0	#energy_storage_operation_agg[475]
4 0.0	#energy_storage_operation_agg[477]
4 0.0	#energy_storage_operation_agg[479]
4 0.0	#energy_storage_operation_agg[481]
4 0.0	#energy_storage_operation_agg[483]
4 0.0	#energy_storage_operation_agg[485]
4 0.0	#energy_storage_operation_agg[487]
4 0.0	#energy_storage_operation_agg[489]
4 0.0	#energy_storage_operation_agg[491]
4 0.0	#energy_storage_operation_agg[493]
4 0.0	#energy_storage_operation_agg[495]
4 0.0	#energy_storage_operation_agg[497]
4 0.0	#energy_storage_operation_agg[499]
4 0.0	#energy_storage_operation_agg[501]
4 0.0	#energy_storage_operation_agg[503]
4 0.0	#energy_storage_operation_agg[505]
4 0.0	#energy_storage_operation_agg[507]
4 0.0	#energy_storage_operation_agg[509]
4 0.0	#energy_storage_operation_agg[511]
4 0.0	#energy_storage_operation_agg[513]
4 0.0	#energy_storage_operation_agg[515]
4 0.0	#energy_storage_operation_agg[517]
4 0.0	#energy_storage_operation_agg[519]
4 0.0	#energy_storage_operation_agg[521]
4 0.0	#energy_storage_operation_agg[523]
4 0.0	#energy_storage_operation_agg[525]
4 0.0	#energy_storage_operation_agg[527]
4 0.0	#energy_storage_operation_agg[529]
4 0.0	#energy_storage_operation_agg[531]
4 0.0	#energy_storage_operation_agg[533]
4 0.0	#energy_storage_operation_agg[535]
4 0.0	#energy_storage_operation_agg[537]
4 0.0	#energy_storage_operation_agg[539]
4 0.0	#energy_storage_operation_agg[541]
4 0.0	#energy_storage_operation_agg[543]
4 0.0	#energy_storage_operation_agg[545]
4 0.0	#energy_storage_operation_agg[547]
4 0.0	#energy_storage_operation_agg[549]
4 0.0	#energy_storage_operation_agg[551]
4 0.0	#energy_storage_operation_agg[553]
4 0.0	#energy_storage_operation_agg[555]
4 0.0	#energy_storage_operation_agg[557]
4 0.0	#energy_storage_operation_agg[559]
4 0.0	#energy_storage_operation_agg[561]
4 0.0	#energy_storage_operation_agg[563]
4 0.0	#energy_storage_operation_agg[565]
4 0.0	#energy_storage_operation_agg[567]
4 0.0	#energy_storage_operation_agg[569]
4 0.0	#energy_storage_operation_agg[571]
4 0.0	#energy_storage_operation_agg[573]
4 0.0	#energy_storage_operation_agg[575]
b	#1002 bounds (on variables)
2 0	#es_e_rated_per_unit[1,1]
2 0	#es_e_rated_per_unit[1,2]
2 0	#es_s_rated[0]
2 0	#es_s_rated[1]
2 0	#es_s_rated[2]
0 0.0 1.0	#es_soh_per_unit_cumul[1,1]
0 0.0 1.0	#es_soh_per_unit_cumul[1,2]
2 0	#es_D_per_unit[1,1]
2 0	#es_D_per_unit[1,2]
2 0	#slack_es_pnet_up[0,0,0]
2 0	#slack_es_pnet_up[0,0,1]
2 0	#slack_es_pnet_up[0,0,2]
2 0	#slack_es_pnet_up[0,0,3]
2 0	#slack_es_pnet_up[0,0,4]
2 0	#slack_es_pnet_up[0,0,5]
2 0	#slack_es_pnet_up[0,0,6]
2 0	#slack_es_pnet_up[0,0,7]
2 0	#slack_es_pnet_up[0,0,8]
2 0	#slack_es_pnet_up[0,0,9]
2 0	#slack_es_pnet_up[0,0,10]
2 0	#slack_es_pnet_up[0,0,11]
2 0	#slack_es_pnet_up[0,0,12]
2 0	#slack_es_pnet_up[0,0,13]
2 0	#slack_es_pnet_up[0,0,14]
2 0	#slack_es_pnet_up[0,0,15]
2 0	#slack_es_pnet_up[0,0,16]
2 0	#slack_es_pnet_up[0,0,17]
2 0	#slack_es_pnet_up[0,0,18]
2 0	#slack_es_pnet_up[0,0,19]
2 0	#slack_es_pnet_up[0,0,20]
2 0	#slack_es_pnet_up[0,0,21]
2 0	#slack_es_pnet_up[0,0,22]
2 0	#slack_es_pnet_up[0,0,23]
2 0	#slack_es_pnet_up[0,1,0]
2 0	#slack_es_pnet_up[0,1,1]
2 0	#slack_es_pnet_up[0,1,2]
2 0	#slack_es_pnet_up[0,1,3]
2 0	#slack_es_pnet_up[0,1,4]
2 0	#slack_es_pnet_up[0,1,5]
2 0	#slack_es_pnet_up[0,1,6]
2 0	#slack_es_pnet_up[0,1,7]
2 0	#slack_es_pnet_up[0,1,8]
2 0	#slack_es_pnet_up[0,1,9]
2 0	#slack_es_pnet_up[0,1,10]
2 0	#slack_es_pnet_up[0,1,11]
2 0	#slack_es_pnet_up[0,1,12]
2 0	#slack_es_pnet_up[0,1,13]
2 0	#slack_es_pnet_up[0,1,14]
2 0	#slack_es_pnet_up[0,1,15]
2 0	#slack_es_pnet_up[0,1,16]
2 0	#slack_es_pnet_up[0,1,17]
2 0	#slack_es_pnet_up[0,1,18]
2 0	#slack_es_pnet_up[0,1,19]
2 0	#slack_es_pnet_up[0,1,20]
2 0	#slack_es_pnet_up[0,1,21]
2 0	#slack_es_pnet_up[0,1,22]
2 0	#slack_es_pnet_up[0,1,23]
2 0	#slack_es_pnet_up[0,2,0]
2 0	#slack_es_pnet_up[0,2,1]
2 0	#slack_es_pnet_up[0,2,2]
2 0	#slack_es_pnet_up[0,2,3]
2 0	#slack_es_pnet_up[0,2,4]
2 0	#slack_es_pnet_up[0,2,5]
2 0	#slack_es_pnet_up[0,2,6]
2 0	#slack_es_pnet_up[0,2,7]
2 0	#slack_es_pnet_up[0,2,8]
2 0	#slack_es_pnet_up[0,2,9]
2 0	#slack_es_pnet_up[0,2,10]
2 0	#slack_es_pnet_up[0,2,11]
2 0	#slack_es_pnet_up[0,2,12]
2 0	#slack_es_pnet_up[0,2,13]
2 0	#slack_es_pnet_up[0,2,14]
2 0	#slack_es_pnet_up[0,2,15]
2 0	#slack_es_pnet_up[0,2,16]
2 0	#slack_es_pnet_up[0,2,17]
2 0	#slack_es_pnet_up[0,2,18]
2 0	#slack_es_pnet_up[0,2,19]
2 0	#slack_es_pnet_up[0,2,20]
2 0	#slack_es_pnet_up[0,2,21]
2 0	#slack_es_pnet_up[0,2,22]
2 0	#slack_es_pnet_up[0,2,23]
2 0	#slack_es_pnet_up[0,3,0]
2 0	#slack_es_pnet_up[0,3,1]
2 0	#slack_es_pnet_up[0,3,2]
2 0	#slack_es_pnet_up[0,3,3]
2 0	#slack_es_pnet_up[0,3,4]
2 0	#slack_es_pnet_up[0,3,5]
2 0	#slack_es_pnet_up[0,3,6]
2 0	#slack_es_pnet_up[0,3,7]
2 0	#slack_es_pnet_up[0,3,8]
2 0	#slack_es_pnet_up[0,3,9]
2 0	#slack_es_pnet_up[0,3,10]
2 0	#slack_es_pnet_up[0,3,11]
2 0	#slack_es_pnet_up[0,3,12]
2 0	#slack_es_pnet_up[0,3,13]
2 0	#slack_es_pnet_up[0,3,14]
2 0	#slack_es_pnet_up[0,3,15]
2 0	#slack_es_pnet_up[0,3,16]
2 0	#slack_es_pnet_up[0,3,17]
2 0	#slack_es_pnet_up[0,3,18]
2 0	#slack_es_pnet_up[0,3,19]
2 0	#slack_es_pnet_up[0,3,20]
2 0	#slack_es_pnet_up[0,3,21]
2 0	#slack_es_pnet_up[0,3,22]
2 0	#slack_es_pnet_up[0,3,23]
2 0	#slack_es_pnet_up[1,0,0]
2 0	#slack_es_pnet_up[1,0,1]
2 0	#slack_es_pnet_up[1,0,2]
2 0	#slack_es_pnet_up[1,0,3]
2 0	#slack_es_pnet_up[1,0,4]
2 0	#slack_es_pnet_up[1,0,5]
2 0	#slack_es_pnet_up[1,0,6]
2 0	#slack_es_pnet_up[1,0,7]
2 0	#slack_es_pnet_up[1,0,8]
2 0	#slack_es_pnet_up[1,0,9]
2 0	#slack_es_pnet_up[1,0,10]
2 0	#slack_es_pnet_up[1,0,11]
2 0	#slack_es_pnet_up[1,0,12]
2 0	#slack_es_pnet_up[1,0,13]
2 0	#slack_es_pnet_up[1,0,14]
2 0	#slack_es_pnet_up[1,0,15]
2 0	#slack_es_pnet_up[1,0,16]
2 0	#slack_es_pnet_up[1,0,17]
2 0	#slack_es_pnet_up[1,0,18]
2 0	#slack_es_pnet_up[1,0,19]
2 0	#slack_es_pnet_up[1,0,20]
2 0	#slack_es_pnet_up[1,0,21]
2 0	#slack_es_pnet_up[1,0,22]
2 0	#slack_es_pnet_up[1,0,23]
2 0	#slack_es_pnet_up[1,1,0]
2 0	#slack_es_pnet_up[1,1,1]
2 0	#slack_es_pnet_up[1,1,2]
2 0	#slack_es_pnet_up[1,1,3]
2 0	#slack_es_pnet_up[1,1,4]
2 0	#slack_es_pnet_up[1,1,5]
2 0	#slack_es_pnet_up[1,1,6]
2 0	#slack_es_pnet_up[1,1,7]
2 0	#slack_es_pnet_up[1,1,8]
2 0	#slack_es_pnet_up[1,1,9]
2 0	#slack_es_pnet_up[1,1,10]
2 0	#slack_es_pnet_up[1,1,11]
2 0	#slack_es_pnet_up[1,1,12]
2 0	#slack_es_pnet_up[1,1,13]
2 0	#slack_es_pnet_up[1,1,14]
2 0	#slack_es_pnet_up[1,1,15]
2 0	#slack_es_pnet_up[1,1,16]
2 0	#slack_es_pnet_up[1,1,17]
2 0	#slack_es_pnet_up[1,1,18]
2 0	#slack_es_pnet_up[1,1,19]
2 0	#slack_es_pnet_up[1,1,20]
2 0	#slack_es_pnet_up[1,1,21]
2 0	#slack_es_pnet_up[1,1,22]
2 0	#slack_es_pnet_up[1,1,23]
2 0	#slack_es_pnet_up[1,2,0]
2 0	#slack_es_pnet_up[1,2,1]
2 0	#slack_es_pnet_up[1,2,2]
2 0	#slack_es_pnet_up[1,2,3]
2 0	#slack_es_pnet_up[1,2,4]
2 0	#slack_es_pnet_up[1,2,5]
2 0	#slack_es_pnet_up[1,2,6]
2 0	#slack_es_pnet_up[1,2,7]
2 0	#slack_es_pnet_up[1,2,8]
2 0	#slack_es_pnet_up[1,2,9]
2 0	#slack_es_pnet_up[1,2,10]
2 0	#slack_es_pnet_up[1,2,11]
2 0	#slack_es_pnet_up[1,2,12]
2 0	#slack_es_pnet_up[1,2,13]
2 0	#slack_es_pnet_up[1,2,14]
2 0	#slack_es_pnet_up[1,2,15]
2 0	#slack_es_pnet_up[1,2,16]
2 0	#slack_es_pnet_up[1,2,17]
2 0	#slack_es_pnet_up[1,2,18]
2 0	#slack_es_pnet_up[1,2,19]
2 0	#slack_es_pnet_up[1,2,20]
2 0	#slack_es_pnet_up[1,2,21]
2 0	#slack_es_pnet_up[1,2,22]
2 0	#slack_es_pnet_up[1,2,23]
2 0	#slack_es_pnet_up[1,3,0]
2 0	#slack_es_pnet_up[1,3,1]
2 0	#slack_es_pnet_up[1,3,2]
2 0	#slack_es_pnet_up[1,3,3]
2 0	#slack_es_pnet_up[1,3,4]
2 0	#slack_es_pnet_up[1,3,5]
2 0	#slack_es_pnet_up[1,3,6]
2 0	#slack_es_pnet_up[1,3,7]
2 0	#slack_es_pnet_up[1,3,8]
2 0	#slack_es_pnet_up[1,3,9]
2 0	#slack_es_pnet_up[1,3,10]
2 0	#slack_es_pnet_up[1,3,11]
2 0	#slack_es_pnet_up[1,3,12]
2 0	#slack_es_pnet_up[1,3,13]
2 0	#slack_es_pnet_up[1,3,14]
2 0	#slack_es_pnet_up[1,3,15]
2 0	#slack_es_pnet_up[1,3,16]
2 0	#slack_es_pnet_up[1,3,17]
2 0	#slack_es_pnet_up[1,3,18]
2 0	#slack_es_pnet_up[1,3,19]
2 0	#slack_es_pnet_up[1,3,20]
2 0	#slack_es_pnet_up[1,3,21]
2 0	#slack_es_pnet_up[1,3,22]
2 0	#slack_es_pnet_up[1,3,23]
2 0	#slack_es_pnet_up[2,0,0]
2 0	#slack_es_pnet_up[2,0,1]
2 0	#slack_es_pnet_up[2,0,2]
2 0	#slack_es_pnet_up[2,0,3]
2 0	#slack_es_pnet_up[2,0,4]
2 0	#slack_es_pnet_up[2,0,5]
2 0	#slack_es_pnet_up[2,0,6]
2 0	#slack_es_pnet_up[2,0,7]
2 0	#slack_es_pnet_up[2,0,8]
2 0	#slack_es_pnet_up[2,0,9]
2 0	#slack_es_pnet_up[2,0,10]
2 0	#slack_es_pnet_up[2,0,11]
2 0	#slack_es_pnet_up[2,0,12]
2 0	#slack_es_pnet_up[2,0,13]
2 0	#slack_es_pnet_up[2,0,14]
2 0	#slack_es_pnet_up[2,0,15]
2 0	#slack_es_pnet_up[2,0,16]
2 0	#slack_es_pnet_up[2,0,17]
2 0	#slack_es_pnet_up[2,0,18]
2 0	#slack_es_pnet_up[2,0,19]
2 0	#slack_es_pnet_up[2,0,20]
2 0	#slack_es_pnet_up[2,0,21]
2 0	#slack_es_pnet_up[2,0,22]
2 0	#slack_es_pnet_up[2,0,23]
2 0	#slack_es_pnet_up[2,1,0]
2 0	#slack_es_pnet_up[2,1,1]
2 0	#slack_es_pnet_up[2,1,2]
2 0	#slack_es_pnet_up[2,1,3]
2 0	#slack_es_pnet_up[2,1,4]
2 0	#slack_es_pnet_up[2,1,5]
2 0	#slack_es_pnet_up[2,1,6]
2 0	#slack_es_pnet_up[2,1,7]
2 0	#slack_es_pnet_up[2,1,8]
2 0	#slack_es_pnet_up[2,1,9]
2 0	#slack_es_pnet_up[2,1,10]
2 0	#slack_es_pnet_up[2,1,11]
2 0	#slack_es_pnet_up[2,1,12]
2 0	#slack_es_pnet_up[2,1,13]
2 0	#slack_es_pnet_up[2,1,14]
2 0	#slack_es_pnet_up[2,1,15]
2 0	#slack_es_pnet_up[2,1,16]
2 0	#slack_es_pnet_up[2,1,17]
2 0	#slack_es_pnet_up[2,1,18]
2 0	#slack_es_pnet_up[2,1,19]
2 0	#slack_es_pnet_up[2,1,20]
2 0	#slack_es_pnet_up[2,1,21]
2 0	#slack_es_pnet_up[2,1,22]
2 0	#slack_es_pnet_up[2,1,23]
2 0	#slack_es_pnet_up[2,2,0]
2 0	#slack_es_pnet_up[2,2,1]
2 0	#slack_es_pnet_up[2,2,2]
2 0	#slack_es_pnet_up[2,2,3]
2 0	#slack_es_pnet_up[2,2,4]
2 0	#slack_es_pnet_up[2,2,5]
2 0	#slack_es_pnet_up[2,2,6]
2 0	#slack_es_pnet_up[2,2,7]
2 0	#slack_es_pnet_up[2,2,8]
2 0	#slack_es_pnet_up[2,2,9]
2 0	#slack_es_pnet_up[2,2,10]
2 0	#slack_es_pnet_up[2,2,11]
2 0	#slack_es_pnet_up[2,2,12]
2 0	#slack_es_pnet_up[2,2,13]
2 0	#slack_es_pnet_up[2,2,14]
2 0	#slack_es_pnet_up[2,2,15]
2 0	#slack_es_pnet_up[2,2,16]
2 0	#slack_es_pnet_up[2,2,17]
2 0	#slack_es_pnet_up[2,2,18]
2 0	#slack_es_pnet_up[2,2,19]
2 0	#slack_es_pnet_up[2,2,20]
2 0	#slack_es_pnet_up[2,2,21]
2 0	#slack_es_pnet_up[2,2,22]
2 0	#slack_es_pnet_up[2,2,23]
2 0	#slack_es_pnet_up[2,3,0]
2 0	#slack_es_pnet_up[2,3,1]
2 0	#slack_es_pnet_up[2,3,2]
2 0	#slack_es_pnet_up[2,3,3]
2 0	#slack_es_pnet_up[2,3,4]
2 0	#slack_es_pnet_up[2,3,5]
2 0	#slack_es_pnet_up[2,3,6]
2 0	#slack_es_pnet_up[2,3,7]
2 0	#slack_es_pnet_up[2,3,8]
2 0	#slack_es_pnet_up[2,3,9]
2 0	#slack_es_pnet_up[2,3,10]
2 0	#slack_es_pnet_up[2,3,11]
2 0	#slack_es_pnet_up[2,3,12]
2 0	#slack_es_pnet_up[2,3,13]
2 0	#slack_es_pnet_up[2,3,14]
2 0	#slack_es_pnet_up[2,3,15]
2 0	#slack_es_pnet_up[2,3,16]
2 0	#slack_es_pnet_up[2,3,17]
2 0	#slack_es_pnet_up[2,3,18]
2 0	#slack_es_pnet_up[2,3,19]
2 0	#slack_es_pnet_up[2,3,20]
2 0	#slack_es_pnet_up[2,3,21]
2 0	#slack_es_pnet_up[2,3,22]
2 0	#slack_es_pnet_up[2,3,23]
2 0	#slack_es_pnet_down[0,0,0]
2 0	#slack_es_pnet_down[0,0,1]
2 0	#slack_es_pnet_down[0,0,2]
2 0	#slack_es_pnet_down[0,0,3]
2 0	#slack_es_pnet_down[0,0,4]
2 0	#slack_es_pnet_down[0,0,5]
2 0	#slack_es_pnet_down[0,0,6]
2 0	#slack_es_pnet_down[0,0,7]
2 0	#slack_es_pnet_down[0,0,8]
2 0	#slack_es_pnet_down[0,0,9]
2 0	#slack_es_pnet_down[0,0,10]
2 0	#slack_es_pnet_down[0,0,11]
2 0	#slack_es_pnet_down[0,0,12]
2 0	#slack_es_pnet_down[0,0,13]
2 0	#slack_es_pnet_down[0,0,14]
2 0	#slack_es_pnet_down[0,0,15]
2 0	#slack_es_pnet_down[0,0,16]
2 0	#slack_es_pnet_down[0,0,17]
2 0	#slack_es_pnet_down[0,0,18]
2 0	#slack_es_pnet_down[0,0,19]
2 0	#slack_es_pnet_down[0,0,20]
2 0	#slack_es_pnet_down[0,0,21]
2 0	#slack_es_pnet_down[0,0,22]
2 0	#slack_es_pnet_down[0,0,23]
2 0	#slack_es_pnet_down[0,1,0]
2 0	#slack_es_pnet_down[0,1,1]
2 0	#slack_es_pnet_down[0,1,2]
2 0	#slack_es_pnet_down[0,1,3]
2 0	#slack_es_pnet_down[0,1,4]
2 0	#slack_es_pnet_down[0,1,5]
2 0	#slack_es_pnet_down[0,1,6]
2 0	#slack_es_pnet_down[0,1,7]
2 0	#slack_es_pnet_down[0,1,8]
2 0	#slack_es_pnet_down[0,1,9]
2 0	#slack_es_pnet_down[0,1,10]
2 0	#slack_es_pnet_down[0,1,11]
2 0	#slack_es_pnet_down[0,1,12]
2 0	#slack_es_pnet_down[0,1,13]
2 0	#slack_es_pnet_down[0,1,14]
2 0	#slack_es_pnet_down[0,1,15]
2 0	#slack_es_pnet_down[0,1,16]
2 0	#slack_es_pnet_down[0,1,17]
2 0	#slack_es_pnet_down[0,1,18]
2 0	#slack_es_pnet_down[0,1,19]
2 0	#slack_es_pnet_down[0,1,20]
2 0	#slack_es_pnet_down[0,1,21]
2 0	#slack_es_pnet_down[0,1,22]
2 0	#slack_es_pnet_down[0,1,23]
2 0	#slack_es_pnet_down[0,2,0]
2 0	#slack_es_pnet_down[0,2,1]
2 0	#slack_es_pnet_down[0,2,2]
2 0	#slack_es_pnet_down[0,2,3]
2 0	#slack_es_pnet_down[0,2,4]
2 0	#slack_es_pnet_down[0,2,5]
2 0	#slack_es_pnet_down[0,2,6]
2 0	#slack_es_pnet_down[0,2,7]
2 0	#slack_es_pnet_down[0,2,8]
2 0	#slack_es_pnet_down[0,2,9]
2 0	#slack_es_pnet_down[0,2,10]
2 0	#slack_es_pnet_down[0,2,11]
2 0	#slack_es_pnet_down[0,2,12]
2 0	#slack_es_pnet_down[0,2,13]
2 0	#slack_es_pnet_down[0,2,14]
2 0	#slack_es_pnet_down[0,2,15]
2 0	#slack_es_pnet_down[0,2,16]
2 0	#slack_es_pnet_down[0,2,17]
2 0	#slack_es_pnet_down[0,2,18]
2 0	#slack_es_pnet_down[0,2,19]
2 0	#slack_es_pnet_down[0,2,20]
2 0	#slack_es_pnet_down[0,2,21]
2 0	#slack_es_pnet_down[0,2,22]
2 0	#slack_es_pnet_down[0,2,23]
2 0	#slack_es_pnet_down[0,3,0]
2 0	#slack_es_pnet_down[0,3,1]
2 0	#slack_es_pnet_down[0,3,2]
2 0	#slack_es_pnet_down[0,3,3]
2 0	#slack_es_pnet_down[0,3,4]
2 0	#slack_es_pnet_down[0,3,5]
2 0	#slack_es_pnet_down[0,3,6]
2 0	#slack_es_pnet_down[0,3,7]
2 0	#slack_es_pnet_down[0,3,8]
2 0	#slack_es_pnet_down[0,3,9]
2 0	#slack_es_pnet_down[0,3,10]
2 0	#slack_es_pnet_down[0,3,11]
2 0	#slack_es_pnet_down[0,3,12]
2 0	#slack_es_pnet_down[0,3,13]
2 0	#slack_es_pnet_down[0,3,14]
2 0	#slack_es_pnet_down[0,3,15]
2 0	#slack_es_pnet_down[0,3,16]
2 0	#slack_es_pnet_down[0,3,17]
2 0	#slack_es_pnet_down[0,3,18]
2 0	#slack_es_pnet_down[0,3,19]
2 0	#slack_es_pnet_down[0,3,20]
2 0	#slack_es_pnet_down[0,3,21]
2 0	#slack_es_pnet_down[0,3,22]
2 0	#slack_es_pnet_down[0,3,23]
2 0	#slack_es_pnet_down[1,0,0]
2 0	#slack_es_pnet_down[1,0,1]
2 0	#slack_es_pnet_down[1,0,2]
2 0	#slack_es_pnet_down[1,0,3]
2 0	#slack_es_pnet_down[1,0,4]
2 0	#slack_es_pnet_down[1,0,5]
2 0	#slack_es_pnet_down[1,0,6]
2 0	#slack_es_pnet_down[1,0,7]
2 0	#slack_es_pnet_down[1,0,8]
2 0	#slack_es_pnet_down[1,0,9]
2 0	#slack_es_pnet_down[1,0,10]
2 0	#slack_es_pnet_down[1,0,11]
2 0	#slack_es_pnet_down[1,0,12]
2 0	#slack_es_pnet_down[1,0,13]
2 0	#slack_es_pnet_down[1,0,14]
2 0	#slack_es_pnet_down[1,0,15]
2 0	#slack_es_pnet_down[1,0,16]
2 0	#slack_es_pnet_down[1,0,17]
2 0	#slack_es_pnet_down[1,0,18]
2 0	#slack_es_pnet_down[1,0,19]
2 0	#slack_es_pnet_down[1,0,20]
2 0	#slack_es_pnet_down[1,0,21]
2 0	#slack_es_pnet_down[1,0,22]
2 0	#slack_es_pnet_down[1,0,23]
2 0	#slack_es_pnet_down[1,1,0]
2 0	#slack_es_pnet_down[1,1,1]
2 0	#slack_es_pnet_down[1,1,2]
2 0	#slack_es_pnet_down[1,1,3]
2 0	#slack_es_pnet_down[1,1,4]
2 0	#slack_es_pnet_down[1,1,5]
2 0	#slack_es_pnet_down[1,1,6]
2 0	#slack_es_pnet_down[1,1,7]
2 0	#slack_es_pnet_down[1,1,8]
2 0	#slack_es_pnet_down[1,1,9]
2 0	#slack_es_pnet_down[1,1,10]
2 0	#slack_es_pnet_down[1,1,11]
2 0	#slack_es_pnet_down[1,1,12]
2 0	#slack_es_pnet_down[1,1,13]
2 0	#slack_es_pnet_down[1,1,14]
2 0	#slack_es_pnet_down[1,1,15]
2 0	#slack_es_pnet_down[1,1,16]
2 0	#slack_es_pnet_down[1,1,17]
2 0	#slack_es_pnet_down[1,1,18]
2 0	#slack_es_pnet_down[1,1,19]
2 0	#slack_es_pnet_down[1,1,20]
2 0	#slack_es_pnet_down[1,1,21]
2 0	#slack_es_pnet_down[1,1,22]
2 0	#slack_es_pnet_down[1,1,23]
2 0	#slack_es_pnet_down[1,2,0]
2 0	#slack_es_pnet_down[1,2,1]
2 0	#slack_es_pnet_down[1,2,2]
2 0	#slack_es_pnet_down[1,2,3]
2 0	#slack_es_pnet_down[1,2,4]
2 0	#slack_es_pnet_down[1,2,5]
2 0	#slack_es_pnet_down[1,2,6]
2 0	#slack_es_pnet_down[1,2,7]
2 0	#slack_es_pnet_down[1,2,8]
2 0	#slack_es_pnet_down[1,2,9]
2 0	#slack_es_pnet_down[1,2,10]
2 0	#slack_es_pnet_down[1,2,11]
2 0	#slack_es_pnet_down[1,2,12]
2 0	#slack_es_pnet_down[1,2,13]
2 0	#slack_es_pnet_down[1,2,14]
2 0	#slack_es_pnet_down[1,2,15]
2 0	#slack_es_pnet_down[1,2,16]
2 0	#slack_es_pnet_down[1,2,17]
2 0	#slack_es_pnet_down[1,2,18]
2 0	#slack_es_pnet_down[1,2,19]
2 0	#slack_es_pnet_down[1,2,20]
2 0	#slack_es_pnet_down[1,2,21]
2 0	#slack_es_pnet_down[1,2,22]
2 0	#slack_es_pnet_down[1,2,23]
2 0	#slack_es_pnet_down[1,3,0]
2 0	#slack_es_pnet_down[1,3,1]
2 0	#slack_es_pnet_down[1,3,2]
2 0	#slack_es_pnet_down[1,3,3]
2 0	#slack_es_pnet_down[1,3,4]
2 0	#slack_es_pnet_down[1,3,5]
2 0	#slack_es_pnet_down[1,3,6]
2 0	#slack_es_pnet_down[1,3,7]
2 0	#slack_es_pnet_down[1,3,8]
2 0	#slack_es_pnet_down[1,3,9]
2 0	#slack_es_pnet_down[1,3,10]
2 0	#slack_es_pnet_down[1,3,11]
2 0	#slack_es_pnet_down[1,3,12]
2 0	#slack_es_pnet_down[1,3,13]
2 0	#slack_es_pnet_down[1,3,14]
2 0	#slack_es_pnet_down[1,3,15]
2 0	#slack_es_pnet_down[1,3,16]
2 0	#slack_es_pnet_down[1,3,17]
2 0	#slack_es_pnet_down[1,3,18]
2 0	#slack_es_pnet_down[1,3,19]
2 0	#slack_es_pnet_down[1,3,20]
2 0	#slack_es_pnet_down[1,3,21]
2 0	#slack_es_pnet_down[1,3,22]
2 0	#slack_es_pnet_down[1,3,23]
2 0	#slack_es_pnet_down[2,0,0]
2 0	#slack_es_pnet_down[2,0,1]
2 0	#slack_es_pnet_down[2,0,2]
2 0	#slack_es_pnet_down[2,0,3]
2 0	#slack_es_pnet_down[2,0,4]
2 0	#slack_es_pnet_down[2,0,5]
2 0	#slack_es_pnet_down[2,0,6]
2 0	#slack_es_pnet_down[2,0,7]
2 0	#slack_es_pnet_down[2,0,8]
2 0	#slack_es_pnet_down[2,0,9]
2 0	#slack_es_pnet_down[2,0,10]
2 0	#slack_es_pnet_down[2,0,11]
2 0	#slack_es_pnet_down[2,0,12]
2 0	#slack_es_pnet_down[2,0,13]
2 0	#slack_es_pnet_down[2,0,14]
2 0	#slack_es_pnet_down[2,0,15]
2 0	#slack_es_pnet_down[2,0,16]
2 0	#slack_es_pnet_down[2,0,17]
2 0	#slack_es_pnet_down[2,0,18]
2 0	#slack_es_pnet_down[2,0,19]
2 0	#slack_es_pnet_down[2,0,20]
2 0	#slack_es_pnet_down[2,0,21]
2 0	#slack_es_pnet_down[2,0,22]
2 0	#slack_es_pnet_down[2,0,23]
2 0	#slack_es_pnet_down[2,1,0]
2 0	#slack_es_pnet_down[2,1,1]
2 0	#slack_es_pnet_down[2,1,2]
2 0	#slack_es_pnet_down[2,1,3]
2 0	#slack_es_pnet_down[2,1,4]
2 0	#slack_es_pnet_down[2,1,5]
2 0	#slack_es_pnet_down[2,1,6]
2 0	#slack_es_pnet_down[2,1,7]
2 0	#slack_es_pnet_down[2,1,8]
2 0	#slack_es_pnet_down[2,1,9]
2 0	#slack_es_pnet_down[2,1,10]
2 0	#slack_es_pnet_down[2,1,11]
2 0	#slack_es_pnet_down[2,1,12]
2 0	#slack_es_pnet_down[2,1,13]
2 0	#slack_es_pnet_down[2,1,14]
2 0	#slack_es_pnet_down[2,1,15]
2 0	#slack_es_pnet_down[2,1,16]
2 0	#slack_es_pnet_down[2,1,17]
2 0	#slack_es_pnet_down[2,1,18]
2 0	#slack_es_pnet_down[2,1,19]
2 0	#slack_es_pnet_down[2,1,20]
2 0	#slack_es_pnet_down[2,1,21]
2 0	#slack_es_pnet_down[2,1,22]
2 0	#slack_es_pnet_down[2,1,23]
2 0	#slack_es_pnet_down[2,2,0]
2 0	#slack_es_pnet_down[2,2,1]
2 0	#slack_es_pnet_down[2,2,2]
2 0	#slack_es_pnet_down[2,2,3]
2 0	#slack_es_pnet_down[2,2,4]
2 0	#slack_es_pnet_down[2,2,5]
2 0	#slack_es_pnet_down[2,2,6]
2 0	#slack_es_pnet_down[2,2,7]
2 0	#slack_es_pnet_down[2,2,8]
2 0	#slack_es_pnet_down[2,2,9]
2 0	#slack_es_pnet_down[2,2,10]
2 0	#slack_es_pnet_down[2,2,11]
2 0	#slack_es_pnet_down[2,2,12]
2 0	#slack_es_pnet_down[2,2,13]
2 0	#slack_es_pnet_down[2,2,14]
2 0	#slack_es_pnet_down[2,2,15]
2 0	#slack_es_pnet_down[2,2,16]
2 0	#slack_es_pnet_down[2,2,17]
2 0	#slack_es_pnet_down[2,2,18]
2 0	#slack_es_pnet_down[2,2,19]
2 0	#slack_es_pnet_down[2,2,20]
2 0	#slack_es_pnet_down[2,2,21]
2 0	#slack_es_pnet_down[2,2,22]
2 0	#slack_es_pnet_down[2,2,23]
2 0	#slack_es_pnet_down[2,3,0]
2 0	#slack_es_pnet_down[2,3,1]
2 0	#slack_es_pnet_down[2,3,2]
2 0	#slack_es_pnet_down[2,3,3]
2 0	#slack_es_pnet_down[2,3,4]
2 0	#slack_es_pnet_down[2,3,5]
2 0	#slack_es_pnet_down[2,3,6]
2 0	#slack_es_pnet_down[2,3,7]
2 0	#slack_es_pnet_down[2,3,8]
2 0	#slack_es_pnet_down[2,3,9]
2 0	#slack_es_pnet_down[2,3,10]
2 0	#slack_es_pnet_down[2,3,11]
2 0	#slack_es_pnet_down[2,3,12]
2 0	#slack_es_pnet_down[2,3,13]
2 0	#slack_es_pnet_down[2,3,14]
2 0	#slack_es_pnet_down[2,3,15]
2 0	#slack_es_pnet_down[2,3,16]
2 0	#slack_es_pnet_down[2,3,17]
2 0	#slack_es_pnet_down[2,3,18]
2 0	#slack_es_pnet_down[2,3,19]
2 0	#slack_es_pnet_down[2,3,20]
2 0	#slack_es_pnet_down[2,3,21]
2 0	#slack_es_pnet_down[2,3,22]
2 0	#slack_es_pnet_down[2,3,23]
2 0	#es_pch_per_unit[1,1,0,0]
2 0	#es_pch_per_unit[1,1,0,1]
2 0	#es_pch_per_unit[1,1,0,2]
2 0	#es_pch_per_unit[1,1,0,3]
2 0	#es_pch_per_unit[1,1,0,4]
2 0	#es_pch_per_unit[1,1,0,5]
2 0	#es_pch_per_unit[1,1,0,6]
2 0	#es_pch_per_unit[1,1,0,7]
2 0	#es_pch_per_unit[1,1,0,8]
2 0	#es_pch_per_unit[1,1,0,9]
2 0	#es_pch_per_unit[1,1,0,10]
2 0	#es_pch_per_unit[1,1,0,11]
2 0	#es_pch_per_unit[1,1,0,12]
2 0	#es_pch_per_unit[1,1,0,13]
2 0	#es_pch_per_unit[1,1,0,14]
2 0	#es_pch_per_unit[1,1,0,15]
2 0	#es_pch_per_unit[1,1,0,16]
2 0	#es_pch_per_unit[1,1,0,17]
2 0	#es_pch_per_unit[1,1,0,18]
2 0	#es_pch_per_unit[1,1,0,19]
2 0	#es_pch_per_unit[1,1,0,20]
2 0	#es_pch_per_unit[1,1,0,21]
2 0	#es_pch_per_unit[1,1,0,22]
2 0	#es_pch_per_unit[1,1,0,23]
2 0	#es_pch_per_unit[1,1,1,0]
2 0	#es_pch_per_unit[1,1,1,1]
2 0	#es_pch_per_unit[1,1,1,2]
2 0	#es_pch_per_unit[1,1,1,3]
2 0	#es_pch_per_unit[1,1,1,4]
2 0	#es_pch_per_unit[1,1,1,5]
2 0	#es_pch_per_unit[1,1,1,6]
2 0	#es_pch_per_unit[1,1,1,7]
2 0	#es_pch_per_unit[1,1,1,8]
2 0	#es_pch_per_unit[1,1,1,9]
2 0	#es_pch_per_unit[1,1,1,10]
2 0	#es_pch_per_unit[1,1,1,11]
2 0	#es_pch_per_unit[1,1,1,12]
2 0	#es_pch_per_unit[1,1,1,13]
2 0	#es_pch_per_unit[1,1,1,14]
2 0	#es_pch_per_unit[1,1,1,15]
2 0	#es_pch_per_unit[1,1,1,16]
2 0	#es_pch_per_unit[1,1,1,17]
2 0	#es_pch_per_unit[1,1,1,18]
2 0	#es_pch_per_unit[1,1,1,19]
2 0	#es_pch_per_unit[1,1,1,20]
2 0	#es_pch_per_unit[1,1,1,21]
2 0	#es_pch_per_unit[1,1,1,22]
2 0	#es_pch_per_unit[1,1,1,23]
2 0	#es_pch_per_unit[1,1,2,0]
2 0	#es_pch_per_unit[1,1,2,1]
2 0	#es_pch_per_unit[1,1,2,2]
2 0	#es_pch_per_unit[1,1,2,3]
2 0	#es_pch_per_unit[1,1,2,4]
2 0	#es_pch_per_unit[1,1,2,5]
2 0	#es_pch_per_unit[1,1,2,6]
2 0	#es_pch_per_unit[1,1,2,7]
2 0	#es_pch_per_unit[1,1,2,8]
2 0	#es_pch_per_unit[1,1,2,9]
2 0	#es_pch_per_unit[1,1,2,10]
2 0	#es_pch_per_unit[1,1,2,11]
2 0	#es_pch_per_unit[1,1,2,12]
2 0	#es_pch_per_unit[1,1,2,13]
2 0	#es_pch_per_unit[1,1,2,14]
2 0	#es_pch_per_unit[1,1,2,15]
2 0	#es_pch_per_unit[1,1,2,16]
2 0	#es_pch_per_unit[1,1,2,17]
2 0	#es_pch_per_unit[1,1,2,18]
2 0	#es_pch_per_unit[1,1,2,19]
2 0	#es_pch_per_unit[1,1,2,20]
2 0	#es_pch_per_unit[1,1,2,21]
2 0	#es_pch_per_unit[1,1,2,22]
2 0	#es_pch_per_unit[1,1,2,23]
2 0	#es_pch_per_unit[1,1,3,0]
2 0	#es_pch_per_unit[1,1,3,1]
2 0	#es_pch_per_unit[1,1,3,2]
2 0	#es_pch_per_unit[1,1,3,3]
2 0	#es_pch_per_unit[1,1,3,4]
2 0	#es_pch_per_unit[1,1,3,5]
2 0	#es_pch_per_unit[1,1,3,6]
2 0	#es_pch_per_unit[1,1,3,7]
2 0	#es_pch_per_unit[1,1,3,8]
2 0	#es_pch_per_unit[1,1,3,9]
2 0	#es_pch_per_unit[1,1,3,10]
2 0	#es_pch_per_unit[1,1,3,11]
2 0	#es_pch_per_unit[1,1,3,12]
2 0	#es_pch_per_unit[1,1,3,13]
2 0	#es_pch_per_unit[1,1,3,14]
2 0	#es_pch_per_unit[1,1,3,15]
2 0	#es_pch_per_unit[1,1,3,16]
2 0	#es_pch_per_unit[1,1,3,17]
2 0	#es_pch_per_unit[1,1,3,18]
2 0	#es_pch_per_unit[1,1,3,19]
2 0	#es_pch_per_unit[1,1,3,20]
2 0	#es_pch_per_unit[1,1,3,21]
2 0	#es_pch_per_unit[1,1,3,22]
2 0	#es_pch_per_unit[1,1,3,23]
2 0	#es_pch_per_unit[1,2,0,0]
2 0	#es_pch_per_unit[1,2,0,1]
2 0	#es_pch_per_unit[1,2,0,2]
2 0	#es_pch_per_unit[1,2,0,3]
2 0	#es_pch_per_unit[1,2,0,4]
2 0	#es_pch_per_unit[1,2,0,5]
2 0	#es_pch_per_unit[1,2,0,6]
2 0	#es_pch_per_unit[1,2,0,7]
2 0	#es_pch_per_unit[1,2,0,8]
2 0	#es_pch_per_unit[1,2,0,9]
2 0	#es_pch_per_unit[1,2,0,10]
2 0	#es_pch_per_unit[1,2,0,11]
2 0	#es_pch_per_unit[1,2,0,12]
2 0	#es_pch_per_unit[1,2,0,13]
2 0	#es_pch_per_unit[1,2,0,14]
2 0	#es_pch_per_unit[1,2,0,15]
2 0	#es_pch_per_unit[1,2,0,16]
2 0	#es_pch_per_unit[1,2,0,17]
2 0	#es_pch_per_unit[1,2,0,18]
2 0	#es_pch_per_unit[1,2,0,19]
2 0	#es_pch_per_unit[1,2,0,20]
2 0	#es_pch_per_unit[1,2,0,21]
2 0	#es_pch_per_unit[1,2,0,22]
2 0	#es_pch_per_unit[1,2,0,23]
2 0	#es_pch_per_unit[1,2,1,0]
2 0	#es_pch_per_unit[1,2,1,1]
2 0	#es_pch_per_unit[1,2,1,2]
2 0	#es_pch_per_unit[1,2,1,3]
2 0	#es_pch_per_unit[1,2,1,4]
2 0	#es_pch_per_unit[1,2,1,5]
2 0	#es_pch_per_unit[1,2,1,6]
2 0	#es_pch_per_unit[1,2,1,7]
2 0	#es_pch_per_unit[1,2,1,8]
2 0	#es_pch_per_unit[1,2,1,9]
2 0	#es_pch_per_unit[1,2,1,10]
2 0	#es_pch_per_unit[1,2,1,11]
2 0	#es_pch_per_unit[1,2,1,12]
2 0	#es_pch_per_unit[1,2,1,13]
2 0	#es_pch_per_unit[1,2,1,14]
2 0	#es_pch_per_unit[1,2,1,15]
2 0	#es_pch_per_unit[1,2,1,16]
2 0	#es_pch_per_unit[1,2,1,17]
2 0	#es_pch_per_unit[1,2,1,18]
2 0	#es_pch_per_unit[1,2,1,19]
2 0	#es_pch_per_unit[1,2,1,20]
2 0	#es_pch_per_unit[1,2,1,21]
2 0	#es_pch_per_unit[1,2,1,22]
2 0	#es_pch_per_unit[1,2,1,23]
2 0	#es_pch_per_unit[1,2,2,0]
2 0	#es_pch_per_unit[1,2,2,1]
2 0	#es_pch_per_unit[1,2,2,2]
2 0	#es_pch_per_unit[1,2,2,3]
2 0	#es_pch_per_unit[1,2,2,4]
2 0	#es_pch_per_unit[1,2,2,5]
2 0	#es_pch_per_unit[1,2,2,6]
2 0	#es_pch_per_unit[1,2,2,7]
2 0	#es_pch_per_unit[1,2,2,8]
2 0	#es_pch_per_unit[1,2,2,9]
2 0	#es_pch_per_unit[1,2,2,10]
2 0	#es_pch_per_unit[1,2,2,11]
2 0	#es_pch_per_unit[1,2,2,12]
2 0	#es_pch_per_unit[1,2,2,13]
2 0	#es_pch_per_unit[1,2,2,14]
2 0	#es_pch_per_unit[1,2,2,15]
2 0	#es_pch_per_unit[1,2,2,16]
2 0	#es_pch_per_unit[1,2,2,17]
2 0	#es_pch_per_unit[1,2,2,18]
2 0	#es_pch_per_unit[1,2,2,19]
2 0	#es_pch_per_unit[1,2,2,20]
2 0	#es_pch_per_unit[1,2,2,21]
2 0	#es_pch_per_unit[1,2,2,22]
2 0	#es_pch_per_unit[1,2,2,23]
2 0	#es_pch_per_unit[1,2,3,0]
2 0	#es_pch_per_unit[1,2,3,1]
2 0	#es_pch_per_unit[1,2,3,2]
2 0	#es_pch_per_unit[1,2,3,3]
2 0	#es_pch_per_unit[1,2,3,4]
2 0	#es_pch_per_unit[1,2,3,5]
2 0	#es_pch_per_unit[1,2,3,6]
2 0	#es_pch_per_unit[1,2,3,7]
2 0	#es_pch_per_unit[1,2,3,8]
2 0	#es_pch_per_unit[1,2,3,9]
2 0	#es_pch_per_unit[1,2,3,10]
2 0	#es_pch_per_unit[1,2,3,11]
2 0	#es_pch_per_unit[1,2,3,12]
2 0	#es_pch_per_unit[1,2,3,13]
2 0	#es_pch_per_unit[1,2,3,14]
2 0	#es_pch_per_unit[1,2,3,15]
2 0	#es_pch_per_unit[1,2,3,16]
2 0	#es_pch_per_unit[1,2,3,17]
2 0	#es_pch_per_unit[1,2,3,18]
2 0	#es_pch_per_unit[1,2,3,19]
2 0	#es_pch_per_unit[1,2,3,20]
2 0	#es_pch_per_unit[1,2,3,21]
2 0	#es_pch_per_unit[1,2,3,22]
2 0	#es_pch_per_unit[1,2,3,23]
2 0	#es_pdch_per_unit[1,1,0,0]
2 0	#es_pdch_per_unit[1,1,0,1]
2 0	#es_pdch_per_unit[1,1,0,2]
2 0	#es_pdch_per_unit[1,1,0,3]
2 0	#es_pdch_per_unit[1,1,0,4]
2 0	#es_pdch_per_unit[1,1,0,5]
2 0	#es_pdch_per_unit[1,1,0,6]
2 0	#es_pdch_per_unit[1,1,0,7]
2 0	#es_pdch_per_unit[1,1,0,8]
2 0	#es_pdch_per_unit[1,1,0,9]
2 0	#es_pdch_per_unit[1,1,0,10]
2 0	#es_pdch_per_unit[1,1,0,11]
2 0	#es_pdch_per_unit[1,1,0,12]
2 0	#es_pdch_per_unit[1,1,0,13]
2 0	#es_pdch_per_unit[1,1,0,14]
2 0	#es_pdch_per_unit[1,1,0,15]
2 0	#es_pdch_per_unit[1,1,0,16]
2 0	#es_pdch_per_unit[1,1,0,17]
2 0	#es_pdch_per_unit[1,1,0,18]
2 0	#es_pdch_per_unit[1,1,0,19]
2 0	#es_pdch_per_unit[1,1,0,20]
2 0	#es_pdch_per_unit[1,1,0,21]
2 0	#es_pdch_per_unit[1,1,0,22]
2 0	#es_pdch_per_unit[1,1,0,23]
2 0	#es_pdch_per_unit[1,1,1,0]
2 0	#es_pdch_per_unit[1,1,1,1]
2 0	#es_pdch_per_unit[1,1,1,2]
2 0	#es_pdch_per_unit[1,1,1,3]
2 0	#es_pdch_per_unit[1,1,1,4]
2 0	#es_pdch_per_unit[1,1,1,5]
2 0	#es_pdch_per_unit[1,1,1,6]
2 0	#es_pdch_per_unit[1,1,1,7]
2 0	#es_pdch_per_unit[1,1,1,8]
2 0	#es_pdch_per_unit[1,1,1,9]
2 0	#es_pdch_per_unit[1,1,1,10]
2 0	#es_pdch_per_unit[1,1,1,11]
2 0	#es_pdch_per_unit[1,1,1,12]
2 0	#es_pdch_per_unit[1,1,1,13]
2 0	#es_pdch_per_unit[1,1,1,14]
2 0	#es_pdch_per_unit[1,1,1,15]
2 0	#es_pdch_per_unit[1,1,1,16]
2 0	#es_pdch_per_unit[1,1,1,17]
2 0	#es_pdch_per_unit[1,1,1,18]
2 0	#es_pdch_per_unit[1,1,1,19]
2 0	#es_pdch_per_unit[1,1,1,20]
2 0	#es_pdch_per_unit[1,1,1,21]
2 0	#es_pdch_per_unit[1,1,1,22]
2 0	#es_pdch_per_unit[1,1,1,23]
2 0	#es_pdch_per_unit[1,1,2,0]
2 0	#es_pdch_per_unit[1,1,2,1]
2 0	#es_pdch_per_unit[1,1,2,2]
2 0	#es_pdch_per_unit[1,1,2,3]
2 0	#es_pdch_per_unit[1,1,2,4]
2 0	#es_pdch_per_unit[1,1,2,5]
2 0	#es_pdch_per_unit[1,1,2,6]
2 0	#es_pdch_per_unit[1,1,2,7]
2 0	#es_pdch_per_unit[1,1,2,8]
2 0	#es_pdch_per_unit[1,1,2,9]
2 0	#es_pdch_per_unit[1,1,2,10]
2 0	#es_pdch_per_unit[1,1,2,11]
2 0	#es_pdch_per_unit[1,1,2,12]
2 0	#es_pdch_per_unit[1,1,2,13]
2 0	#es_pdch_per_unit[1,1,2,14]
2 0	#es_pdch_per_unit[1,1,2,15]
2 0	#es_pdch_per_unit[1,1,2,16]
2 0	#es_pdch_per_unit[1,1,2,17]
2 0	#es_pdch_per_unit[1,1,2,18]
2 0	#es_pdch_per_unit[1,1,2,19]
2 0	#es_pdch_per_unit[1,1,2,20]
2 0	#es_pdch_per_unit[1,1,2,21]
2 0	#es_pdch_per_unit[1,1,2,22]
2 0	#es_pdch_per_unit[1,1,2,23]
2 0	#es_pdch_per_unit[1,1,3,0]
2 0	#es_pdch_per_unit[1,1,3,1]
2 0	#es_pdch_per_unit[1,1,3,2]
2 0	#es_pdch_per_unit[1,1,3,3]
2 0	#es_pdch_per_unit[1,1,3,4]
2 0	#es_pdch_per_unit[1,1,3,5]
2 0	#es_pdch_per_unit[1,1,3,6]
2 0	#es_pdch_per_unit[1,1,3,7]
2 0	#es_pdch_per_unit[1,1,3,8]
2 0	#es_pdch_per_unit[1,1,3,9]
2 0	#es_pdch_per_unit[1,1,3,10]
2 0	#es_pdch_per_unit[1,1,3,11]
2 0	#es_pdch_per_unit[1,1,3,12]
2 0	#es_pdch_per_unit[1,1,3,13]
2 0	#es_pdch_per_unit[1,1,3,14]
2 0	#es_pdch_per_unit[1,1,3,15]
2 0	#es_pdch_per_unit[1,1,3,16]
2 0	#es_pdch_per_unit[1,1,3,17]
2 0	#es_pdch_per_unit[1,1,3,18]
2 0	#es_pdch_per_unit[1,1,3,19]
2 0	#es_pdch_per_unit[1,1,3,20]
2 0	#es_pdch_per_unit[1,1,3,21]
2 0	#es_pdch_per_unit[1,1,3,22]
2 0	#es_pdch_per_unit[1,1,3,23]
2 0	#es_pdch_per_unit[1,2,0,0]
2 0	#es_pdch_per_unit[1,2,0,1]
2 0	#es_pdch_per_unit[1,2,0,2]
2 0	#es_pdch_per_unit[1,2,0,3]
2 0	#es_pdch_per_unit[1,2,0,4]
2 0	#es_pdch_per_unit[1,2,0,5]
2 0	#es_pdch_per_unit[1,2,0,6]
2 0	#es_pdch_per_unit[1,2,0,7]
2 0	#es_pdch_per_unit[1,2,0,8]
2 0	#es_pdch_per_unit[1,2,0,9]
2 0	#es_pdch_per_unit[1,2,0,10]
2 0	#es_pdch_per_unit[1,2,0,11]
2 0	#es_pdch_per_unit[1,2,0,12]
2 0	#es_pdch_per_unit[1,2,0,13]
2 0	#es_pdch_per_unit[1,2,0,14]
2 0	#es_pdch_per_unit[1,2,0,15]
2 0	#es_pdch_per_unit[1,2,0,16]
2 0	#es_pdch_per_unit[1,2,0,17]
2 0	#es_pdch_per_unit[1,2,0,18]
2 0	#es_pdch_per_unit[1,2,0,19]
2 0	#es_pdch_per_unit[1,2,0,20]
2 0	#es_pdch_per_unit[1,2,0,21]
2 0	#es_pdch_per_unit[1,2,0,22]
2 0	#es_pdch_per_unit[1,2,0,23]
2 0	#es_pdch_per_unit[1,2,1,0]
2 0	#es_pdch_per_unit[1,2,1,1]
2 0	#es_pdch_per_unit[1,2,1,2]
2 0	#es_pdch_per_unit[1,2,1,3]
2 0	#es_pdch_per_unit[1,2,1,4]
2 0	#es_pdch_per_unit[1,2,1,5]
2 0	#es_pdch_per_unit[1,2,1,6]
2 0	#es_pdch_per_unit[1,2,1,7]
2 0	#es_pdch_per_unit[1,2,1,8]
2 0	#es_pdch_per_unit[1,2,1,9]
2 0	#es_pdch_per_unit[1,2,1,10]
2 0	#es_pdch_per_unit[1,2,1,11]
2 0	#es_pdch_per_unit[1,2,1,12]
2 0	#es_pdch_per_unit[1,2,1,13]
2 0	#es_pdch_per_unit[1,2,1,14]
2 0	#es_pdch_per_unit[1,2,1,15]
2 0	#es_pdch_per_unit[1,2,1,16]
2 0	#es_pdch_per_unit[1,2,1,17]
2 0	#es_pdch_per_unit[1,2,1,18]
2 0	#es_pdch_per_unit[1,2,1,19]
2 0	#es_pdch_per_unit[1,2,1,20]
2 0	#es_pdch_per_unit[1,2,1,21]
2 0	#es_pdch_per_unit[1,2,1,22]
2 0	#es_pdch_per_unit[1,2,1,23]
2 0	#es_pdch_per_unit[1,2,2,0]
2 0	#es_pdch_per_unit[1,2,2,1]
2 0	#es_pdch_per_unit[1,2,2,2]
2 0	#es_pdch_per_unit[1,2,2,3]
2 0	#es_pdch_per_unit[1,2,2,4]
2 0	#es_pdch_per_unit[1,2,2,5]
2 0	#es_pdch_per_unit[1,2,2,6]
2 0	#es_pdch_per_unit[1,2,2,7]
2 0	#es_pdch_per_unit[1,2,2,8]
2 0	#es_pdch_per_unit[1,2,2,9]
2 0	#es_pdch_per_unit[1,2,2,10]
2 0	#es_pdch_per_unit[1,2,2,11]
2 0	#es_pdch_per_unit[1,2,2,12]
2 0	#es_pdch_per_unit[1,2,2,13]
2 0	#es_pdch_per_unit[1,2,2,14]
2 0	#es_pdch_per_unit[1,2,2,15]
2 0	#es_pdch_per_unit[1,2,2,16]
2 0	#es_pdch_per_unit[1,2,2,17]
2 0	#es_pdch_per_unit[1,2,2,18]
2 0	#es_pdch_per_unit[1,2,2,19]
2 0	#es_pdch_per_unit[1,2,2,20]
2 0	#es_pdch_per_unit[1,2,2,21]
2 0	#es_pdch_per_unit[1,2,2,22]
2 0	#es_pdch_per_unit[1,2,2,23]
2 0	#es_pdch_per_unit[1,2,3,0]
2 0	#es_pdch_per_unit[1,2,3,1]
2 0	#es_pdch_per_unit[1,2,3,2]
2 0	#es_pdch_per_unit[1,2,3,3]
2 0	#es_pdch_per_unit[1,2,3,4]
2 0	#es_pdch_per_unit[1,2,3,5]
2 0	#es_pdch_per_unit[1,2,3,6]
2 0	#es_pdch_per_unit[1,2,3,7]
2 0	#es_pdch_per_unit[1,2,3,8]
2 0	#es_pdch_per_unit[1,2,3,9]
2 0	#es_pdch_per_unit[1,2,3,10]
2 0	#es_pdch_per_unit[1,2,3,11]
2 0	#es_pdch_per_unit[1,2,3,12]
2 0	#es_pdch_per_unit[1,2,3,13]
2 0	#es_pdch_per_unit[1,2,3,14]
2 0	#es_pdch_per_unit[1,2,3,15]
2 0	#es_pdch_per_unit[1,2,3,16]
2 0	#es_pdch_per_unit[1,2,3,17]
2 0	#es_pdch_per_unit[1,2,3,18]
2 0	#es_pdch_per_unit[1,2,3,19]
2 0	#es_pdch_per_unit[1,2,3,20]
2 0	#es_pdch_per_unit[1,2,3,21]
2 0	#es_pdch_per_unit[1,2,3,22]
2 0	#es_pdch_per_unit[1,2,3,23]
2 0	#es_s_rated_per_unit[0,0]
2 0	#es_s_rated_per_unit[0,1]
2 0	#es_s_rated_per_unit[0,2]
2 0	#es_s_rated_per_unit[1,1]
2 0	#es_s_rated_per_unit[1,2]
2 0	#es_s_rated_per_unit[2,2]
2 0	#es_e_rated_per_unit[0,0]
2 0	#es_e_rated_per_unit[0,1]
2 0	#es_e_rated_per_unit[0,2]
2 0	#es_e_rated_per_unit[2,2]
2 0	#es_e_rated[0]
2 0	#es_e_rated[1]
2 0	#es_e_rated[2]
2 0	#es_s_available_per_unit[0,0]
2 0	#es_s_available_per_unit[0,1]
2 0	#es_s_available_per_unit[0,2]
2 0	#es_s_available_per_unit[1,0]
2 0	#es_s_available_per_unit[1,1]
2 0	#es_s_available_per_unit[1,2]
2 0	#es_s_available_per_unit[2,0]
2 0	#es_s_available_per_unit[2,1]
2 0	#es_s_available_per_unit[2,2]
2 0	#es_e_available_per_unit[0,0]
2 0	#es_e_available_per_unit[0,1]
2 0	#es_e_available_per_unit[0,2]
2 0	#es_e_available_per_unit[1,0]
2 0	#es_e_available_per_unit[1,1]
2 0	#es_e_available_per_unit[1,2]
2 0	#es_e_available_per_unit[2,0]
2 0	#es_e_available_per_unit[2,1]
2 0	#es_e_available_per_unit[2,2]
3	#es_avg_ch_dch_per_unit[1,1]
3	#es_avg_ch_dch_per_unit[1,2]
k1001	#intermediate Jacobian column lengths
3
6
103
200
297
301
304
306
308
309
310
311
312
313
314
315
316
317
318
319
320
321
322
323
324
325
326
327
328
329
330
331
332
333
334
335
336
337
338
339
340
341
342
343
344
345
346
347
348
349
350
351
352
353
354
355
356
357
358
359
360
361
362
363
364
365
366
367
368
369
370
371
372
373
374
375
376
377
378
379
380
381
382
383
384
385
386
387
388
389
390
391
392
393
394
395
396
397
398
399
400
401
402
403
404
405
406
407
408
409
410
411
412
413
414
415
416
417
418
419
420
421
422
423
424
425
426
427
428
429
430
431
432
433
434
435
436
437
438
439
440
441
442
443
444
445
446
447
448
449
450
451
452
453
454
455
456
457
458
459
460
461
462
463
464
465
466
467
468
469
470
471
472
473
474
475
476
477
478
479
480
481
482
483
484
485
486
487
488
489
490
491
492
493
494
495
496
497
498
499
500
501
502
503
504
505
506
507
508
509
510
511
512
513
514
515
516
517
518
519
520
521
522
523
524
525
526
527
528
529
530
531
532
533
534
535
536
537
538
539
540
541
542
543
544
545
546
547
548
549
550
551
552
553
554
555
556
557
558
559
560
561
562
563
564
565
566
567
568
569
570
571
572
573
574
575
576
577
578
579
580
581
582
583
584
585
586
587
588
589
590
591
592
593
594
595
596
597
598
599
600
601
602
603
604
605
606
607
608
609
610
611
612
613
614
615
616
617
618
619
620
621
622
623
624
625
626
627
628
629
630
631
632
633
634
635
636
637
638
639
640
641
642
643
644
645
646
647
648
649
650
651
652
653
654
655
656
657
658
659
660
661
662
663
664
665
666
667
668
669
670
671
672
673
674
675
676
677
678
679
680
681
682
683
684
685
686
687
688
689
690
691
692
693
694
695
696
697
698
699
700
701
702
703
704
705
706
707
708
709
710
711
712
713
714
715
716
717
718
719
720
721
722
723
724
725
726
727
728
729
730
731
732
733
734
735
736
737
738
739
740
741
742
743
744
745
746
747
748
749
750
751
752
753
754
755
756
757
758
759
760
761
762
763
764
765
766
767
768
769
770
771
772
773
774
775
776
777
778
779
780
781
782
783
784
785
786
787
788
789
790
791
792
793
794
795
796
797
798
799
800
801
802
803
804
805
806
807
808
809
810
811
812
813
814
815
816
817
818
819
820
821
822
823
824
825
826
827
828
829
830
831
832
833
834
835
836
837
838
839
840
841
842
843
844
845
846
847
848
849
850
851
852
853
854
855
856
857
858
859
860
861
862
863
864
865
866
867
868
869
870
871
872
873
874
875
876
877
878
879
880
881
882
883
884
887
890
893
896
899
902
905
908
911
914
917
920
923
926
929
932
935
938
941
944
947
950
953
956
959
962
965
968
971
974
977
980
983
986
989
992
995
998
1001
1004
1007
1010
1013
1016
1019
1022
1025
1028
1031
1034
1037
1040
1043
1046
1049
1052
1055
1058
1061
1064
1067
1070
1073
1076
1079
1082
1085
1088
1091
1094
1097
1100
1103
1106
1109
1112
1115
1118
1121
1124
1127
1130
1133
1136
1139
1142
1145
1148
1151
1154
1157
1160
1163
1166
1169
1172
1175
1178
1181
1184
1187
1190
1193
1196
1199
1202
1205
1208
1211
1214
1217
1220
1223
1226
1229
1232
1235
1238
1241
1244
1247
1250
1253
1256
1259
1262
1265
1268
1271
1274
1277
1280
1283
1286
1289
1292
1295
1298
1301
1304
1307
1310
1313
1316
1319
1322
1325
1328
1331
1334
1337
1340
1343
1346
1349
1352
1355
1358
1361
1364
1367
1370
1373
1376
1379
1382
1385
1388
1391
1394
1397
1400
1403
1406
1409
1412
1415
1418
1421
1424
1427
1430
1433
1436
1439
1442
1445
1448
1451
1454
1457
1460
1463
1466
1469
1472
1475
1478
1481
1484
1487
1490
1493
1496
1499
1502
1505
1508
1511
1514
1517
1520
1523
1526
1529
1532
1535
1538
1541
1544
1547
1550
1553
1556
1559
1562
1565
1568
1571
1574
1577
1580
1583
1586
1589
1592
1595
1598
1601
1604
1607
1610
1613
1616
1619
1622
1625
1628
1631
1634
1637
1640
1643
1646
1649
1652
1655
1658
1661
1664
1667
1670
1673
1676
1679
1682
1685
1688
1691
1694
1697
1700
1703
1706
1709
1712
1715
1718
1721
1724
1727
1730
1733
1736
1739
1742
1745
1748
1751
1754
1757
1760
1763
1766
1769
1772
1775
1778
1781
1784
1787
1790
1793
1796
1799
1802
1805
1808
1811
1814
1817
1820
1823
1826
1829
1832
1835
1838
1841
1844
1847
1850
1853
1856
1859
1862
1865
1868
1871
1874
1877
1880
1883
1886
1889
1892
1895
1898
1901
1904
1907
1910
1913
1916
1919
1922
1925
1928
1931
1934
1937
1940
1943
1946
1949
1952
1955
1958
1961
1964
1967
1970
1973
1976
1979
1982
1985
1988
1991
1994
1997
2000
2003
2006
2009
2012
2015
2018
2021
2024
2027
2030
2033
2036
2039
2042
2045
2240
2435
2438
2441
2444
2447
2450
2451
2452
2453
2454
2455
2456
2457
2458
2459
2460
2461
2462
2463
2464
2465
2466
2467
2468
2469
2470
2471
2473
J0 3	#available_e_capacity_unit[5]
0 0
5 0
995 1
J1 3	#available_e_capacity_unit[6]
1 0
6 0
996 1
J2 2	#energy_storage_capacity_degradation[11]
5 1
7 0
J3 3	#energy_storage_capacity_degradation[14]
5 0
6 1
8 0
J4 1	#energy_storage_operation_agg[2]
2 0
J5 1	#energy_storage_operation_agg[4]
2 0
J6 1	#energy_storage_operation_agg[6]
2 0
J7 1	#energy_storage_operation_agg[8]
2 0
J8 1	#energy_storage_operation_agg[10]
2 0
J9 1	#energy_storage_operation_agg[12]
2 0
J10 1	#energy_storage_operation_agg[14]
2 0
J11 1	#energy_storage_operation_agg[16]
2 0
J12 1	#energy_storage_operation_agg[18]
2 0
J13 1	#energy_storage_operation_agg[20]
2 0
J14 1	#energy_storage_operation_agg[22]
2 0
J15 1	#energy_storage_operation_agg[24]
2 0
J16 1	#energy_storage_operation_agg[26]
2 0
J17 1	#energy_storage_operation_agg[28]
2 0
J18 1	#energy_storage_operation_agg[30]
2 0
J19 1	#energy_storage_operation_agg[32]
2 0
J20 1	#energy_storage_operation_agg[34]
2 0
J21 1	#energy_storage_operation_agg[36]
2 0
J22 1	#energy_storage_operation_agg[38]
2 0
J23 1	#energy_storage_operation_agg[40]
2 0
J24 1	#energy_storage_operation_agg[42]
2 0
J25 1	#energy_storage_operation_agg[44]
2 0
J26 1	#energy_storage_operation_agg[46]
2 0
J27 1	#energy_storage_operation_agg[48]
2 0
J28 1	#energy_storage_operation_agg[50]
2 0
J29 1	#energy_storage_operation_agg[52]
2 0
J30 1	#energy_storage_operation_agg[54]
2 0
J31 1	#energy_storage_operation_agg[56]
2 0
J32 1	#energy_storage_operation_agg[58]
2 0
J33 1	#energy_storage_operation_agg[60]
2 0
J34 1	#energy_storage_operation_agg[62]
2 0
J35 1	#energy_storage_operation_agg[64]
2 0
J36 1	#energy_storage_operation_agg[66]
2 0
J37 1	#energy_storage_operation_agg[68]
2 0
J38 1	#energy_storage_operation_agg[70]
2 0
J39 1	#energy_storage_operation_agg[72]
2 0
J40 1	#energy_storage_operation_agg[74]
2 0
J41 1	#energy_storage_operation_agg[76]
2 0
J42 1	#energy_storage_operation_agg[78]
2 0
J43 1	#energy_storage_operation_agg[80]
2 0
J44 1	#energy_storage_operation_agg[82]
2 0
J45 1	#energy_storage_operation_agg[84]
2 0
J46 1	#energy_storage_operation_agg[86]
2 0
J47 1	#energy_storage_operation_agg[88]
2 0
J48 1	#energy_storage_operation_agg[90]
2 0
J49 1	#energy_storage_operation_agg[92]
2 0
J50 1	#energy_storage_operation_agg[94]
2 0
J51 1	#energy_storage_operation_agg[96]
2 0
J52 1	#energy_storage_operation_agg[98]
2 0
J53 1	#energy_storage_operation_agg[100]
2 0
J54 1	#energy_storage_operation_agg[102]
2 0
J55 1	#energy_storage_operation_agg[104]
2 0
J56 1	#energy_storage_operation_agg[106]
2 0
J57 1	#energy_storage_operation_agg[108]
2 0
J58 1	#energy_storage_operation_agg[110]
2 0
J59 1	#energy_storage_operation_agg[112]
2 0
J60 1	#energy_storage_operation_agg[114]
2 0
J61 1	#energy_storage_operation_agg[116]
2 0
J62 1	#energy_storage_operation_agg[118]
2 0
J63 1	#energy_storage_operation_agg[120]
2 0
J64 1	#energy_storage_operation_agg[122]
2 0
J65 1	#energy_storage_operation_agg[124]
2 0
J66 1	#energy_storage_operation_agg[126]
2 0
J67 1	#energy_storage_operation_agg[128]
2 0
J68 1	#energy_storage_operation_agg[130]
2 0
J69 1	#energy_storage_operation_agg[132]
2 0
J70 1	#energy_storage_operation_agg[134]
2 0
J71 1	#energy_storage_operation_agg[136]
2 0
J72 1	#energy_storage_operation_agg[138]
2 0
J73 1	#energy_storage_operation_agg[140]
2 0
J74 1	#energy_storage_operation_agg[142]
2 0
J75 1	#energy_storage_operation_agg[144]
2 0
J76 1	#energy_storage_operation_agg[146]
2 0
J77 1	#energy_storage_operation_agg[148]
2 0
J78 1	#energy_storage_operation_agg[150]
2 0
J79 1	#energy_storage_operation_agg[152]
2 0
J80 1	#energy_storage_operation_agg[154]
2 0
J81 1	#energy_storage_operation_agg[156]
2 0
J82 1	#energy_storage_operation_agg[158]
2 0
J83 1	#energy_storage_operation_agg[160]
2 0
J84 1	#energy_storage_operation_agg[162]
2 0
J85 1	#energy_storage_operation_agg[164]
2 0
J86 1	#energy_storage_operation_agg[166]
2 0
J87 1	#energy_storage_operation_agg[168]
2 0
J88 1	#energy_storage_operation_agg[170]
2 0
J89 1	#energy_storage_operation_agg[172]
2 0
J90 1	#energy_storage_operation_agg[174]
2 0
J91 1	#energy_storage_operation_agg[176]
2 0
J92 1	#energy_storage_operation_agg[178]
2 0
J93 1	#energy_storage_operation_agg[180]
2 0
J94 1	#energy_storage_operation_agg[182]
2 0
J95 1	#energy_storage_operation_agg[184]
2 0
J96 1	#energy_storage_operation_agg[186]
2 0
J97 1	#energy_storage_operation_agg[188]
2 0
J98 1	#energy_storage_operation_agg[190]
2 0
J99 1	#energy_storage_operation_agg[192]
2 0
J100 1	#energy_storage_operation_agg[194]
3 0
J101 1	#energy_storage_operation_agg[196]
3 0
J102 1	#energy_storage_operation_agg[198]
3 0
J103 1	#energy_storage_operation_agg[200]
3 0
J104 1	#energy_storage_operation_agg[202]
3 0
J105 1	#energy_storage_operation_agg[204]
3 0
J106 1	#energy_storage_operation_agg[206]
3 0
J107 1	#energy_storage_operation_agg[208]
3 0
J108 1	#energy_storage_operation_agg[210]
3 0
J109 1	#energy_storage_operation_agg[212]
3 0
J110 1	#energy_storage_operation_agg[214]
3 0
J111 1	#energy_storage_operation_agg[216]
3 0
J112 1	#energy_storage_operation_agg[218]
3 0
J113 1	#energy_storage_operation_agg[220]
3 0
J114 1	#energy_storage_operation_agg[222]
3 0
J115 1	#energy_storage_operation_agg[224]
3 0
J116 1	#energy_storage_operation_agg[226]
3 0
J117 1	#energy_storage_operation_agg[228]
3 0
J118 1	#energy_storage_operation_agg[230]
3 0
J119 1	#energy_storage_operation_agg[232]
3 0
J120 1	#energy_storage_operation_agg[234]
3 0
J121 1	#energy_storage_operation_agg[236]
3 0
J122 1	#energy_storage_operation_agg[238]
3 0
J123 1	#energy_storage_operation_agg[240]
3 0
J124 1	#energy_storage_operation_agg[242]
3 0
J125 1	#energy_storage_operation_agg[244]
3 0
J126 1	#energy_storage_operation_agg[246]
3 0
J127 1	#energy_storage_operation_agg[248]
3 0
J128 1	#energy_storage_operation_agg[250]
3 0
J129 1	#energy_storage_operation_agg[252]
3 0
J130 1	#energy_storage_operation_agg[254]
3 0
J131 1	#energy_storage_operation_agg[256]
3 0
J132 1	#energy_storage_operation_agg[258]
3 0
J133 1	#energy_storage_operation_agg[260]
3 0
J134 1	#energy_storage_operation_agg[262]
3 0
J135 1	#energy_storage_operation_agg[264]
3 0
J136 1	#energy_storage_operation_agg[266]
3 0
J137 1	#energy_storage_operation_agg[268]
3 0
J138 1	#energy_storage_operation_agg[270]
3 0
J139 1	#energy_storage_operation_agg[272]
3 0
J140 1	#energy_storage_operation_agg[274]
3 0
J141 1	#energy_storage_operation_agg[276]
3 0
J142 1	#energy_storage_operation_agg[278]
3 0
J143 1	#energy_storage_operation_agg[280]
3 0
J144 1	#energy_storage_operation_agg[282]
3 0
J145 1	#energy_storage_operation_agg[284]
3 0
J146 1	#energy_storage_operation_agg[286]
3 0
J147 1	#energy_storage_operation_agg[288]
3 0
J148 1	#energy_storage_operation_agg[290]
3 0
J149 1	#energy_storage_operation_agg[292]
3 0
J150 1	#energy_storage_operation_agg[294]
3 0
J151 1	#energy_storage_operation_agg[296]
3 0
J152 1	#energy_storage_operation_agg[298]
3 0
J153 1	#energy_storage_operation_agg[300]
3 0
J154 1	#energy_storage_operation_agg[302]
3 0
J155 1	#energy_storage_operation_agg[304]
3 0
J156 1	#energy_storage_operation_agg[306]
3 0
J157 1	#energy_storage_operation_agg[308]
3 0
J158 1	#energy_storage_operation_agg[310]
3 0
J159 1	#energy_storage_operation_agg[312]
3 0
J160 1	#energy_storage_operation_agg[314]
3 0
J161 1	#energy_storage_operation_agg[316]
3 0
J162 1	#energy_storage_operation_agg[318]
3 0
J163 1	#energy_storage_operation_agg[320]
3 0
J164 1	#energy_storage_operation_agg[322]
3 0
J165 1	#energy_storage_operation_agg[324]
3 0
J166 1	#energy_storage_operation_agg[326]
3 0
J167 1	#energy_storage_operation_agg[328]
3 0
J168 1	#energy_storage_operation_agg[330]
3 0
J169 1	#energy_storage_operation_agg[332]
3 0
J170 1	#energy_storage_operation_agg[334]
3 0
J171 1	#energy_storage_operation_agg[336]
3 0
J172 1	#energy_storage_operation_agg[338]
3 0
J173 1	#energy_storage_operation_agg[340]
3 0
J174 1	#energy_storage_operation_agg[342]
3 0
J175 1	#energy_storage_operation_agg[344]
3 0
J176 1	#energy_storage_operation_agg[346]
3 0
J177 1	#energy_storage_operation_agg[348]
3 0
J178 1	#energy_storage_operation_agg[350]
3 0
J179 1	#energy_storage_operation_agg[352]
3 0
J180 1	#energy_storage_operation_agg[354]
3 0
J181 1	#energy_storage_operation_agg[356]
3 0
J182 1	#energy_storage_operation_agg[358]
3 0
J183 1	#energy_storage_operation_agg[360]
3 0
J184 1	#energy_storage_operation_agg[362]
3 0
J185 1	#energy_storage_operation_agg[364]
3 0
J186 1	#energy_storage_operation_agg[366]
3 0
J187 1	#energy_storage_operation_agg[368]
3 0
J188 1	#energy_storage_operation_agg[370]
3 0
J189 1	#energy_storage_operation_agg[372]
3 0
J190 1	#energy_storage_operation_agg[374]
3 0
J191 1	#energy_storage_operation_agg[376]
3 0
J192 1	#energy_storage_operation_agg[378]
3 0
J193 1	#energy_storage_operation_agg[380]
3 0
J194 1	#energy_storage_operation_agg[382]
3 0
J195 1	#energy_storage_operation_agg[384]
3 0
J196 1	#energy_storage_operation_agg[386]
4 0
J197 1	#energy_storage_operation_agg[388]
4 0
J198 1	#energy_storage_operation_agg[390]
4 0
J199 1	#energy_storage_operation_agg[392]
4 0
J200 1	#energy_storage_operation_agg[394]
4 0
J201 1	#energy_storage_operation_agg[396]
4 0
J202 1	#energy_storage_operation_agg[398]
4 0
J203 1	#energy_storage_operation_agg[400]
4 0
J204 1	#energy_storage_operation_agg[402]
4 0
J205 1	#energy_storage_operation_agg[404]
4 0
J206 1	#energy_storage_operation_agg[406]
4 0
J207 1	#energy_storage_operation_agg[408]
4 0
J208 1	#energy_storage_operation_agg[410]
4 0
J209 1	#energy_storage_operation_agg[412]
4 0
J210 1	#energy_storage_operation_agg[414]
4 0
J211 1	#energy_storage_operation_agg[416]
4 0
J212 1	#energy_storage_operation_agg[418]
4 0
J213 1	#energy_storage_operation_agg[420]
4 0
J214 1	#energy_storage_operation_agg[422]
4 0
J215 1	#energy_storage_operation_agg[424]
4 0
J216 1	#energy_storage_operation_agg[426]
4 0
J217 1	#energy_storage_operation_agg[428]
4 0
J218 1	#energy_storage_operation_agg[430]
4 0
J219 1	#energy_storage_operation_agg[432]
4 0
J220 1	#energy_storage_operation_agg[434]
4 0
J221 1	#energy_storage_operation_agg[436]
4 0
J222 1	#energy_storage_operation_agg[438]
4 0
J223 1	#energy_storage_operation_agg[440]
4 0
J224 1	#energy_storage_operation_agg[442]
4 0
J225 1	#energy_storage_operation_agg[444]
4 0
J226 1	#energy_storage_operation_agg[446]
4 0
J227 1	#energy_storage_operation_agg[448]
4 0
J228 1	#energy_storage_operation_agg[450]
4 0
J229 1	#energy_storage_operation_agg[452]
4 0
J230 1	#energy_storage_operation_agg[454]
4 0
J231 1	#energy_storage_operation_agg[456]
4 0
J232 1	#energy_storage_operation_agg[458]
4 0
J233 1	#energy_storage_operation_agg[460]
4 0
J234 1	#energy_storage_operation_agg[462]
4 0
J235 1	#energy_storage_operation_agg[464]
4 0
J236 1	#energy_storage_operation_agg[466]
4 0
J237 1	#energy_storage_operation_agg[468]
4 0
J238 1	#energy_storage_operation_agg[470]
4 0
J239 1	#energy_storage_operation_agg[472]
4 0
J240 1	#energy_storage_operation_agg[474]
4 0
J241 1	#energy_storage_operation_agg[476]
4 0
J242 1	#energy_storage_operation_agg[478]
4 0
J243 1	#energy_storage_operation_agg[480]
4 0
J244 1	#energy_storage_operation_agg[482]
4 0
J245 1	#energy_storage_operation_agg[484]
4 0
J246 1	#energy_storage_operation_agg[486]
4 0
J247 1	#energy_storage_operation_agg[488]
4 0
J248 1	#energy_storage_operation_agg[490]
4 0
J249 1	#energy_storage_operation_agg[492]
4 0
J250 1	#energy_storage_operation_agg[494]
4 0
J251 1	#energy_storage_operation_agg[496]
4 0
J252 1	#energy_storage_operation_agg[498]
4 0
J253 1	#energy_storage_operation_agg[500]
4 0
J254 1	#energy_storage_operation_agg[502]
4 0
J255 1	#energy_storage_operation_agg[504]
4 0
J256 1	#energy_storage_operation_agg[506]
4 0
J257 1	#energy_storage_operation_agg[508]
4 0
J258 1	#energy_storage_operation_agg[510]
4 0
J259 1	#energy_storage_operation_agg[512]
4 0
J260 1	#energy_storage_operation_agg[514]
4 0
J261 1	#energy_storage_operation_agg[516]
4 0
J262 1	#energy_storage_operation_agg[518]
4 0
J263 1	#energy_storage_operation_agg[520]
4 0
J264 1	#energy_storage_operation_agg[522]
4 0
J265 1	#energy_storage_operation_agg[524]
4 0
J266 1	#energy_storage_operation_agg[526]
4 0
J267 1	#energy_storage_operation_agg[528]
4 0
J268 1	#energy_storage_operation_agg[530]
4 0
J269 1	#energy_storage_operation_agg[532]
4 0
J270 1	#energy_storage_operation_agg[534]
4 0
J271 1	#energy_storage_operation_agg[536]
4 0
J272 1	#energy_storage_operation_agg[538]
4 0
J273 1	#energy_storage_operation_agg[540]
4 0
J274 1	#energy_storage_operation_agg[542]
4 0
J275 1	#energy_storage_operation_agg[544]
4 0
J276 1	#energy_storage_operation_agg[546]
4 0
J277 1	#energy_storage_operation_agg[548]
4 0
J278 1	#energy_storage_operation_agg[550]
4 0
J279 1	#energy_storage_operation_agg[552]
4 0
J280 1	#energy_storage_operation_agg[554]
4 0
J281 1	#energy_storage_operation_agg[556]
4 0
J282 1	#energy_storage_operation_agg[558]
4 0
J283 1	#energy_storage_operation_agg[560]
4 0
J284 1	#energy_storage_operation_agg[562]
4 0
J285 1	#energy_storage_operation_agg[564]
4 0
J286 1	#energy_storage_operation_agg[566]
4 0
J287 1	#energy_storage_operation_agg[568]
4 0
J288 1	#energy_storage_operation_agg[570]
4 0
J289 1	#energy_storage_operation_agg[572]
4 0
J290 1	#energy_storage_operation_agg[574]
4 0
J291 1	#energy_storage_operation_agg[576]
4 0
J292 1	#rated_s_capacity_unit[1]
969 1
J293 1	#rated_s_capacity_unit[2]
970 1
J294 1	#rated_s_capacity_unit[3]
971 1
J295 1	#rated_s_capacity_unit[4]
972 1
J296 1	#rated_s_capacity_unit[5]
973 1
J297 1	#rated_s_capacity_unit[6]
974 1
J298 1	#rated_e_capacity_unit[1]
975 1
J299 1	#rated_e_capacity_unit[2]
976 1
J300 1	#rated_e_capacity_unit[3]
977 1
J301 1	#rated_e_capacity_unit[4]
0 1
J302 1	#rated_e_capacity_unit[5]
1 1
J303 1	#rated_e_capacity_unit[6]
978 1
J304 2	#rated_s_capacity[1]
2 1
969 -1
J305 3	#rated_s_capacity[2]
3 1
970 -1
972 -1
J306 4	#rated_s_capacity[3]
4 1
971 -1
973 -1
974 -1
J307 2	#rated_e_capacity[1]
975 -1
979 1
J308 3	#rated_e_capacity[2]
0 -1
976 -1
980 1
J309 4	#rated_e_capacity[3]
1 -1
977 -1
978 -1
981 1
J310 2	#available_s_capacity_unit[1]
969 -1
982 1
J311 2	#available_s_capacity_unit[2]
970 -1
983 1
J312 2	#available_s_capacity_unit[3]
971 -1
984 1
J313 1	#available_s_capacity_unit[4]
985 1
J314 2	#available_s_capacity_unit[5]
972 -1
986 1
J315 2	#available_s_capacity_unit[6]
973 -1
987 1
J316 1	#available_s_capacity_unit[7]
988 1
J317 1	#available_s_capacity_unit[8]
989 1
J318 2	#available_s_capacity_unit[9]
974 -1
990 1
J319 2	#available_e_capacity_unit[1]
975 -1
991 1
J320 2	#available_e_capacity_unit[2]
976 -1
992 1
J321 2	#available_e_capacity_unit[3]
977 -1
993 1
J322 1	#available_e_capacity_unit[4]
994 1
J323 1	#available_e_capacity_unit[7]
997 1
J324 1	#available_e_capacity_unit[8]
998 1
J325 2	#available_e_capacity_unit[9]
978 -1
999 1
J326 193	#energy_storage_charging_discharging[5]
585 -0.24449315068493152
586 -0.24449315068493152
587 -0.24449315068493152
588 -0.24449315068493152
589 -0.24449315068493152
590 -0.24449315068493152
591 -0.24449315068493152
592 -0.24449315068493152
593 -0.24449315068493152
594 -0.24449315068493152
595 -0.24449315068493152
596 -0.24449315068493152
597 -0.24449315068493152
598 -0.24449315068493152
599 -0.24449315068493152
600 -0.24449315068493152
601 -0.24449315068493152
602 -0.24449315068493152
603 -0.24449315068493152
604 -0.24449315068493152
605 -0.24449315068493152
606 -0.24449315068493152
607 -0.24449315068493152
608 -0.24449315068493152
609 -0.24183561643835616
610 -0.24183561643835616
611 -0.24183561643835616
612 -0.24183561643835616
613 -0.24183561643835616
614 -0.24183561643835616
615 -0.24183561643835616
616 -0.24183561643835616
617 -0.24183561643835616
618 -0.24183561643835616
619 -0.24183561643835616
620 -0.24183561643835616
621 -0.24183561643835616
622 -0.24183561643835616
623 -0.24183561643835616
624 -0.24183561643835616
625 -0.24183561643835616
626 -0.24183561643835616
627 -0.24183561643835616
628 -0.24183561643835616
629 -0.24183561643835616
630 -0.24183561643835616
631 -0.24183561643835616
632 -0.24183561643835616
633 -0.24183561643835616
634 -0.24183561643835616
635 -0.24183561643835616
636 -0.24183561643835616
637 -0.24183561643835616
638 -0.24183561643835616
639 -0.24183561643835616
640 -0.24183561643835616
641 -0.24183561643835616
642 -0.24183561643835616
643 -0.24183561643835616
644 -0.24183561643835616
645 -0.24183561643835616
646 -0.24183561643835616
647 -0.24183561643835616
648 -0.24183561643835616
649 -0.24183561643835616
650 -0.24183561643835616
651 -0.24183561643835616
652 -0.24183561643835616
653 -0.24183561643835616
654 -0.24183561643835616
655 -0.24183561643835616
656 -0.24183561643835616
657 -0.24183561643835616
658 -0.24183561643835616
659 -0.24183561643835616
660 -0.24183561643835616
661 -0.24183561643835616
662 -0.24183561643835616
663 -0.24183561643835616
664 -0.24183561643835616
665 -0.24183561643835616
666 -0.24183561643835616
667 -0.24183561643835616
668 -0.24183561643835616
669 -0.24183561643835616
670 -0.24183561643835616
671 -0.24183561643835616
672 -0.24183561643835616
673 -0.24183561643835616
674 -0.24183561643835616
675 -0.24183561643835616
676 -0.24183561643835616
677 -0.24183561643835616
678 -0.24183561643835616
679 -0.24183561643835616
680 -0.24183561643835616
777 -0.2625570776255708
778 -0.2625570776255708
779 -0.2625570776255708
780 -0.2625570776255708
781 -0.2625570776255708
782 -0.2625570776255708
783 -0.2625570776255708
784 -0.2625570776255708
785 -0.2625570776255708
786 -0.2625570776255708
787 -0.2625570776255708
788 -0.2625570776255708
789 -0.2625570776255708
790 -0.2625570776255708
791 -0.2625570776255708
792 -0.2625570776255708
793 -0.2625570776255708
794 -0.2625570776255708
795 -0.2625570776255708
796 -0.2625570776255708
797 -0.2625570776255708
798 -0.2625570776255708
799 -0.2625570776255708
800 -0.2625570776255708
801 -0.259703196347032
802 -0.259703196347032
803 -0.259703196347032
804 -0.259703196347032
805 -0.259703196347032
806 -0.259703196347032
807 -0.259703196347032
808 -0.259703196347032
809 -0.259703196347032
810 -0.259703196347032
811 -0.259703196347032
812 -0.259703196347032
813 -0.259703196347032
814 -0.259703196347032
815 -0.259703196347032
816 -0.259703196347032
817 -0.259703196347032
818 -0.259703196347032
819 -0.259703196347032
820 -0.259703196347032
821 -0.259703196347032
822 -0.259703196347032
823 -0.259703196347032
824 -0.259703196347032
825 -0.259703196347032
826 -0.259703196347032
827 -0.259703196347032
828 -0.259703196347032
829 -0.259703196347032
830 -0.259703196347032
831 -0.259703196347032
832 -0.259703196347032
833 -0.259703196347032
834 -0.259703196347032
835 -0.259703196347032
836 -0.259703196347032
837 -0.259703196347032
838 -0.259703196347032
839 -0.259703196347032
840 -0.259703196347032
841 -0.259703196347032
842 -0.259703196347032
843 -0.259703196347032
844 -0.259703196347032
845 -0.259703196347032
846 -0.259703196347032
847 -0.259703196347032
848 -0.259703196347032
849 -0.259703196347032
850 -0.259703196347032
851 -0.259703196347032
852 -0.259703196347032
853 -0.259703196347032
854 -0.259703196347032
855 -0.259703196347032
856 -0.259703196347032
857 -0.259703196347032
858 -0.259703196347032
859 -0.259703196347032
860 -0.259703196347032
861 -0.259703196347032
862 -0.259703196347032
863 -0.259703196347032
864 -0.259703196347032
865 -0.259703196347032
866 -0.259703196347032
867 -0.259703196347032
868 -0.259703196347032
869 -0.259703196347032
870 -0.259703196347032
871 -0.259703196347032
872 -0.259703196347032
1000 1
J327 193	#energy_storage_charging_discharging[6]
681 -0.24449315068493152
682 -0.24449315068493152
683 -0.24449315068493152
684 -0.24449315068493152
685 -0.24449315068493152
686 -0.24449315068493152
687 -0.24449315068493152
688 -0.24449315068493152
689 -0.24449315068493152
690 -0.24449315068493152
691 -0.24449315068493152
692 -0.24449315068493152
693 -0.24449315068493152
694 -0.24449315068493152
695 -0.24449315068493152
696 -0.24449315068493152
697 -0.24449315068493152
698 -0.24449315068493152
699 -0.24449315068493152
700 -0.24449315068493152
701 -0.24449315068493152
702 -0.24449315068493152
703 -0.24449315068493152
704 -0.24449315068493152
705 -0.24183561643835616
706 -0.24183561643835616
707 -0.24183561643835616
708 -0.24183561643835616
709 -0.24183561643835616
710 -0.24183561643835616
711 -0.24183561643835616
712 -0.24183561643835616
713 -0.24183561643835616
714 -0.24183561643835616
715 -0.24183561643835616
716 -0.24183561643835616
717 -0.24183561643835616
718 -0.24183561643835616
719 -0.24183561643835616
720 -0.24183561643835616
721 -0.24183561643835616
722 -0.24183561643835616
723 -0.24183561643835616
724 -0.24183561643835616
725 -0.24183561643835616
726 -0.24183561643835616
727 -0.24183561643835616
728 -0.24183561643835616
729 -0.24183561643835616
730 -0.24183561643835616
731 -0.24183561643835616
732 -0.24183561643835616
733 -0.24183561643835616
734 -0.24183561643835616
735 -0.24183561643835616
736 -0.24183561643835616
737 -0.24183561643835616
738 -0.24183561643835616
739 -0.24183561643835616
740 -0.24183561643835616
741 -0.24183561643835616
742 -0.24183561643835616
743 -0.24183561643835616
744 -0.24183561643835616
745 -0.24183561643835616
746 -0.24183561643835616
747 -0.24183561643835616
748 -0.24183561643835616
749 -0.24183561643835616
750 -0.24183561643835616
751 -0.24183561643835616
752 -0.24183561643835616
753 -0.24183561643835616
754 -0.24183561643835616
755 -0.24183561643835616
756 -0.24183561643835616
757 -0.24183561643835616
758 -0.24183561643835616
759 -0.24183561643835616
760 -0.24183561643835616
761 -0.24183561643835616
762 -0.24183561643835616
763 -0.24183561643835616
764 -0.24183561643835616
765 -0.24183561643835616
766 -0.24183561643835616
767 -0.24183561643835616
768 -0.24183561643835616
769 -0.24183561643835616
770 -0.24183561643835616
771 -0.24183561643835616
772 -0.24183561643835616
773 -0.24183561643835616
774 -0.24183561643835616
775 -0.24183561643835616
776 -0.24183561643835616
873 -0.2625570776255708
874 -0.2625570776255708
875 -0.2625570776255708
876 -0.2625570776255708
877 -0.2625570776255708
878 -0.2625570776255708
879 -0.2625570776255708
880 -0.2625570776255708
881 -0.2625570776255708
882 -0.2625570776255708
883 -0.2625570776255708
884 -0.2625570776255708
885 -0.2625570776255708
886 -0.2625570776255708
887 -0.2625570776255708
888 -0.2625570776255708
889 -0.2625570776255708
890 -0.2625570776255708
891 -0.2625570776255708
892 -0.2625570776255708
893 -0.2625570776255708
894 -0.2625570776255708
895 -0.2625570776255708
896 -0.2625570776255708
897 -0.259703196347032
898 -0.259703196347032
899 -0.259703196347032
900 -0.259703196347032
901 -0.259703196347032
902 -0.259703196347032
903 -0.259703196347032
904 -0.259703196347032
905 -0.259703196347032
906 -0.259703196347032
907 -0.259703196347032
908 -0.259703196347032
909 -0.259703196347032
910 -0.259703196347032
911 -0.259703196347032
912 -0.259703196347032
913 -0.259703196347032
914 -0.259703196347032
915 -0.259703196347032
916 -0.259703196347032
917 -0.259703196347032
918 -0.259703196347032
919 -0.259703196347032
920 -0.259703196347032
921 -0.259703196347032
922 -0.259703196347032
923 -0.259703196347032
924 -0.259703196347032
925 -0.259703196347032
926 -0.259703196347032
927 -0.259703196347032
928 -0.259703196347032
929 -0.259703196347032
930 -0.259703196347032
931 -0.259703196347032
932 -0.259703196347032
933 -0.259703196347032
934 -0.259703196347032
935 -0.259703196347032
936 -0.259703196347032
937 -0.259703196347032
938 -0.259703196347032
939 -0.259703196347032
940 -0.259703196347032
941 -0.259703196347032
942 -0.259703196347032
943 -0.259703196347032
944 -0.259703196347032
945 -0.259703196347032
946 -0.259703196347032
947 -0.259703196347032
948 -0.259703196347032
949 -0.259703196347032
950 -0.259703196347032
951 -0.259703196347032
952 -0.259703196347032
953 -0.259703196347032
954 -0.259703196347032
955 -0.259703196347032
956 -0.259703196347032
957 -0.259703196347032
958 -0.259703196347032
959 -0.259703196347032
960 -0.259703196347032
961 -0.259703196347032
962 -0.259703196347032
963 -0.259703196347032
964 -0.259703196347032
965 -0.259703196347032
966 -0.259703196347032
967 -0.259703196347032
968 -0.259703196347032
1001 1
J328 2	#energy_storage_capacity_degradation[10]
7 71702.7218835928
1000 -1825.0
J329 1	#energy_storage_capacity_degradation[12]
5 1
J330 2	#energy_storage_capacity_degradation[13]
8 71702.7218835928
1001 -1825.0
J331 1	#energy_storage_capacity_degradation[15]
6 1
J332 2	#energy_storage_limits[769]
585 1
972 -1
J333 2	#energy_storage_limits[770]
777 1
972 -1
J334 2	#energy_storage_limits[771]
586 1
972 -1
J335 2	#energy_storage_limits[772]
778 1
972 -1
J336 2	#energy_storage_limits[773]
587 1
972 -1
J337 2	#energy_storage_limits[774]
779 1
972 -1
J338 2	#energy_storage_limits[775]
588 1
972 -1
J339 2	#energy_storage_limits[776]
780 1
972 -1
J340 2	#energy_storage_limits[777]
589 1
972 -1
J341 2	#energy_storage_limits[778]
781 1
972 -1
J342 2	#energy_storage_limits[779]
590 1
972 -1
J343 2	#energy_storage_limits[780]
782 1
972 -1
J344 2	#energy_storage_limits[781]
591 1
972 -1
J345 2	#energy_storage_limits[782]
783 1
972 -1
J346 2	#energy_storage_limits[783]
592 1
972 -1
J347 2	#energy_storage_limits[784]
784 1
972 -1
J348 2	#energy_storage_limits[785]
593 1
972 -1
J349 2	#energy_storage_limits[786]
785 1
972 -1
J350 2	#energy_storage_limits[787]
594 1
972 -1
J351 2	#energy_storage_limits[788]
786 1
972 -1
J352 2	#energy_storage_limits[789]
595 1
972 -1
J353 2	#energy_storage_limits[790]
787 1
972 -1
J354 2	#energy_storage_limits[791]
596 1
972 -1
J355 2	#energy_storage_limits[792]
788 1
972 -1
J356 2	#energy_storage_limits[793]
597 1
972 -1
J357 2	#energy_storage_limits[794]
789 1
972 -1
J358 2	#energy_storage_limits[795]
598 1
972 -1
J359 2	#energy_storage_limits[796]
790 1
972 -1
J360 2	#energy_storage_limits[797]
599 1
972 -1
J361 2	#energy_storage_limits[798]
791 1
972 -1
J362 2	#energy_storage_limits[799]
600 1
972 -1
J363 2	#energy_storage_limits[800]
792 1
972 -1
J364 2	#energy_storage_limits[801]
601 1
972 -1
J365 2	#energy_storage_limits[802]
793 1
972 -1
J366 2	#energy_storage_limits[803]
602 1
972 -1
J367 2	#energy_storage_limits[804]
794 1
972 -1
J368 2	#energy_storage_limits[805]
603 1
972 -1
J369 2	#energy_storage_limits[806]
795 1
972 -1
J370 2	#energy_storage_limits[807]
604 1
972 -1
J371 2	#energy_storage_limits[808]
796 1
972 -1
J372 2	#energy_storage_limits[809]
605 1
972 -1
J373 2	#energy_storage_limits[810]
797 1
972 -1
J374 2	#energy_storage_limits[811]
606 1
972 -1
J375 2	#energy_storage_limits[812]
798 1
972 -1
J376 2	#energy_storage_limits[813]
607 1
972 -1
J377 2	#energy_storage_limits[814]
799 1
972 -1
J378 2	#energy_storage_limits[815]
608 1
972 -1
J379 2	#energy_storage_limits[816]
800 1
972 -1
J380 2	#energy_storage_limits[817]
609 1
972 -1
J381 2	#energy_storage_limits[818]
801 1
972 -1
J382 2	#energy_storage_limits[819]
610 1
972 -1
J383 2	#energy_storage_limits[820]
802 1
972 -1
J384 2	#energy_storage_limits[821]
611 1
972 -1
J385 2	#energy_storage_limits[822]
803 1
972 -1
J386 2	#energy_storage_limits[823]
612 1
972 -1
J387 2	#energy_storage_limits[824]
804 1
972 -1
J388 2	#energy_storage_limits[825]
613 1
972 -1
J389 2	#energy_storage_limits[826]
805 1
972 -1
J390 2	#energy_storage_limits[827]
614 1
972 -1
J391 2	#energy_storage_limits[828]
806 1
972 -1
J392 2	#energy_storage_limits[829]
615 1
972 -1
J393 2	#energy_storage_limits[830]
807 1
972 -1
J394 2	#energy_storage_limits[831]
616 1
972 -1
J395 2	#energy_storage_limits[832]
808 1
972 -1
J396 2	#energy_storage_limits[833]
617 1
972 -1
J397 2	#energy_storage_limits[834]
809 1
972 -1
J398 2	#energy_storage_limits[835]
618 1
972 -1
J399 2	#energy_storage_limits[836]
810 1
972 -1
J400 2	#energy_storage_limits[837]
619 1
972 -1
J401 2	#energy_storage_limits[838]
811 1
972 -1
J402 2	#energy_storage_limits[839]
620 1
972 -1
J403 2	#energy_storage_limits[840]
812 1
972 -1
J404 2	#energy_storage_limits[841]
621 1
972 -1
J405 2	#energy_storage_limits[842]
813 1
972 -1
J406 2	#energy_storage_limits[843]
622 1
972 -1
J407 2	#energy_storage_limits[844]
814 1
972 -1
J408 2	#energy_storage_limits[845]
623 1
972 -1
J409 2	#energy_storage_limits[846]
815 1
972 -1
J410 2	#energy_storage_limits[847]
624 1
972 -1
J411 2	#energy_storage_limits[848]
816 1
972 -1
J412 2	#energy_storage_limits[849]
625 1
972 -1
J413 2	#energy_storage_limits[850]
817 1
972 -1
J414 2	#energy_storage_limits[851]
626 1
972 -1
J415 2	#energy_storage_limits[852]
818 1
972 -1
J416 2	#energy_storage_limits[853]
627 1
972 -1
J417 2	#energy_storage_limits[854]
819 1
972 -1
J418 2	#energy_storage_limits[855]
628 1
972 -1
J419 2	#energy_storage_limits[856]
820 1
972 -1
J420 2	#energy_storage_limits[857]
629 1
972 -1
J421 2	#energy_storage_limits[858]
821 1
972 -1
J422 2	#energy_storage_limits[859]
630 1
972 -1
J423 2	#energy_storage_limits[860]
822 1
972 -1
J424 2	#energy_storage_limits[861]
631 1
972 -1
J425 2	#energy_storage_limits[862]
823 1
972 -1
J426 2	#energy_storage_limits[863]
632 1
972 -1
J427 2	#energy_storage_limits[864]
824 1
972 -1
J428 2	#energy_storage_limits[865]
633 1
972 -1
J429 2	#energy_storage_limits[866]
825 1
972 -1
J430 2	#energy_storage_limits[867]
634 1
972 -1
J431 2	#energy_storage_limits[868]
826 1
972 -1
J432 2	#energy_storage_limits[869]
635 1
972 -1
J433 2	#energy_storage_limits[870]
827 1
972 -1
J434 2	#energy_storage_limits[871]
636 1
972 -1
J435 2	#energy_storage_limits[872]
828 1
972 -1
J436 2	#energy_storage_limits[873]
637 1
972 -1
J437 2	#energy_storage_limits[874]
829 1
972 -1
J438 2	#energy_storage_limits[875]
638 1
972 -1
J439 2	#energy_storage_limits[876]
830 1
972 -1
J440 2	#energy_storage_limits[877]
639 1
972 -1
J441 2	#energy_storage_limits[878]
831 1
972 -1
J442 2	#energy_storage_limits[879]
640 1
972 -1
J443 2	#energy_storage_limits[880]
832 1
972 -1
J444 2	#energy_storage_limits[881]
641 1
972 -1
J445 2	#energy_storage_limits[882]
833 1
972 -1
J446 2	#energy_storage_limits[883]
642 1
972 -1
J447 2	#energy_storage_limits[884]
834 1
972 -1
J448 2	#energy_storage_limits[885]
643 1
972 -1
J449 2	#energy_storage_limits[886]
835 1
972 -1
J450 2	#energy_storage_limits[887]
644 1
972 -1
J451 2	#energy_storage_limits[888]
836 1
972 -1
J452 2	#energy_storage_limits[889]
645 1
972 -1
J453 2	#energy_storage_limits[890]
837 1
972 -1
J454 2	#energy_storage_limits[891]
646 1
972 -1
J455 2	#energy_storage_limits[892]
838 1
972 -1
J456 2	#energy_storage_limits[893]
647 1
972 -1
J457 2	#energy_storage_limits[894]
839 1
972 -1
J458 2	#energy_storage_limits[895]
648 1
972 -1
J459 2	#energy_storage_limits[896]
840 1
972 -1
J460 2	#energy_storage_limits[897]
649 1
972 -1
J461 2	#energy_storage_limits[898]
841 1
972 -1
J462 2	#energy_storage_limits[899]
650 1
972 -1
J463 2	#energy_storage_limits[900]
842 1
972 -1
J464 2	#energy_storage_limits[901]
651 1
972 -1
J465 2	#energy_storage_limits[902]
843 1
972 -1
J466 2	#energy_storage_limits[903]
652 1
972 -1
J467 2	#energy_storage_limits[904]
844 1
972 -1
J468 2	#energy_storage_limits[905]
653 1
972 -1
J469 2	#energy_storage_limits[906]
845 1
972 -1
J470 2	#energy_storage_limits[907]
654 1
972 -1
J471 2	#energy_storage_limits[908]
846 1
972 -1
J472 2	#energy_storage_limits[909]
655 1
972 -1
J473 2	#energy_storage_limits[910]
847 1
972 -1
J474 2	#energy_storage_limits[911]
656 1
972 -1
J475 2	#energy_storage_limits[912]
848 1
972 -1
J476 2	#energy_storage_limits[913]
657 1
972 -1
J477 2	#energy_storage_limits[914]
849 1
972 -1
J478 2	#energy_storage_limits[915]
658 1
972 -1
J479 2	#energy_storage_limits[916]
850 1
972 -1
J480 2	#energy_storage_limits[917]
659 1
972 -1
J481 2	#energy_storage_limits[918]
851 1
972 -1
J482 2	#energy_storage_limits[919]
660 1
972 -1
J483 2	#energy_storage_limits[920]
852 1
972 -1
J484 2	#energy_storage_limits[921]
661 1
972 -1
J485 2	#energy_storage_limits[922]
853 1
972 -1
J486 2	#energy_storage_limits[923]
662 1
972 -1
J487 2	#energy_storage_limits[924]
854 1
972 -1
J488 2	#energy_storage_limits[925]
663 1
972 -1
J489 2	#energy_storage_limits[926]
855 1
972 -1
J490 2	#energy_storage_limits[927]
664 1
972 -1
J491 2	#energy_storage_limits[928]
856 1
972 -1
J492 2	#energy_storage_limits[929]
665 1
972 -1
J493 2	#energy_storage_limits[930]
857 1
972 -1
J494 2	#energy_storage_limits[931]
666 1
972 -1
J495 2	#energy_storage_limits[932]
858 1
972 -1
J496 2	#energy_storage_limits[933]
667 1
972 -1
J497 2	#energy_storage_limits[934]
859 1
972 -1
J498 2	#energy_storage_limits[935]
668 1
972 -1
J499 2	#energy_storage_limits[936]
860 1
972 -1
J500 2	#energy_storage_limits[937]
669 1
972 -1
J501 2	#energy_storage_limits[938]
861 1
972 -1
J502 2	#energy_storage_limits[939]
670 1
972 -1
J503 2	#energy_storage_limits[940]
862 1
972 -1
J504 2	#energy_storage_limits[941]
671 1
972 -1
J505 2	#energy_storage_limits[942]
863 1
972 -1
J506 2	#energy_storage_limits[943]
672 1
972 -1
J507 2	#energy_storage_limits[944]
864 1
972 -1
J508 2	#energy_storage_limits[945]
673 1
972 -1
J509 2	#energy_storage_limits[946]
865 1
972 -1
J510 2	#energy_storage_limits[947]
674 1
972 -1
J511 2	#energy_storage_limits[948]
866 1
972 -1
J512 2	#energy_storage_limits[949]
675 1
972 -1
J513 2	#energy_storage_limits[950]
867 1
972 -1
J514 2	#energy_storage_limits[951]
676 1
972 -1
J515 2	#energy_storage_limits[952]
868 1
972 -1
J516 2	#energy_storage_limits[953]
677 1
972 -1
J517 2	#energy_storage_limits[954]
869 1
972 -1
J518 2	#energy_storage_limits[955]
678 1
972 -1
J519 2	#energy_storage_limits[956]
870 1
972 -1
J520 2	#energy_storage_limits[957]
679 1
972 -1
J521 2	#energy_storage_limits[958]
871 1
972 -1
J522 2	#energy_storage_limits[959]
680 1
972 -1
J523 2	#energy_storage_limits[960]
872 1
972 -1
J524 2	#energy_storage_limits[961]
681 1
973 -1
J525 2	#energy_storage_limits[962]
873 1
973 -1
J526 2	#energy_storage_limits[963]
682 1
973 -1
J527 2	#energy_storage_limits[964]
874 1
973 -1
J528 2	#energy_storage_limits[965]
683 1
973 -1
J529 2	#energy_storage_limits[966]
875 1
973 -1
J530 2	#energy_storage_limits[967]
684 1
973 -1
J531 2	#energy_storage_limits[968]
876 1
973 -1
J532 2	#energy_storage_limits[969]
685 1
973 -1
J533 2	#energy_storage_limits[970]
877 1
973 -1
J534 2	#energy_storage_limits[971]
686 1
973 -1
J535 2	#energy_storage_limits[972]
878 1
973 -1
J536 2	#energy_storage_limits[973]
687 1
973 -1
J537 2	#energy_storage_limits[974]
879 1
973 -1
J538 2	#energy_storage_limits[975]
688 1
973 -1
J539 2	#energy_storage_limits[976]
880 1
973 -1
J540 2	#energy_storage_limits[977]
689 1
973 -1
J541 2	#energy_storage_limits[978]
881 1
973 -1
J542 2	#energy_storage_limits[979]
690 1
973 -1
J543 2	#energy_storage_limits[980]
882 1
973 -1
J544 2	#energy_storage_limits[981]
691 1
973 -1
J545 2	#energy_storage_limits[982]
883 1
973 -1
J546 2	#energy_storage_limits[983]
692 1
973 -1
J547 2	#energy_storage_limits[984]
884 1
973 -1
J548 2	#energy_storage_limits[985]
693 1
973 -1
J549 2	#energy_storage_limits[986]
885 1
973 -1
J550 2	#energy_storage_limits[987]
694 1
973 -1
J551 2	#energy_storage_limits[988]
886 1
973 -1
J552 2	#energy_storage_limits[989]
695 1
973 -1
J553 2	#energy_storage_limits[990]
887 1
973 -1
J554 2	#energy_storage_limits[991]
696 1
973 -1
J555 2	#energy_storage_limits[992]
888 1
973 -1
J556 2	#energy_storage_limits[993]
697 1
973 -1
J557 2	#energy_storage_limits[994]
889 1
973 -1
J558 2	#energy_storage_limits[995]
698 1
973 -1
J559 2	#energy_storage_limits[996]
890 1
973 -1
J560 2	#energy_storage_limits[997]
699 1
973 -1
J561 2	#energy_storage_limits[998]
891 1
973 -1
J562 2	#energy_storage_limits[999]
700 1
973 -1
J563 2	#energy_storage_limits[1000]
892 1
973 -1
J564 2	#energy_storage_limits[1001]
701 1
973 -1
J565 2	#energy_storage_limits[1002]
893 1
973 -1
J566 2	#energy_storage_limits[1003]
702 1
973 -1
J567 2	#energy_storage_limits[1004]
894 1
973 -1
J568 2	#energy_storage_limits[1005]
703 1
973 -1
J569 2	#energy_storage_limits[1006]
895 1
973 -1
J570 2	#energy_storage_limits[1007]
704 1
973 -1
J571 2	#energy_storage_limits[1008]
896 1
973 -1
J572 2	#energy_storage_limits[1009]
705 1
973 -1
J573 2	#energy_storage_limits[1010]
897 1
973 -1
J574 2	#energy_storage_limits[1011]
706 1
973 -1
J575 2	#energy_storage_limits[1012]
898 1
973 -1
J576 2	#energy_storage_limits[1013]
707 1
973 -1
J577 2	#energy_storage_limits[1014]
899 1
973 -1
J578 2	#energy_storage_limits[1015]
708 1
973 -1
J579 2	#energy_storage_limits[1016]
900 1
973 -1
J580 2	#energy_storage_limits[1017]
709 1
973 -1
J581 2	#energy_storage_limits[1018]
901 1
973 -1
J582 2	#energy_storage_limits[1019]
710 1
973 -1
J583 2	#energy_storage_limits[1020]
902 1
973 -1
J584 2	#energy_storage_limits[1021]
711 1
973 -1
J585 2	#energy_storage_limits[1022]
903 1
973 -1
J586 2	#energy_storage_limits[1023]
712 1
973 -1
J587 2	#energy_storage_limits[1024]
904 1
973 -1
J588 2	#energy_storage_limits[1025]
713 1
973 -1
J589 2	#energy_storage_limits[1026]
905 1
973 -1
J590 2	#energy_storage_limits[1027]
714 1
973 -1
J591 2	#energy_storage_limits[1028]
906 1
973 -1
J592 2	#energy_storage_limits[1029]
715 1
973 -1
J593 2	#energy_storage_limits[1030]
907 1
973 -1
J594 2	#energy_storage_limits[1031]
716 1
973 -1
J595 2	#energy_storage_limits[1032]
908 1
973 -1
J596 2	#energy_storage_limits[1033]
717 1
973 -1
J597 2	#energy_storage_limits[1034]
909 1
973 -1
J598 2	#energy_storage_limits[1035]
718 1
973 -1
J599 2	#energy_storage_limits[1036]
910 1
973 -1
J600 2	#energy_storage_limits[1037]
719 1
973 -1
J601 2	#energy_storage_limits[1038]
911 1
973 -1
J602 2	#energy_storage_limits[1039]
720 1
973 -1
J603 2	#energy_storage_limits[1040]
912 1
973 -1
J604 2	#energy_storage_limits[1041]
721 1
973 -1
J605 2	#energy_storage_limits[1042]
913 1
973 -1
J606 2	#energy_storage_limits[1043]
722 1
973 -1
J607 2	#energy_storage_limits[1044]
914 1
973 -1
J608 2	#energy_storage_limits[1045]
723 1
973 -1
J609 2	#energy_storage_limits[1046]
915 1
973 -1
J610 2	#energy_storage_limits[1047]
724 1
973 -1
J611 2	#energy_storage_limits[1048]
916 1
973 -1
J612 2	#energy_storage_limits[1049]
725 1
973 -1
J613 2	#energy_storage_limits[1050]
917 1
973 -1
J614 2	#energy_storage_limits[1051]
726 1
973 -1
J615 2	#energy_storage_limits[1052]
918 1
973 -1
J616 2	#energy_storage_limits[1053]
727 1
973 -1
J617 2	#energy_storage_limits[1054]
919 1
973 -1
J618 2	#energy_storage_limits[1055]
728 1
973 -1
J619 2	#energy_storage_limits[1056]
920 1
973 -1
J620 2	#energy_storage_limits[1057]
729 1
973 -1
J621 2	#energy_storage_limits[1058]
921 1
973 -1
J622 2	#energy_storage_limits[1059]
730 1
973 -1
J623 2	#energy_storage_limits[1060]
922 1
973 -1
J624 2	#energy_storage_limits[1061]
731 1
973 -1
J625 2	#energy_storage_limits[1062]
923 1
973 -1
J626 2	#energy_storage_limits[1063]
732 1
973 -1
J627 2	#energy_storage_limits[1064]
924 1
973 -1
J628 2	#energy_storage_limits[1065]
733 1
973 -1
J629 2	#energy_storage_limits[1066]
925 1
973 -1
J630 2	#energy_storage_limits[1067]
734 1
973 -1
J631 2	#energy_storage_limits[1068]
926 1
973 -1
J632 2	#energy_storage_limits[1069]
735 1
973 -1
J633 2	#energy_storage_limits[1070]
927 1
973 -1
J634 2	#energy_storage_limits[1071]
736 1
973 -1
J635 2	#energy_storage_limits[1072]
928 1
973 -1
J636 2	#energy_storage_limits[1073]
737 1
973 -1
J637 2	#energy_storage_limits[1074]
929 1
973 -1
J638 2	#energy_storage_limits[1075]
738 1
973 -1
J639 2	#energy_storage_limits[1076]
930 1
973 -1
J640 2	#energy_storage_limits[1077]
739 1
973 -1
J641 2	#energy_storage_limits[1078]
931 1
973 -1
J642 2	#energy_storage_limits[1079]
740 1
973 -1
J643 2	#energy_storage_limits[1080]
932 1
973 -1
J644 2	#energy_storage_limits[1081]
741 1
973 -1
J645 2	#energy_storage_limits[1082]
933 1
973 -1
J646 2	#energy_storage_limits[1083]
742 1
973 -1
J647 2	#energy_storage_limits[1084]
934 1
973 -1
J648 2	#energy_storage_limits[1085]
743 1
973 -1
J649 2	#energy_storage_limits[1086]
935 1
973 -1
J650 2	#energy_storage_limits[1087]
744 1
973 -1
J651 2	#energy_storage_limits[1088]
936 1
973 -1
J652 2	#energy_storage_limits[1089]
745 1
973 -1
J653 2	#energy_storage_limits[1090]
937 1
973 -1
J654 2	#energy_storage_limits[1091]
746 1
973 -1
J655 2	#energy_storage_limits[1092]
938 1
973 -1
J656 2	#energy_storage_limits[1093]
747 1
973 -1
J657 2	#energy_storage_limits[1094]
939 1
973 -1
J658 2	#energy_storage_limits[1095]
748 1
973 -1
J659 2	#energy_storage_limits[1096]
940 1
973 -1
J660 2	#energy_storage_limits[1097]
749 1
973 -1
J661 2	#energy_storage_limits[1098]
941 1
973 -1
J662 2	#energy_storage_limits[1099]
750 1
973 -1
J663 2	#energy_storage_limits[1100]
942 1
973 -1
J664 2	#energy_storage_limits[1101]
751 1
973 -1
J665 2	#energy_storage_limits[1102]
943 1
973 -1
J666 2	#energy_storage_limits[1103]
752 1
973 -1
J667 2	#energy_storage_limits[1104]
944 1
973 -1
J668 2	#energy_storage_limits[1105]
753 1
973 -1
J669 2	#energy_storage_limits[1106]
945 1
973 -1
J670 2	#energy_storage_limits[1107]
754 1
973 -1
J671 2	#energy_storage_limits[1108]
946 1
973 -1
J672 2	#energy_storage_limits[1109]
755 1
973 -1
J673 2	#energy_storage_limits[1110]
947 1
973 -1
J674 2	#energy_storage_limits[1111]
756 1
973 -1
J675 2	#energy_storage_limits[1112]
948 1
973 -1
J676 2	#energy_storage_limits[1113]
757 1
973 -1
J677 2	#energy_storage_limits[1114]
949 1
973 -1
J678 2	#energy_storage_limits[1115]
758 1
973 -1
J679 2	#energy_storage_limits[1116]
950 1
973 -1
J680 2	#energy_storage_limits[1117]
759 1
973 -1
J681 2	#energy_storage_limits[1118]
951 1
973 -1
J682 2	#energy_storage_limits[1119]
760 1
973 -1
J683 2	#energy_storage_limits[1120]
952 1
973 -1
J684 2	#energy_storage_limits[1121]
761 1
973 -1
J685 2	#energy_storage_limits[1122]
953 1
973 -1
J686 2	#energy_storage_limits[1123]
762 1
973 -1
J687 2	#energy_storage_limits[1124]
954 1
973 -1
J688 2	#energy_storage_limits[1125]
763 1
973 -1
J689 2	#energy_storage_limits[1126]
955 1
973 -1
J690 2	#energy_storage_limits[1127]
764 1
973 -1
J691 2	#energy_storage_limits[1128]
956 1
973 -1
J692 2	#energy_storage_limits[1129]
765 1
973 -1
J693 2	#energy_storage_limits[1130]
957 1
973 -1
J694 2	#energy_storage_limits[1131]
766 1
973 -1
J695 2	#energy_storage_limits[1132]
958 1
973 -1
J696 2	#energy_storage_limits[1133]
767 1
973 -1
J697 2	#energy_storage_limits[1134]
959 1
973 -1
J698 2	#energy_storage_limits[1135]
768 1
973 -1
J699 2	#energy_storage_limits[1136]
960 1
973 -1
J700 2	#energy_storage_limits[1137]
769 1
973 -1
J701 2	#energy_storage_limits[1138]
961 1
973 -1
J702 2	#energy_storage_limits[1139]
770 1
973 -1
J703 2	#energy_storage_limits[1140]
962 1
973 -1
J704 2	#energy_storage_limits[1141]
771 1
973 -1
J705 2	#energy_storage_limits[1142]
963 1
973 -1
J706 2	#energy_storage_limits[1143]
772 1
973 -1
J707 2	#energy_storage_limits[1144]
964 1
973 -1
J708 2	#energy_storage_limits[1145]
773 1
973 -1
J709 2	#energy_storage_limits[1146]
965 1
973 -1
J710 2	#energy_storage_limits[1147]
774 1
973 -1
J711 2	#energy_storage_limits[1148]
966 1
973 -1
J712 2	#energy_storage_limits[1149]
775 1
973 -1
J713 2	#energy_storage_limits[1150]
967 1
973 -1
J714 2	#energy_storage_limits[1151]
776 1
973 -1
J715 2	#energy_storage_limits[1152]
968 1
973 -1
J716 2	#energy_storage_operation_agg[1]
9 -1
297 1
J717 2	#energy_storage_operation_agg[3]
10 -1
298 1
J718 2	#energy_storage_operation_agg[5]
11 -1
299 1
J719 2	#energy_storage_operation_agg[7]
12 -1
300 1
J720 2	#energy_storage_operation_agg[9]
13 -1
301 1
J721 2	#energy_storage_operation_agg[11]
14 -1
302 1
J722 2	#energy_storage_operation_agg[13]
15 -1
303 1
J723 2	#energy_storage_operation_agg[15]
16 -1
304 1
J724 2	#energy_storage_operation_agg[17]
17 -1
305 1
J725 2	#energy_storage_operation_agg[19]
18 -1
306 1
J726 2	#energy_storage_operation_agg[21]
19 -1
307 1
J727 2	#energy_storage_operation_agg[23]
20 -1
308 1
J728 2	#energy_storage_operation_agg[25]
21 -1
309 1
J729 2	#energy_storage_operation_agg[27]
22 -1
310 1
J730 2	#energy_storage_operation_agg[29]
23 -1
311 1
J731 2	#energy_storage_operation_agg[31]
24 -1
312 1
J732 2	#energy_storage_operation_agg[33]
25 -1
313 1
J733 2	#energy_storage_operation_agg[35]
26 -1
314 1
J734 2	#energy_storage_operation_agg[37]
27 -1
315 1
J735 2	#energy_storage_operation_agg[39]
28 -1
316 1
J736 2	#energy_storage_operation_agg[41]
29 -1
317 1
J737 2	#energy_storage_operation_agg[43]
30 -1
318 1
J738 2	#energy_storage_operation_agg[45]
31 -1
319 1
J739 2	#energy_storage_operation_agg[47]
32 -1
320 1
J740 2	#energy_storage_operation_agg[49]
33 -1
321 1
J741 2	#energy_storage_operation_agg[51]
34 -1
322 1
J742 2	#energy_storage_operation_agg[53]
35 -1
323 1
J743 2	#energy_storage_operation_agg[55]
36 -1
324 1
J744 2	#energy_storage_operation_agg[57]
37 -1
325 1
J745 2	#energy_storage_operation_agg[59]
38 -1
326 1
J746 2	#energy_storage_operation_agg[61]
39 -1
327 1
J747 2	#energy_storage_operation_agg[63]
40 -1
328 1
J748 2	#energy_storage_operation_agg[65]
41 -1
329 1
J749 2	#energy_storage_operation_agg[67]
42 -1
330 1
J750 2	#energy_storage_operation_agg[69]
43 -1
331 1
J751 2	#energy_storage_operation_agg[71]
44 -1
332 1
J752 2	#energy_storage_operation_agg[73]
45 -1
333 1
J753 2	#energy_storage_operation_agg[75]
46 -1
334 1
J754 2	#energy_storage_operation_agg[77]
47 -1
335 1
J755 2	#energy_storage_operation_agg[79]
48 -1
336 1
J756 2	#energy_storage_operation_agg[81]
49 -1
337 1
J757 2	#energy_storage_operation_agg[83]
50 -1
338 1
J758 2	#energy_storage_operation_agg[85]
51 -1
339 1
J759 2	#energy_storage_operation_agg[87]
52 -1
340 1
J760 2	#energy_storage_operation_agg[89]
53 -1
341 1
J761 2	#energy_storage_operation_agg[91]
54 -1
342 1
J762 2	#energy_storage_operation_agg[93]
55 -1
343 1
J763 2	#energy_storage_operation_agg[95]
56 -1
344 1
J764 2	#energy_storage_operation_agg[97]
57 -1
345 1
J765 2	#energy_storage_operation_agg[99]
58 -1
346 1
J766 2	#energy_storage_operation_agg[101]
59 -1
347 1
J767 2	#energy_storage_operation_agg[103]
60 -1
348 1
J768 2	#energy_storage_operation_agg[105]
61 -1
349 1
J769 2	#energy_storage_operation_agg[107]
62 -1
350 1
J770 2	#energy_storage_operation_agg[109]
63 -1
351 1
J771 2	#energy_storage_operation_agg[111]
64 -1
352 1
J772 2	#energy_storage_operation_agg[113]
65 -1
353 1
J773 2	#energy_storage_operation_agg[115]
66 -1
354 1
J774 2	#energy_storage_operation_agg[117]
67 -1
355 1
J775 2	#energy_storage_operation_agg[119]
68 -1
356 1
J776 2	#energy_storage_operation_agg[121]
69 -1
357 1
J777 2	#energy_storage_operation_agg[123]
70 -1
358 1
J778 2	#energy_storage_operation_agg[125]
71 -1
359 1
J779 2	#energy_storage_operation_agg[127]
72 -1
360 1
J780 2	#energy_storage_operation_agg[129]
73 -1
361 1
J781 2	#energy_storage_operation_agg[131]
74 -1
362 1
J782 2	#energy_storage_operation_agg[133]
75 -1
363 1
J783 2	#energy_storage_operation_agg[135]
76 -1
364 1
J784 2	#energy_storage_operation_agg[137]
77 -1
365 1
J785 2	#energy_storage_operation_agg[139]
78 -1
366 1
J786 2	#energy_storage_operation_agg[141]
79 -1
367 1
J787 2	#energy_storage_operation_agg[143]
80 -1
368 1
J788 2	#energy_storage_operation_agg[145]
81 -1
369 1
J789 2	#energy_storage_operation_agg[147]
82 -1
370 1
J790 2	#energy_storage_operation_agg[149]
83 -1
371 1
J791 2	#energy_storage_operation_agg[151]
84 -1
372 1
J792 2	#energy_storage_operation_agg[153]
85 -1
373 1
J793 2	#energy_storage_operation_agg[155]
86 -1
374 1
J794 2	#energy_storage_operation_agg[157]
87 -1
375 1
J795 2	#energy_storage_operation_agg[159]
88 -1
376 1
J796 2	#energy_storage_operation_agg[161]
89 -1
377 1
J797 2	#energy_storage_operation_agg[163]
90 -1
378 1
J798 2	#energy_storage_operation_agg[165]
91 -1
379 1
J799 2	#energy_storage_operation_agg[167]
92 -1
380 1
J800 2	#energy_storage_operation_agg[169]
93 -1
381 1
J801 2	#energy_storage_operation_agg[171]
94 -1
382 1
J802 2	#energy_storage_operation_agg[173]
95 -1
383 1
J803 2	#energy_storage_operation_agg[175]
96 -1
384 1
J804 2	#energy_storage_operation_agg[177]
97 -1
385 1
J805 2	#energy_storage_operation_agg[179]
98 -1
386 1
J806 2	#energy_storage_operation_agg[181]
99 -1
387 1
J807 2	#energy_storage_operation_agg[183]
100 -1
388 1
J808 2	#energy_storage_operation_agg[185]
101 -1
389 1
J809 2	#energy_storage_operation_agg[187]
102 -1
390 1
J810 2	#energy_storage_operation_agg[189]
103 -1
391 1
J811 2	#energy_storage_operation_agg[191]
104 -1
392 1
J812 4	#energy_storage_operation_agg[193]
105 -1
393 1
585 -1
777 1
J813 4	#energy_storage_operation_agg[195]
106 -1
394 1
586 -1
778 1
J814 4	#energy_storage_operation_agg[197]
107 -1
395 1
587 -1
779 1
J815 4	#energy_storage_operation_agg[199]
108 -1
396 1
588 -1
780 1
J816 4	#energy_storage_operation_agg[201]
109 -1
397 1
589 -1
781 1
J817 4	#energy_storage_operation_agg[203]
110 -1
398 1
590 -1
782 1
J818 4	#energy_storage_operation_agg[205]
111 -1
399 1
591 -1
783 1
J819 4	#energy_storage_operation_agg[207]
112 -1
400 1
592 -1
784 1
J820 4	#energy_storage_operation_agg[209]
113 -1
401 1
593 -1
785 1
J821 4	#energy_storage_operation_agg[211]
114 -1
402 1
594 -1
786 1
J822 4	#energy_storage_operation_agg[213]
115 -1
403 1
595 -1
787 1
J823 4	#energy_storage_operation_agg[215]
116 -1
404 1
596 -1
788 1
J824 4	#energy_storage_operation_agg[217]
117 -1
405 1
597 -1
789 1
J825 4	#energy_storage_operation_agg[219]
118 -1
406 1
598 -1
790 1
J826 4	#energy_storage_operation_agg[221]
119 -1
407 1
599 -1
791 1
J827 4	#energy_storage_operation_agg[223]
120 -1
408 1
600 -1
792 1
J828 4	#energy_storage_operation_agg[225]
121 -1
409 1
601 -1
793 1
J829 4	#energy_storage_operation_agg[227]
122 -1
410 1
602 -1
794 1
J830 4	#energy_storage_operation_agg[229]
123 -1
411 1
603 -1
795 1
J831 4	#energy_storage_operation_agg[231]
124 -1
412 1
604 -1
796 1
J832 4	#energy_storage_operation_agg[233]
125 -1
413 1
605 -1
797 1
J833 4	#energy_storage_operation_agg[235]
126 -1
414 1
606 -1
798 1
J834 4	#energy_storage_operation_agg[237]
127 -1
415 1
607 -1
799 1
J835 4	#energy_storage_operation_agg[239]
128 -1
416 1
608 -1
800 1
J836 4	#energy_storage_operation_agg[241]
129 -1
417 1
609 -1
801 1
J837 4	#energy_storage_operation_agg[243]
130 -1
418 1
610 -1
802 1
J838 4	#energy_storage_operation_agg[245]
131 -1
419 1
611 -1
803 1
J839 4	#energy_storage_operation_agg[247]
132 -1
420 1
612 -1
804 1
J840 4	#energy_storage_operation_agg[249]
133 -1
421 1
613 -1
805 1
J841 4	#energy_storage_operation_agg[251]
134 -1
422 1
614 -1
806 1
J842 4	#energy_storage_operation_agg[253]
135 -1
423 1
615 -1
807 1
J843 4	#energy_storage_operation_agg[255]
136 -1
424 1
616 -1
808 1
J844 4	#energy_storage_operation_agg[257]
137 -1
425 1
617 -1
809 1
J845 4	#energy_storage_operation_agg[259]
138 -1
426 1
618 -1
810 1
J846 4	#energy_storage_operation_agg[261]
139 -1
427 1
619 -1
811 1
J847 4	#energy_storage_operation_agg[263]
140 -1
428 1
620 -1
812 1
J848 4	#energy_storage_operation_agg[265]
141 -1
429 1
621 -1
813 1
J849 4	#energy_storage_operation_agg[267]
142 -1
430 1
622 -1
814 1
J850 4	#energy_storage_operation_agg[269]
143 -1
431 1
623 -1
815 1
J851 4	#energy_storage_operation_agg[271]
144 -1
432 1
624 -1
816 1
J852 4	#energy_storage_operation_agg[273]
145 -1
433 1
625 -1
817 1
J853 4	#energy_storage_operation_agg[275]
146 -1
434 1
626 -1
818 1
J854 4	#energy_storage_operation_agg[277]
147 -1
435 1
627 -1
819 1
J855 4	#energy_storage_operation_agg[279]
148 -1
436 1
628 -1
820 1
J856 4	#energy_storage_operation_agg[281]
149 -1
437 1
629 -1
821 1
J857 4	#energy_storage_operation_agg[283]
150 -1
438 1
630 -1
822 1
J858 4	#energy_storage_operation_agg[285]
151 -1
439 1
631 -1
823 1
J859 4	#energy_storage_operation_agg[287]
152 -1
440 1
632 -1
824 1
J860 4	#energy_storage_operation_agg[289]
153 -1
441 1
633 -1
825 1
J861 4	#energy_storage_operation_agg[291]
154 -1
442 1
634 -1
826 1
J862 4	#energy_storage_operation_agg[293]
155 -1
443 1
635 -1
827 1
J863 4	#energy_storage_operation_agg[295]
156 -1
444 1
636 -1
828 1
J864 4	#energy_storage_operation_agg[297]
157 -1
445 1
637 -1
829 1
J865 4	#energy_storage_operation_agg[299]
158 -1
446 1
638 -1
830 1
J866 4	#energy_storage_operation_agg[301]
159 -1
447 1
639 -1
831 1
J867 4	#energy_storage_operation_agg[303]
160 -1
448 1
640 -1
832 1
J868 4	#energy_storage_operation_agg[305]
161 -1
449 1
641 -1
833 1
J869 4	#energy_storage_operation_agg[307]
162 -1
450 1
642 -1
834 1
J870 4	#energy_storage_operation_agg[309]
163 -1
451 1
643 -1
835 1
J871 4	#energy_storage_operation_agg[311]
164 -1
452 1
644 -1
836 1
J872 4	#energy_storage_operation_agg[313]
165 -1
453 1
645 -1
837 1
J873 4	#energy_storage_operation_agg[315]
166 -1
454 1
646 -1
838 1
J874 4	#energy_storage_operation_agg[317]
167 -1
455 1
647 -1
839 1
J875 4	#energy_storage_operation_agg[319]
168 -1
456 1
648 -1
840 1
J876 4	#energy_storage_operation_agg[321]
169 -1
457 1
649 -1
841 1
J877 4	#energy_storage_operation_agg[323]
170 -1
458 1
650 -1
842 1
J878 4	#energy_storage_operation_agg[325]
171 -1
459 1
651 -1
843 1
J879 4	#energy_storage_operation_agg[327]
172 -1
460 1
652 -1
844 1
J880 4	#energy_storage_operation_agg[329]
173 -1
461 1
653 -1
845 1
J881 4	#energy_storage_operation_agg[331]
174 -1
462 1
654 -1
846 1
J882 4	#energy_storage_operation_agg[333]
175 -1
463 1
655 -1
847 1
J883 4	#energy_storage_operation_agg[335]
176 -1
464 1
656 -1
848 1
J884 4	#energy_storage_operation_agg[337]
177 -1
465 1
657 -1
849 1
J885 4	#energy_storage_operation_agg[339]
178 -1
466 1
658 -1
850 1
J886 4	#energy_storage_operation_agg[341]
179 -1
467 1
659 -1
851 1
J887 4	#energy_storage_operation_agg[343]
180 -1
468 1
660 -1
852 1
J888 4	#energy_storage_operation_agg[345]
181 -1
469 1
661 -1
853 1
J889 4	#energy_storage_operation_agg[347]
182 -1
470 1
662 -1
854 1
J890 4	#energy_storage_operation_agg[349]
183 -1
471 1
663 -1
855 1
J891 4	#energy_storage_operation_agg[351]
184 -1
472 1
664 -1
856 1
J892 4	#energy_storage_operation_agg[353]
185 -1
473 1
665 -1
857 1
J893 4	#energy_storage_operation_agg[355]
186 -1
474 1
666 -1
858 1
J894 4	#energy_storage_operation_agg[357]
187 -1
475 1
667 -1
859 1
J895 4	#energy_storage_operation_agg[359]
188 -1
476 1
668 -1
860 1
J896 4	#energy_storage_operation_agg[361]
189 -1
477 1
669 -1
861 1
J897 4	#energy_storage_operation_agg[363]
190 -1
478 1
670 -1
862 1
J898 4	#energy_storage_operation_agg[365]
191 -1
479 1
671 -1
863 1
J899 4	#energy_storage_operation_agg[367]
192 -1
480 1
672 -1
864 1
J900 4	#energy_storage_operation_agg[369]
193 -1
481 1
673 -1
865 1
J901 4	#energy_storage_operation_agg[371]
194 -1
482 1
674 -1
866 1
J902 4	#energy_storage_operation_agg[373]
195 -1
483 1
675 -1
867 1
J903 4	#energy_storage_operation_agg[375]
196 -1
484 1
676 -1
868 1
J904 4	#energy_storage_operation_agg[377]
197 -1
485 1
677 -1
869 1
J905 4	#energy_storage_operation_agg[379]
198 -1
486 1
678 -1
870 1
J906 4	#energy_storage_operation_agg[381]
199 -1
487 1
679 -1
871 1
J907 4	#energy_storage_operation_agg[383]
200 -1
488 1
680 -1
872 1
J908 4	#energy_storage_operation_agg[385]
201 -1
489 1
681 -1
873 1
J909 4	#energy_storage_operation_agg[387]
202 -1
490 1
682 -1
874 1
J910 4	#energy_storage_operation_agg[389]
203 -1
491 1
683 -1
875 1
J911 4	#energy_storage_operation_agg[391]
204 -1
492 1
684 -1
876 1
J912 4	#energy_storage_operation_agg[393]
205 -1
493 1
685 -1
877 1
J913 4	#energy_storage_operation_agg[395]
206 -1
494 1
686 -1
878 1
J914 4	#energy_storage_operation_agg[397]
207 -1
495 1
687 -1
879 1
J915 4	#energy_storage_operation_agg[399]
208 -1
496 1
688 -1
880 1
J916 4	#energy_storage_operation_agg[401]
209 -1
497 1
689 -1
881 1
J917 4	#energy_storage_operation_agg[403]
210 -1
498 1
690 -1
882 1
J918 4	#energy_storage_operation_agg[405]
211 -1
499 1
691 -1
883 1
J919 4	#energy_storage_operation_agg[407]
212 -1
500 1
692 -1
884 1
J920 4	#energy_storage_operation_agg[409]
213 -1
501 1
693 -1
885 1
J921 4	#energy_storage_operation_agg[411]
214 -1
502 1
694 -1
886 1
J922 4	#energy_storage_operation_agg[413]
215 -1
503 1
695 -1
887 1
J923 4	#energy_storage_operation_agg[415]
216 -1
504 1
696 -1
888 1
J924 4	#energy_storage_operation_agg[417]
217 -1
505 1
697 -1
889 1
J925 4	#energy_storage_operation_agg[419]
218 -1
506 1
698 -1
890 1
J926 4	#energy_storage_operation_agg[421]
219 -1
507 1
699 -1
891 1
J927 4	#energy_storage_operation_agg[423]
220 -1
508 1
700 -1
892 1
J928 4	#energy_storage_operation_agg[425]
221 -1
509 1
701 -1
893 1
J929 4	#energy_storage_operation_agg[427]
222 -1
510 1
702 -1
894 1
J930 4	#energy_storage_operation_agg[429]
223 -1
511 1
703 -1
895 1
J931 4	#energy_storage_operation_agg[431]
224 -1
512 1
704 -1
896 1
J932 4	#energy_storage_operation_agg[433]
225 -1
513 1
705 -1
897 1
J933 4	#energy_storage_operation_agg[435]
226 -1
514 1
706 -1
898 1
J934 4	#energy_storage_operation_agg[437]
227 -1
515 1
707 -1
899 1
J935 4	#energy_storage_operation_agg[439]
228 -1
516 1
708 -1
900 1
J936 4	#energy_storage_operation_agg[441]
229 -1
517 1
709 -1
901 1
J937 4	#energy_storage_operation_agg[443]
230 -1
518 1
710 -1
902 1
J938 4	#energy_storage_operation_agg[445]
231 -1
519 1
711 -1
903 1
J939 4	#energy_storage_operation_agg[447]
232 -1
520 1
712 -1
904 1
J940 4	#energy_storage_operation_agg[449]
233 -1
521 1
713 -1
905 1
J941 4	#energy_storage_operation_agg[451]
234 -1
522 1
714 -1
906 1
J942 4	#energy_storage_operation_agg[453]
235 -1
523 1
715 -1
907 1
J943 4	#energy_storage_operation_agg[455]
236 -1
524 1
716 -1
908 1
J944 4	#energy_storage_operation_agg[457]
237 -1
525 1
717 -1
909 1
J945 4	#energy_storage_operation_agg[459]
238 -1
526 1
718 -1
910 1
J946 4	#energy_storage_operation_agg[461]
239 -1
527 1
719 -1
911 1
J947 4	#energy_storage_operation_agg[463]
240 -1
528 1
720 -1
912 1
J948 4	#energy_storage_operation_agg[465]
241 -1
529 1
721 -1
913 1
J949 4	#energy_storage_operation_agg[467]
242 -1
530 1
722 -1
914 1
J950 4	#energy_storage_operation_agg[469]
243 -1
531 1
723 -1
915 1
J951 4	#energy_storage_operation_agg[471]
244 -1
532 1
724 -1
916 1
J952 4	#energy_storage_operation_agg[473]
245 -1
533 1
725 -1
917 1
J953 4	#energy_storage_operation_agg[475]
246 -1
534 1
726 -1
918 1
J954 4	#energy_storage_operation_agg[477]
247 -1
535 1
727 -1
919 1
J955 4	#energy_storage_operation_agg[479]
248 -1
536 1
728 -1
920 1
J956 4	#energy_storage_operation_agg[481]
249 -1
537 1
729 -1
921 1
J957 4	#energy_storage_operation_agg[483]
250 -1
538 1
730 -1
922 1
J958 4	#energy_storage_operation_agg[485]
251 -1
539 1
731 -1
923 1
J959 4	#energy_storage_operation_agg[487]
252 -1
540 1
732 -1
924 1
J960 4	#energy_storage_operation_agg[489]
253 -1
541 1
733 -1
925 1
J961 4	#energy_storage_operation_agg[491]
254 -1
542 1
734 -1
926 1
J962 4	#energy_storage_operation_agg[493]
255 -1
543 1
735 -1
927 1
J963 4	#energy_storage_operation_agg[495]
256 -1
544 1
736 -1
928 1
J964 4	#energy_storage_operation_agg[497]
257 -1
545 1
737 -1
929 1
J965 4	#energy_storage_operation_agg[499]
258 -1
546 1
738 -1
930 1
J966 4	#energy_storage_operation_agg[501]
259 -1
547 1
739 -1
931 1
J967 4	#energy_storage_operation_agg[503]
260 -1
548 1
740 -1
932 1
J968 4	#energy_storage_operation_agg[505]
261 -1
549 1
741 -1
933 1
J969 4	#energy_storage_operation_agg[507]
262 -1
550 1
742 -1
934 1
J970 4	#energy_storage_operation_agg[509]
263 -1
551 1
743 -1
935 1
J971 4	#energy_storage_operation_agg[511]
264 -1
552 1
744 -1
936 1
J972 4	#energy_storage_operation_agg[513]
265 -1
553 1
745 -1
937 1
J973 4	#energy_storage_operation_agg[515]
266 -1
554 1
746 -1
938 1
J974 4	#energy_storage_operation_agg[517]
267 -1
555 1
747 -1
939 1
J975 4	#energy_storage_operation_agg[519]
268 -1
556 1
748 -1
940 1
J976 4	#energy_storage_operation_agg[521]
269 -1
557 1
749 -1
941 1
J977 4	#energy_storage_operation_agg[523]
270 -1
558 1
750 -1
942 1
J978 4	#energy_storage_operation_agg[525]
271 -1
559 1
751 -1
943 1
J979 4	#energy_storage_operation_agg[527]
272 -1
560 1
752 -1
944 1
J980 4	#energy_storage_operation_agg[529]
273 -1
561 1
753 -1
945 1
J981 4	#energy_storage_operation_agg[531]
274 -1
562 1
754 -1
946 1
J982 4	#energy_storage_operation_agg[533]
275 -1
563 1
755 -1
947 1
J983 4	#energy_storage_operation_agg[535]
276 -1
564 1
756 -1
948 1
J984 4	#energy_storage_operation_agg[537]
277 -1
565 1
757 -1
949 1
J985 4	#energy_storage_operation_agg[539]
278 -1
566 1
758 -1
950 1
J986 4	#energy_storage_operation_agg[541]
279 -1
567 1
759 -1
951 1
J987 4	#energy_storage_operation_agg[543]
280 -1
568 1
760 -1
952 1
J988 4	#energy_storage_operation_agg[545]
281 -1
569 1
761 -1
953 1
J989 4	#energy_storage_operation_agg[547]
282 -1
570 1
762 -1
954 1
J990 4	#energy_storage_operation_agg[549]
283 -1
571 1
763 -1
955 1
J991 4	#energy_storage_operation_agg[551]
284 -1
572 1
764 -1
956 1
J992 4	#energy_storage_operation_agg[553]
285 -1
573 1
765 -1
957 1
J993 4	#energy_storage_operation_agg[555]
286 -1
574 1
766 -1
958 1
J994 4	#energy_storage_operation_agg[557]
287 -1
575 1
767 -1
959 1
J995 4	#energy_storage_operation_agg[559]
288 -1
576 1
768 -1
960 1
J996 4	#energy_storage_operation_agg[561]
289 -1
577 1
769 -1
961 1
J997 4	#energy_storage_operation_agg[563]
290 -1
578 1
770 -1
962 1
J998 4	#energy_storage_operation_agg[565]
291 -1
579 1
771 -1
963 1
J999 4	#energy_storage_operation_agg[567]
292 -1
580 1
772 -1
964 1
J1000 4	#energy_storage_operation_agg[569]
293 -1
581 1
773 -1
965 1
J1001 4	#energy_storage_operation_agg[571]
294 -1
582 1
774 -1
966 1
J1002 4	#energy_storage_operation_agg[573]
295 -1
583 1
775 -1
967 1
J1003 4	#energy_storage_operation_agg[575]
296 -1
584 1
776 -1
968 1
G0 960	#objective
9 1000.0
10 1000.0
11 1000.0
12 1000.0
13 1000.0
14 1000.0
15 1000.0
16 1000.0
17 1000.0
18 1000.0
19 1000.0
20 1000.0
21 1000.0
22 1000.0
23 1000.0
24 1000.0
25 1000.0
26 1000.0
27 1000.0
28 1000.0
29 1000.0
30 1000.0
31 1000.0
32 1000.0
33 1000.0
34 1000.0
35 1000.0
36 1000.0
37 1000.0
38 1000.0
39 1000.0
40 1000.0
41 1000.0
42 1000.0
43 1000.0
44 1000.0
45 1000.0
46 1000.0
47 1000.0
48 1000.0
49 1000.0
50 1000.0
51 1000.0
52 1000.0
53 1000.0
54 1000.0
55 1000.0
56 1000.0
57 1000.0
58 1000.0
59 1000.0
60 1000.0
61 1000.0
62 1000.0
63 1000.0
64 1000.0
65 1000.0
66 1000.0
67 1000.0
68 1000.0
69 1000.0
70 1000.0
71 1000.0
72 1000.0
73 1000.0
74 1000.0
75 1000.0
76 1000.0
77 1000.0
78 1000.0
79 1000.0
80 1000.0
81 1000.0
82 1000.0
83 1000.0
84 1000.0
85 1000.0
86 1000.0
87 1000.0
88 1000.0
89 1000.0
90 1000.0
91 1000.0
92 1000.0
93 1000.0
94 1000.0
95 1000.0
96 1000.0
97 1000.0
98 1000.0
99 1000.0
100 1000.0
101 1000.0
102 1000.0
103 1000.0
104 1000.0
105 1000.0
106 1000.0
107 1000.0
108 1000.0
109 1000.0
110 1000.0
111 1000.0
112 1000.0
113 1000.0
114 1000.0
115 1000.0
116 1000.0
117 1000.0
118 1000.0
119 1000.0
120 1000.0
121 1000.0
122 1000.0
123 1000.0
124 1000.0
125 1000.0
126 1000.0
127 1000.0
128 1000.0
129 1000.0
130 1000.0
131 1000.0
132 1000.0
133 1000.0
134 1000.0
135 1000.0
136 1000.0
137 1000.0
138 1000.0
139 1000.0
140 1000.0
141 1000.0
142 1000.0
143 1000.0
144 1000.0
145 1000.0
146 1000.0
147 1000.0
148 1000.0
149 1000.0
150 1000.0
151 1000.0
152 1000.0
153 1000.0
154 1000.0
155 1000.0
156 1000.0
157 1000.0
158 1000.0
159 1000.0
160 1000.0
161 1000.0
162 1000.0
163 1000.0
164 1000.0
165 1000.0
166 1000.0
167 1000.0
168 1000.0
169 1000.0
170 1000.0
171 1000.0
172 1000.0
173 1000.0
174 1000.0
175 1000.0
176 1000.0
177 1000.0
178 1000.0
179 1000.0
180 1000.0
181 1000.0
182 1000.0
183 1000.0
184 1000.0
185 1000.0
186 1000.0
187 1000.0
188 1000.0
189 1000.0
190 1000.0
191 1000.0
192 1000.0
193 1000.0
194 1000.0
195 1000.0
196 1000.0
197 1000.0
198 1000.0
199 1000.0
200 1000.0
201 1000.0
202 1000.0
203 1000.0
204 1000.0
205 1000.0
206 1000.0
207 1000.0
208 1000.0
209 1000.0
210 1000.0
211 1000.0
212 1000.0
213 1000.0
214 1000.0
215 1000.0
216 1000.0
217 1000.0
218 1000.0
219 1000.0
220 1000.0
221 1000.0
222 1000.0
223 1000.0
224 1000.0
225 1000.0
226 1000.0
227 1000.0
228 1000.0
229 1000.0
230 1000.0
231 1000.0
232 1000.0
233 1000.0
234 1000.0
235 1000.0
236 1000.0
237 1000.0
238 1000.0
239 1000.0
240 1000.0
241 1000.0
242 1000.0
243 1000.0
244 1000.0
245 1000.0
246 1000.0
247 1000.0
248 1000.0
249 1000.0
250 1000.0
251 1000.0
252 1000.0
253 1000.0
254 1000.0
255 1000.0
256 1000.0
257 1000.0
258 1000.0
259 1000.0
260 1000.0
261 1000.0
262 1000.0
263 1000.0
264 1000.0
265 1000.0
266 1000.0
267 1000.0
268 1000.0
269 1000.0
270 1000.0
271 1000.0
272 1000.0
273 1000.0
274 1000.0
275 1000.0
276 1000.0
277 1000.0
278 1000.0
279 1000.0
280 1000.0
281 1000.0
282 1000.0
283 1000.0
284 1000.0
285 1000.0
286 1000.0
287 1000.0
288 1000.0
289 1000.0
290 1000.0
291 1000.0
292 1000.0
293 1000.0
294 1000.0
295 1000.0
296 1000.0
297 1000.0
298 1000.0
299 1000.0
300 1000.0
301 1000.0
302 1000.0
303 1000.0
304 1000.0
305 1000.0
306 1000.0
307 1000.0
308 1000.0
309 1000.0
310 1000.0
311 1000.0
312 1000.0
313 1000.0
314 1000.0
315 1000.0
316 1000.0
317 1000.0
318 1000.0
319 1000.0
320 1000.0
321 1000.0
322 1000.0
323 1000.0
324 1000.0
325 1000.0
326 1000.0
327 1000.0
328 1000.0
329 1000.0
330 1000.0
331 1000.0
332 1000.0
333 1000.0
334 1000.0
335 1000.0
336 1000.0
337 1000.0
338 1000.0
339 1000.0
340 1000.0
341 1000.0
342 1000.0
343 1000.0
344 1000.0
345 1000.0
346 1000.0
347 1000.0
348 1000.0
349 1000.0
350 1000.0
351 1000.0
352 1000.0
353 1000.0
354 1000.0
355 1000.0
356 1000.0
357 1000.0
358 1000.0
359 1000.0
360 1000.0
361 1000.0
362 1000.0
363 1000.0
364 1000.0
365 1000.0
366 1000.0
367 1000.0
368 1000.0
369 1000.0
370 1000.0
371 1000.0
372 1000.0
373 1000.0
374 1000.0
375 1000.0
376 1000.0
377 1000.0
378 1000.0
379 1000.0
380 1000.0
381 1000.0
382 1000.0
383 1000.0
384 1000.0
385 1000.0
386 1000.0
387 1000.0
388 1000.0
389 1000.0
390 1000.0
391 1000.0
392 1000.0
393 1000.0
394 1000.0
395 1000.0
396 1000.0
397 1000.0
398 1000.0
399 1000.0
400 1000.0
401 1000.0
402 1000.0
403 1000.0
404 1000.0
405 1000.0
406 1000.0
407 1000.0
408 1000.0
409 1000.0
410 1000.0
411 1000.0
412 1000.0
413 1000.0
414 1000.0
415 1000.0
416 1000.0
417 1000.0
418 1000.0
419 1000.0
420 1000.0
421 1000.0
422 1000.0
423 1000.0
424 1000.0
425 1000.0
426 1000.0
427 1000.0
428 1000.0
429 1000.0
430 1000.0
431 1000.0
432 1000.0
433 1000.0
434 1000.0
435 1000.0
436 1000.0
437 1000.0
438 1000.0
439 1000.0
440 1000.0
441 1000.0
442 1000.0
443 1000.0
444 1000.0
445 1000.0
446 1000.0
447 1000.0
448 1000.0
449 1000.0
450 1000.0
451 1000.0
452 1000.0
453 1000.0
454 1000.0
455 1000.0
456 1000.0
457 1000.0
458 1000.0
459 1000.0
460 1000.0
461 1000.0
462 1000.0
463 1000.0
464 1000.0
465 1000.0
466 1000.0
467 1000.0
468 1000.0
469 1000.0
470 1000.0
471 1000.0
472 1000.0
473 1000.0
474 1000.0
475 1000.0
476 1000.0
477 1000.0
478 1000.0
479 1000.0
480 1000.0
481 1000.0
482 1000.0
483 1000.0
484 1000.0
485 1000.0
486 1000.0
487 1000.0
488 1000.0
489 1000.0
490 1000.0
491 1000.0
492 1000.0
493 1000.0
494 1000.0
495 1000.0
496 1000.0
497 1000.0
498 1000.0
499 1000.0
500 1000.0
501 1000.0
502 1000.0
503 1000.0
504 1000.0
505 1000.0
506 1000.0
507 1000.0
508 1000.0
509 1000.0
510 1000.0
511 1000.0
512 1000.0
513 1000.0
514 1000.0
515 1000.0
516 1000.0
517 1000.0
518 1000.0
519 1000.0
520 1000.0
521 1000.0
522 1000.0
523 1000.0
524 1000.0
525 1000.0
526 1000.0
527 1000.0
528 1000.0
529 1000.0
530 1000.0
531 1000.0
532 1000.0
533 1000.0
534 1000.0
535 1000.0
536 1000.0
537 1000.0
538 1000.0
539 1000.0
540 1000.0
541 1000.0
542 1000.0
543 1000.0
544 1000.0
545 1000.0
546 1000.0
547 1000.0
548 1000.0
549 1000.0
550 1000.0
551 1000.0
552 1000.0
553 1000.0
554 1000.0
555 1000.0
556 1000.0
557 1000.0
558 1000.0
559 1000.0
560 1000.0
561 1000.0
562 1000.0
563 1000.0
564 1000.0
565 1000.0
566 1000.0
567 1000.0
568 1000.0
569 1000.0
570 1000.0
571 1000.0
572 1000.0
573 1000.0
574 1000.0
575 1000.0
576 1000.0
577 1000.0
578 1000.0
579 1000.0
580 1000.0
581 1000.0
582 1000.0
583 1000.0
584 1000.0
585 1e-05
586 1e-05
587 1e-05
588 1e-05
589 1e-05
590 1e-05
591 1e-05
592 1e-05
593 1e-05
594 1e-05
595 1e-05
596 1e-05
597 1e-05
598 1e-05
599 1e-05
600 1e-05
601 1e-05
602 1e-05
603 1e-05
604 1e-05
605 1e-05
606 1e-05
607 1e-05
608 1e-05
609 1e-05
610 1e-05
611 1e-05
612 1e-05
613 1e-05
614 1e-05
615 1e-05
616 1e-05
617 1e-05
618 1e-05
619 1e-05
620 1e-05
621 1e-05
622 1e-05
623 1e-05
624 1e-05
625 1e-05
626 1e-05
627 1e-05
628 1e-05
629 1e-05
630 1e-05
631 1e-05
632 1e-05
633 1e-05
634 1e-05
635 1e-05
636 1e-05
637 1e-05
638 1e-05
639 1e-05
640 1e-05
641 1e-05
642 1e-05
643 1e-05
644 1e-05
645 1e-05
646 1e-05
647 1e-05
648 1e-05
649 1e-05
650 1e-05
651 1e-05
652 1e-05
653 1e-05
654 1e-05
655 1e-05
656 1e-05
657 1e-05
658 1e-05
659 1e-05
660 1e-05
661 1e-05
662 1e-05
663 1e-05
664 1e-05
665 1e-05
666 1e-05
667 1e-05
668 1e-05
669 1e-05
670 1e-05
671 1e-05
672 1e-05
673 1e-05
674 1e-05
675 1e-05
676 1e-05
677 1e-05
678 1e-05
679 1e-05
680 1e-05
681 1e-05
682 1e-05
683 1e-05
684 1e-05
685 1e-05
686 1e-05
687 1e-05
688 1e-05
689 1e-05
690 1e-05
691 1e-05
692 1e-05
693 1e-05
694 1e-05
695 1e-05
696 1e-05
697 1e-05
698 1e-05
699 1e-05
700 1e-05
701 1e-05
702 1e-05
703 1e-05
704 1e-05
705 1e-05
706 1e-05
707 1e-05
708 1e-05
709 1e-05
710 1e-05
711 1e-05
712 1e-05
713 1e-05
714 1e-05
715 1e-05
716 1e-05
717 1e-05
718 1e-05
719 1e-05
720 1e-05
721 1e-05
722 1e-05
723 1e-05
724 1e-05
725 1e-05
726 1e-05
727 1e-05
728 1e-05
729 1e-05
730 1e-05
731 1e-05
732 1e-05
733 1e-05
734 1e-05
735 1e-05
736 1e-05
737 1e-05
738 1e-05
739 1e-05
740 1e-05
741 1e-05
742 1e-05
743 1e-05
744 1e-05
745 1e-05
746 1e-05
747 1e-05
748 1e-05
749 1e-05
750 1e-05
751 1e-05
752 1e-05
753 1e-05
754 1e-05
755 1e-05
756 1e-05
757 1e-05
758 1e-05
759 1e-05
760 1e-05
761 1e-05
762 1e-05
763 1e-05
764 1e-05
765 1e-05
766 1e-05
767 1e-05
768 1e-05
769 1e-05
770 1e-05
771 1e-05
772 1e-05
773 1e-05
774 1e-05
775 1e-05
776 1e-05
777 1e-05
778 1e-05
779 1e-05
780 1e-05
781 1e-05
782 1e-05
783 1e-05
784 1e-05
785 1e-05
786 1e-05
787 1e-05
788 1e-05
789 1e-05
790 1e-05
791 1e-05
792 1e-05
793 1e-05
794 1e-05
795 1e-05
796 1e-05
797 1e-05
798 1e-05
799 1e-05
800 1e-05
801 1e-05
802 1e-05
803 1e-05
804 1e-05
805 1e-05
806 1e-05
807 1e-05
808 1e-05
809 1e-05
810 1e-05
811 1e-05
812 1e-05
813 1e-05
814 1e-05
815 1e-05
816 1e-05
817 1e-05
818 1e-05
819 1e-05
820 1e-05
821 1e-05
822 1e-05
823 1e-05
824 1e-05
825 1e-05
826 1e-05
827 1e-05
828 1e-05
829 1e-05
830 1e-05
831 1e-05
832 1e-05
833 1e-05
834 1e-05
835 1e-05
836 1e-05
837 1e-05
838 1e-05
839 1e-05
840 1e-05
841 1e-05
842 1e-05
843 1e-05
844 1e-05
845 1e-05
846 1e-05
847 1e-05
848 1e-05
849 1e-05
850 1e-05
851 1e-05
852 1e-05
853 1e-05
854 1e-05
855 1e-05
856 1e-05
857 1e-05
858 1e-05
859 1e-05
860 1e-05
861 1e-05
862 1e-05
863 1e-05
864 1e-05
865 1e-05
866 1e-05
867 1e-05
868 1e-05
869 1e-05
870 1e-05
871 1e-05
872 1e-05
873 1e-05
874 1e-05
875 1e-05
876 1e-05
877 1e-05
878 1e-05
879 1e-05
880 1e-05
881 1e-05
882 1e-05
883 1e-05
884 1e-05
885 1e-05
886 1e-05
887 1e-05
888 1e-05
889 1e-05
890 1e-05
891 1e-05
892 1e-05
893 1e-05
894 1e-05
895 1e-05
896 1e-05
897 1e-05
898 1e-05
899 1e-05
900 1e-05
901 1e-05
902 1e-05
903 1e-05
904 1e-05
905 1e-05
906 1e-05
907 1e-05
908 1e-05
909 1e-05
910 1e-05
911 1e-05
912 1e-05
913 1e-05
914 1e-05
915 1e-05
916 1e-05
917 1e-05
918 1e-05
919 1e-05
920 1e-05
921 1e-05
922 1e-05
923 1e-05
924 1e-05
925 1e-05
926 1e-05
927 1e-05
928 1e-05
929 1e-05
930 1e-05
931 1e-05
932 1e-05
933 1e-05
934 1e-05
935 1e-05
936 1e-05
937 1e-05
938 1e-05
939 1e-05
940 1e-05
941 1e-05
942 1e-05
943 1e-05
944 1e-05
945 1e-05
946 1e-05
947 1e-05
948 1e-05
949 1e-05
950 1e-05
951 1e-05
952 1e-05
953 1e-05
954 1e-05
955 1e-05
956 1e-05
957 1e-05
958 1e-05
959 1e-05
960 1e-05
961 1e-05
962 1e-05
963 1e-05
964 1e-05
965 1e-05
966 1e-05
967 1e-05
968 1e-05
